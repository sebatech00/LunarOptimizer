#!/usr/bin/env bash
# Offline-capable build WITHOUT Gradle/D8: kotlinc -> dx -> desugar (tools/dex-hotfix) -> DEX gate -> aapt -> zipalign -> apksigner.
# Used when Maven/Google are unreachable. ./build.sh (D8) remains the preferred build when a network is available.
# Env: KOTLIN_HOME (Kotlin 1.9.x, NOT 2.x: 2.x stdlib is full of invokedynamic), ANDROID_JAR (API 34), KEYSTORE (+ KS_ALIAS, KS_PASS).
# Without KEYSTORE it produces the aligned, UNSIGNED apk plus a TEST-signed copy that can NOT update an installed Lunar Optimizer.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd); SRC="$ROOT/app/src/main"; B="$ROOT/build"
KH=${KOTLIN_HOME:-/home/claude/tc/k19/kotlinc}; AJ=${ANDROID_JAR:-/home/claude/tc/android.jar}
VC=$(grep -oP 'versionCode = \K\d+' "$ROOT/app/build.gradle.kts"); VN=$(grep -oP 'versionName = "\K[^"]+' "$ROOT/app/build.gradle.kts")
export JAVA_OPTS="${JAVA_OPTS:--Xmx3200m -Xss16m}"
rm -rf "$B"; mkdir -p "$B/classes" "$B/dex"
echo "== kotlinc ($("$KH/bin/kotlinc" -version 2>&1 | tail -1))"
"$KH/bin/kotlinc" "$SRC"/java/com/lunaroptimizer/app/*.kt -cp "$AJ:$ROOT/libs/shizuku-api.jar" -jvm-target 1.8 -Xlambdas=class -Xsam-conversions=class -Xstring-concat=inline -no-reflect -nowarn -d "$B/classes" > "$B/kotlinc.log" 2>&1 || { grep -E "error" -A2 "$B/kotlinc.log" | head -60; echo "KOTLIN COMPILE FAILED"; exit 1; }
(cd "$B/classes" && jar cf ../app.jar .)
cp "$KH/lib/kotlin-stdlib.jar" "$B/stdlib.jar"; zip -qd "$B/stdlib.jar" "META-INF/versions/*" module-info.class >/dev/null 2>&1 || true
echo "== dx"; JAVA_TOOL_OPTIONS=-Xmx2g dalvik-exchange --dex --min-sdk-version=26 --output="$B/dex/classes.dex" "$B/app.jar" "$B/stdlib.jar" "$ROOT/libs/shizuku-api.jar" 2>&1 | grep -v '^Picked up' || true
echo "== desugar remaining invokedynamic lambda sites (stdlib comparators etc.)"
(cd "$B/dex" && zip -q t.apk classes.dex && LUNAR_APK="$B/dex/t.apk" python3 "$ROOT/tools/dex-hotfix/desugar.py" | tail -3 && mv classes.fixed.dex classes.dex && rm -f t.apk)
echo "== DEX gate"; (cd "$B/dex" && zip -q g.apk classes.dex && python3 "$ROOT/tools/verify_dex.py" g.apk | tail -1 | tee "$B/gate.txt"; rm -f g.apk); grep -q PASS "$B/gate.txt" || { echo "GATE FAILED: refusing to package"; exit 1; }
sed "s|<manifest |<manifest package=\"com.lunaroptimizer.app\" android:versionCode=\"$VC\" android:versionName=\"$VN\" |" "$SRC/AndroidManifest.xml" > "$B/AndroidManifest.xml"
aapt package -f -M "$B/AndroidManifest.xml" -S "$SRC/res" -A "$SRC/assets" -I "$AJ" --min-sdk-version 30 --target-sdk-version 34 -F "$B/base.apk"
(cd "$B/dex" && aapt add -k "$B/base.apk" classes.dex >/dev/null)
zipalign -f -p 4 "$B/base.apk" "$ROOT/LunarOptimizer-$VN-unsigned-aligned.apk"
if [ -n "${KEYSTORE:-}" ]; then
  apksigner sign --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true --ks "$KEYSTORE" --ks-key-alias "${KS_ALIAS:-lunar}" --ks-pass "pass:${KS_PASS:-android}" --key-pass "pass:${KS_PASS:-android}" --out "$ROOT/LunarOptimizer-$VN.apk" "$ROOT/LunarOptimizer-$VN-unsigned-aligned.apk"
  apksigner verify --verbose --print-certs "$ROOT/LunarOptimizer-$VN.apk" | grep -E "Verifies|SHA-256|Number of signers"
else
  echo "!! No KEYSTORE given: signing with a THROWAWAY test key. That APK cannot update your installed Lunar Optimizer."
  T="${TEST_KEYSTORE:-$B/test.keystore}"; [ -f "$T" ] || keytool -genkeypair -keystore "$T" -storepass android -keypass android -alias lunar -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Lunar throwaway test key" >/dev/null 2>&1
  apksigner sign --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true --ks "$T" --ks-pass pass:android --key-pass pass:android --out "$ROOT/LunarOptimizer-$VN-TESTKEY.apk" "$ROOT/LunarOptimizer-$VN-unsigned-aligned.apk"
  apksigner verify --verbose --print-certs "$ROOT/LunarOptimizer-$VN-TESTKEY.apk" | grep -E "Verifies|SHA-256|Number of signers"
fi
ls -la "$ROOT"/LunarOptimizer-$VN*.apk
