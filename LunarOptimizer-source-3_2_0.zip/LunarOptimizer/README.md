# Lunar Optimizer 2.0.0
Native Kotlin Android app for Xiaomi 14 / HyperOS 3. Shizuku-level tweaks, Debloat, live telemetry, Lunar Boost. No root, no accounts, no analytics.

Build: `./build.sh` (kotlinc + aapt + dx + zipalign + apksigner; `TC` = folder with kotlinc/, android.jar API 34, stdlib-clean.jar).
`libs/shizuku-api.jar` is RikkaApps/Shizuku-API (MIT) compiled from source. Gradle files are provided but untested.
Tests: `tests/ClassifyTest.kt` (package risk rules).
