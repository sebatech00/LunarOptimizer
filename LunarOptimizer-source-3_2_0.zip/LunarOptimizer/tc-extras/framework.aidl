parcelable android.os.Bundle;
parcelable android.os.ParcelFileDescriptor;
parcelable android.content.ComponentName;
parcelable android.content.Intent;
