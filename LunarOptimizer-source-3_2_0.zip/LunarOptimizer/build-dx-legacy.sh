#!/usr/bin/env bash
# Toolchain-light build (no Gradle): kotlinc + aapt + dx + zipalign + apksigner.
# Needs: JDK 17+, Kotlin compiler 2.x, android.jar (API 34), aapt, dalvik-exchange, zipalign, apksigner.
set -euo pipefail
TC=${TC:-/home/claude/tc}; ROOT=$(cd "$(dirname "$0")" && pwd); B=$ROOT/build; SRC=$ROOT/app/src/main
export PATH=$TC/kotlinc/bin:$PATH
rm -rf "$B"; mkdir -p "$B/classes" "$B/dex"
kotlinc "$SRC"/java/com/lunaroptimizer/app/*.kt -cp "$TC/android.jar:$ROOT/libs/shizuku-api.jar" -jvm-target 1.8 -Xlambdas=class -Xsam-conversions=class -Xstring-concat=inline \
  -no-reflect -nowarn -d "$B/classes" > "$B/kotlinc.log" 2>&1 || { grep -E "error" -A2 "$B/kotlinc.log" | head -60; echo "KOTLIN COMPILE FAILED"; exit 1; }
(cd "$B/classes" && jar cf ../app.jar .)
dalvik-exchange --dex --min-sdk-version=26 --output="$B/dex/classes.dex" "$B/app.jar" "$TC/stdlib-clean.jar" "$ROOT/libs/shizuku-api.jar"
sed 's|<manifest |<manifest package="com.lunaroptimizer.app" android:versionCode="13" android:versionName="3.0.2" |' "$SRC/AndroidManifest.xml" > "$B/AndroidManifest.xml"
aapt package -f -M "$B/AndroidManifest.xml" -S "$SRC/res" -A "$SRC/assets" -I "$TC/android.jar" --min-sdk-version 30 --target-sdk-version 34 -F "$B/base.apk"
(cd "$B/dex" && aapt add -k "$B/base.apk" classes.dex >/dev/null)
zipalign -f -p 4 "$B/base.apk" "$B/aligned.apk"
[ -f "$ROOT/lunar-debug.keystore" ] || keytool -genkeypair -keystore "$ROOT/lunar-debug.keystore" -storepass android -keypass android -alias lunar -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Lunar Optimizer Debug" >/dev/null 2>&1
apksigner sign --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true --ks "$ROOT/lunar-debug.keystore" --ks-pass pass:android --key-pass pass:android --out "$ROOT/LunarOptimizer-3.0.2.apk" "$B/aligned.apk"
apksigner verify --verbose "$ROOT/LunarOptimizer-3.0.2.apk" | head -4
ls -la "$ROOT/LunarOptimizer-3.0.2.apk"
