#!/usr/bin/env bash
# Signs the unsigned-aligned APK with the key the installed app already uses (~/.android/debug.keystore) so it updates in place.
set -euo pipefail
IN=${1:?usage: sign-with-debug-key.sh LunarOptimizer-X-unsigned-aligned.apk}; OUT=${IN/-unsigned-aligned/}
AS=$(ls /opt/android-sdk/build-tools/*/apksigner | tail -1)
"$AS" sign --ks ~/.android/debug.keystore --ks-key-alias androiddebugkey --ks-pass pass:android --v2-signing-enabled true --v3-signing-enabled true --out "$OUT" "$IN"
"$AS" verify --print-certs "$OUT" | grep -E "SHA-256|Verifies"; echo "signed: $OUT  (install: adb install -r $OUT)"
