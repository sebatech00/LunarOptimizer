#!/usr/bin/env bash
# Rebuilds the "3.0.3 lambda-fix" APK from a 3.0.2 APK + the original keystore, with no compiler.
# It desugars the 72 invokedynamic lambda sites in classes.dex (what D8 would do), bumps versionCode/Name,
# re-signs (v2+v3) with the ORIGINAL key, and runs every check. Pure Python 3 + `cryptography`.
# Usage: LUNAR_APK=LunarOptimizer-3.0.2.apk LUNAR_KEYSTORE=lunar-debug.keystore tools/dex-hotfix/hotfix.sh
set -euo pipefail
: "${LUNAR_APK:?path to the 3.0.2 APK}"; : "${LUNAR_KEYSTORE:?path to the original keystore (PKCS12, password android)}"
export LUNAR_APK LUNAR_KEYSTORE; H=$(cd "$(dirname "$0")" && pwd)
python3 "$H/desugar.py"; python3 "$H/dexcheck.py"; python3 "$H/verify_equiv.py"; python3 "$H/emulate.py"; python3 "$H/make_apk.py"
for f in LunarOptimizer-3.0.2-lambdafix.apk LunarOptimizer-3.0.3-lambdafix.apk; do python3 "$H/../verify_dex.py" $f | tail -1; done
sha256sum LunarOptimizer-3.0.*-lambdafix.apk
