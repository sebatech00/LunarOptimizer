import os
HERE = os.path.dirname(os.path.abspath(__file__))
APK = os.environ.get('LUNAR_APK', 'LunarOptimizer-3.0.2.apk')
KS = os.environ.get('LUNAR_KEYSTORE', 'lunar-debug.keystore')
import sys, zipfile, collections
sys.path.insert(0, HERE); import dexmodel as dm
orig_b = zipfile.ZipFile(APK).read('classes.dex'); fix_b = open('classes.fixed.dex', 'rb').read()
A = dm.Reader(orig_b); B = dm.Reader(fix_b)
cc = lambda c: None if c is None else (c.regs, c.ins, c.outs, tuple(c.units), tuple(c.refs), tuple(c.tries), tuple(c.handlers), c.debug)
Bmap = {c['cls']: c for c in B.classes}
flag_changes = []; code_changes = []; other = []
for a in A.classes:
    b = Bmap[a['cls']]
    for k in ('acc', 'sup', 'ifs', 'src', 'ann', 'sv'):
        if a[k] != b[k]: other.append((a['cls'], k))
    if (a['data'] is None) != (b['data'] is None): other.append((a['cls'], 'data presence')); continue
    if a['data'] is None: continue
    for k in ('sf', 'if'):
        if a['data'][k] != b['data'][k]: other.append((a['cls'], k))
    for k in ('dm', 'vm'):
        la, lb = a['data'][k], b['data'][k]
        if len(la) != len(lb): other.append((a['cls'], k + ' length')); continue
        for ea, eb in zip(la, lb):
            if ea[0] != eb[0]: other.append((a['cls'], 'method order')); continue
            if ea[1] != eb[1]:
                assert ea[1] & 2 and (ea[1] & ~2) == eb[1], "unexpected flag change"; flag_changes.append(ea[0])
            ca, cb = cc(ea[2]), cc(eb[2])
            def sym(c):
                if c is None: return None
                u = list(c[3])
                for p_, kd, sy in c[4]:
                    u[p_] = 0
                    if kd == 'sj': u[p_+1] = 0
                return (c[0], c[1], c[2], tuple(u), c[4], c[5], c[6], c[7])
            if sym(ca) != sym(cb):
                # diff must be only: opcode low byte at call-site positions (0xfc->0x71, 0xfd->0x77) and refs cs->m
                def mask(code):
                    u = list(code[3])
                    for p_, kd, sy in code[4]:
                        u[p_] = 0
                        if kd == 'sj': u[p_+1] = 0
                    return u
                ua, ub = mask(ca), mask(cb); assert len(ua) == len(ub) and ca[:3] == cb[:3] and ca[5:] == cb[5:]
                pos_cs = {p for p, kd, s in ca[4] if kd == 'cs'}
                for i, (x, y) in enumerate(zip(ua, ub)):
                    if x != y: assert (i+1) in pos_cs and (x & 0xff00) == (y & 0xff00) and (x & 0xff, y & 0xff) in ((0xfc, 0x71), (0xfd, 0x77)), ("unexpected unit change", ea[0], i)
                for (p1, k1, s1), (p2, k2, s2) in zip(ca[4], cb[4]):
                    assert p1 == p2
                    if (k1, s1) != (k2, s2): assert k1 == 'cs' and k2 == 'm' and s2[0].endswith(b'LunarLambda$%d;' % s1[1]) or s2[1] == b'create', (k1, k2)
                code_changes.append(ea[0])
print("original classes:", len(A.classes), "| classes in fixed:", len(B.classes), "| added:", len(B.classes) - len(A.classes))
print("unexpected differences in original classes:", len(other), other[:5])
print("methods whose private flag was relaxed: %d (expected 72, all distinct: %s)" % (len(flag_changes), len(set(flag_changes)) == 72))
print("methods whose code changed: %d, containing 72 call sites; changes confined to call-site opcodes/refs: yes (asserted)" % len(code_changes))
print("fixed DEX still has call sites/method handles in map:", any(t in (7, 8) for t in [__import__('struct').unpack_from('<HHII', fix_b, B.map_off + 4 + 12*i)[0] for i in range(__import__('struct').unpack_from('<I', fix_b, B.map_off)[0])]))
