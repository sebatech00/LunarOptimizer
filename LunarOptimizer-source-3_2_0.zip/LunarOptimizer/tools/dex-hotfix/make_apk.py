import os
HERE = os.path.dirname(os.path.abspath(__file__))
APK = os.environ.get('LUNAR_APK', 'LunarOptimizer-3.0.2.apk')
KS = os.environ.get('LUNAR_KEYSTORE', 'lunar-debug.keystore')
import sys, struct, zipfile, io, hashlib
sys.path.insert(0, HERE); import apktool as A
from cryptography.hazmat.primitives.serialization import Encoding
ORIG = APK

def axml_strings(b):
    # string pool chunk right after the 8-byte XML header
    t, hs, size, n, sn, flags, sstart, ystart = struct.unpack_from('<HHIIIIII', b, 8)
    assert t == 1; utf8 = bool(flags & 0x100); offs = struct.unpack_from('<%dI' % n, b, 8 + hs); base = 8 + sstart; out = []
    for o in offs:
        p = base + o
        if utf8:
            l = b[p]; p += 1 + (1 if l & 0x80 else 0)           # char length
            bl = b[p]; p += 1
            if bl & 0x80: bl = ((bl & 0x7f) << 8) | b[p]; p += 1
            out.append((p, bl, b[p:p+bl].decode('utf-8', 'replace')))
        else:
            l = struct.unpack_from('<H', b, p)[0]; out.append((p + 2, l * 2, b[p+2:p+2+l*2].decode('utf-16le')))
    return out, 8 + size, utf8

def manifest_attrs(b):
    strs, pos, utf8 = axml_strings(b); o = pos; res = []
    while o < len(b):
        t, hs, size = struct.unpack_from('<HHI', b, o)
        if t == 0x0102:
            ns, name, astart, asize, acount = struct.unpack_from('<iiHHH', b, o + 16)
            if strs[name][2] == 'manifest':
                for k in range(acount):
                    ao = o + 16 + 20 + k * 20; ans, an, raw, sz, r0, dt, data = struct.unpack_from('<iiiHBBI', b, ao)
                    res.append((strs[an][2], ao, raw, dt, data, strs))
                return res
        o += size
    raise ValueError("manifest element not found")

def patch_manifest(b, old_code, old_name, new_code, new_name):
    b = bytearray(b); attrs = manifest_attrs(bytes(b)); done = set()
    for name, ao, raw, dt, data, strs in attrs:
        if name == 'versionCode':
            assert dt == 0x10 and data == old_code, (dt, data); struct.pack_into('<I', b, ao + 16, new_code); done.add(name)
        if name == 'versionName':
            assert dt == 0x03 and strs[data][2] == old_name; p, ln, _ = strs[data]; assert len(old_name) == len(new_name)
            assert sum(1 for s in strs if s[2] == old_name) == 1
            if (len(strs[data]) and True):
                enc = old_name.encode('utf-16le') if ln == len(old_name) * 2 else old_name.encode()
                assert bytes(b[p:p+ln]) == enc; b[p:p+ln] = new_name.encode('utf-16le') if ln == len(old_name) * 2 else new_name.encode(); done.add(name)
    assert done == {'versionCode', 'versionName'}, done
    return bytes(b)

orig = open(ORIG, 'rb').read(); zin = zipfile.ZipFile(io.BytesIO(orig))
man0 = zin.read('AndroidManifest.xml')
print("original manifest:", {n: (dt, d if dt == 0x10 else strs[d][2]) for n, ao, raw, dt, d, strs in manifest_attrs(man0) if n in ('package', 'versionCode', 'versionName', 'minSdkVersion', 'targetSdkVersion')})
dex = open('classes.fixed.dex', 'rb').read()
key, cert, _ = A.load_key(KS); cder = cert.public_bytes(Encoding.DER)
man1 = patch_manifest(man0, 13, '3.0.2', 14, '3.0.3')
print("variant B manifest:", {n: (dt, d if dt == 0x10 else strs[d][2]) for n, ao, raw, dt, d, strs in manifest_attrs(man1) if n in ('package', 'versionCode', 'versionName')},
      "| bytes changed:", sum(1 for x, y in zip(man0, man1) if x != y))
for name, man in (('LunarOptimizer-3.0.2-lambdafix.apk', man0), ('LunarOptimizer-3.0.3-lambdafix.apk', man1)):
    unsigned = A.build_zip(orig, {'classes.dex': dex, 'AndroidManifest.xml': man})
    signed = A.sign_apk(unsigned, key, cder, (24, 2147483647)); open(name, 'wb').write(signed)
    print("wrote %s (%d bytes)" % (name, len(signed)))
