import os
HERE = os.path.dirname(os.path.abspath(__file__))
APK = os.environ.get('LUNAR_APK', 'LunarOptimizer-3.0.2.apk')
KS = os.environ.get('LUNAR_KEYSTORE', 'lunar-debug.keystore')
import struct, hashlib, zipfile, io, sys
from cryptography.hazmat.primitives.serialization import pkcs12, Encoding, PublicFormat
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
MAGIC = b'APK Sig Block 42'; ALG = 0x0103
le32 = lambda n: struct.pack('<I', n); le64 = lambda n: struct.pack('<Q', n); lp = lambda b: le32(len(b)) + b

def split(apk):
    eocd = apk.rfind(b'PK\x05\x06'); cd_size, cd_off = struct.unpack_from('<II', apk, eocd + 12)
    bs = cd_off
    if apk[cd_off-16:cd_off] == MAGIC: bs = cd_off - struct.unpack_from('<Q', apk, cd_off - 24)[0] - 8
    return apk[:bs], apk[cd_off:cd_off+cd_size], bytearray(apk[eocd:]), bs, cd_off, eocd

def digest(sec1, sec2, eocd_with_offset):
    ds = []
    for sec in (sec1, sec2, bytes(eocd_with_offset)):
        for i in range(0, len(sec), 1 << 20):
            c = sec[i:i + (1 << 20)]; ds.append(hashlib.sha256(b'\xa5' + le32(len(c)) + c).digest())
    return hashlib.sha256(b'\x5a' + le32(len(ds)) + b''.join(ds)).digest()

def apk_digest(apk):
    s1, s2, e, bs, cd_off, eo = split(apk); e = bytearray(e); struct.pack_into('<I', e, 16, len(s1)); return digest(s1, s2, e)

def pairs_of(apk):
    s1, s2, e, bs, cd_off, eo = split(apk)
    if bs == cd_off: return {}
    out = {}; o = bs + 8; end = cd_off - 24
    while o < end:
        n = struct.unpack_from('<Q', apk, o)[0]; i = struct.unpack_from('<I', apk, o + 8)[0]; out[i] = apk[o+12:o+8+n]; o += 8 + n
    return out

def signer_blocks(dig, key, cert_der, sdk=(None, None)):
    pub = cert_pub = None
    digs = lp(lp(le32(ALG) + lp(dig))); certs = lp(lp(cert_der))
    def sig(sd): return key.sign(sd, padding.PKCS1v15(), hashes.SHA256())
    pubder = key.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
    out = {}
    sd2 = digs + certs + lp(lp(le32(0xbeeff00d) + le32(3))) + lp(b'')   # stripping-protection attribute + trailing reserved element, as apksigner emits
    sigs2 = lp(lp(le32(ALG) + lp(sig(sd2))))
    out[0x7109871a] = lp(lp(lp(sd2) + sigs2 + lp(pubder)))
    mn, mx = sdk
    sd3 = digs + certs + le32(mn) + le32(mx) + lp(b'')
    sigs3 = lp(lp(le32(ALG) + lp(sig(sd3))))
    out[0xf05368c0] = lp(lp(lp(sd3) + le32(mn) + le32(mx) + sigs3 + lp(pubder)))
    return out

def build_block(pairs, pad_to=4096):
    body = b''.join(le64(4 + len(v)) + le32(i) + v for i, v in pairs)
    total = len(body) + 8 + 8 + 16
    pad = (-(total + 12)) % pad_to if pad_to else 0     # + 12 for the padding pair's own header
    # padding pair: 8 (len) + 4 (id) + value; make total multiple of pad_to
    need = (-total) % pad_to
    if need:
        if need < 12: need += pad_to
        body += le64(4 + need - 12) + le32(0x42726577) + b'\0' * (need - 12)
    size = len(body) + 8 + 16
    return le64(size) + body + le64(size) + MAGIC

def load_key(path, pw=b'android'):
    return pkcs12.load_key_and_certificates(open(path, 'rb').read(), pw)

def verify(apk):
    from cryptography import x509
    s1, s2, e, bs, cd_off, eo = split(apk); dig = apk_digest(apk); pr = pairs_of(apk); res = {}
    for pid, name in ((0x7109871a, 'v2'), (0xf05368c0, 'v3')):
        if pid not in pr: res[name] = 'absent'; continue
        v = pr[pid]; n = struct.unpack_from('<I', v, 0)[0]; sg = v[4:4+n]; n2 = struct.unpack_from('<I', sg, 0)[0]; signer = sg[4:4+n2]
        o = 0
        def rd():
            nonlocal o
            l = struct.unpack_from('<I', signer, o)[0]; x = signer[o+4:o+4+l]; o += 4 + l; return x
        signed = rd()
        if name == 'v3': o += 8
        sigs = rd(); pub = rd()
        # inside signed data
        digs = signed[4:4+struct.unpack_from('<I', signed, 0)[0]]; rec_len = struct.unpack_from('<I', digs, 0)[0]; rec = digs[4:4+rec_len]
        alg = struct.unpack_from('<I', rec, 0)[0]; dl = struct.unpack_from('<I', rec, 4)[0]; sd = rec[8:8+dl]
        p = 4 + struct.unpack_from('<I', signed, 0)[0]; cl = struct.unpack_from('<I', signed, p)[0]; certs = signed[p+4:p+4+cl]; cert = certs[4:4+struct.unpack_from('<I', certs, 0)[0]]
        rl = struct.unpack_from('<I', sigs, 0)[0]; sr = sigs[4:4+rl]; assert struct.unpack_from('<I', sr, 0)[0] == ALG; sl = struct.unpack_from('<I', sr, 4)[0]; sigb = sr[8:8+sl]
        c = x509.load_der_x509_certificate(cert); c.public_key().verify(sigb, signed, padding.PKCS1v15(), hashes.SHA256())
        res[name] = ('OK', sd == dig, c.fingerprint(hashes.SHA256()).hex())
    return res

def build_zip(orig_apk_bytes, replace):
    zin = zipfile.ZipFile(io.BytesIO(orig_apk_bytes)); buf = io.BytesIO(); zo = zipfile.ZipFile(buf, 'w')
    for zi in zin.infolist():
        data = replace.get(zi.filename, zin.read(zi.filename))
        ni = zipfile.ZipInfo(zi.filename, zi.date_time); ni.compress_type = zi.compress_type; ni.external_attr = zi.external_attr; ni.create_system = zi.create_system
        if ni.compress_type == zipfile.ZIP_STORED:
            hdr = 30 + len(ni.filename.encode()); pad = (-(buf.tell() + hdr)) % 4; ni.extra = b'\0' * pad
        zo.writestr(ni, data)
    zo.close(); return buf.getvalue()

def sign_apk(unsigned_zip, key, cert_der, sdk):
    s1, s2, e, bs, cd_off, eo = split(unsigned_zip); assert bs == cd_off
    e = bytearray(e); struct.pack_into('<I', e, 16, len(s1)); dig = digest(s1, s2, e)
    sb = signer_blocks(dig, key, cert_der, sdk); block = build_block(sorted(sb.items(), key=lambda kv: kv[0] != 0x7109871a))
    e2 = bytearray(unsigned_zip[eo:]); struct.pack_into('<I', e2, 16, len(s1) + len(block))
    return s1 + block + s2 + bytes(e2)
