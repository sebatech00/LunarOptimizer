import os
HERE = os.path.dirname(os.path.abspath(__file__))
APK = os.environ.get('LUNAR_APK', 'LunarOptimizer-3.0.2.apk')
KS = os.environ.get('LUNAR_KEYSTORE', 'lunar-debug.keystore')
import sys, struct, zlib, hashlib, re
sys.path.insert(0, HERE); import dexmodel as dm
from dexmodel import uleb, sleb, mkey, W, KINDS, payload_width
def check(b):
    errs = []; E = errs.append
    magic, = struct.unpack_from('8s', b, 0)
    if magic[:4] != b'dex\n': E("magic")
    fsz, hsz, endian, lsz, loff, moff = struct.unpack_from('<6I', b, 0x20)
    if fsz != len(b): E("file_size %d != %d" % (fsz, len(b)))
    if hsz != 0x70 or endian != 0x12345678: E("header")
    if zlib.adler32(b[12:]) & 0xffffffff != struct.unpack_from('<I', b, 8)[0]: E("checksum")
    if hashlib.sha1(b[32:]).digest() != b[12:32]: E("sha1")
    sn, so, tn, to, pn, po, fn, fo, mn, mo, cn, co = struct.unpack_from('<12I', b, 0x38); dsz, doff = struct.unpack_from('<II', b, 0x68)
    if doff + dsz != fsz: E("data_size/off")
    # map
    n = struct.unpack_from('<I', b, moff)[0]; items = [struct.unpack_from('<HHII', b, moff + 4 + 12*i) for i in range(n)]
    ALIGN = {0x1001: 4, 0x1002: 4, 0x1003: 4, 0x2001: 4, 0x2006: 4, 0x1000: 4}
    last = -1
    for t, _, c, o in items:
        if o < last: E("map order at type %x" % t)
        last = o
        if o % ALIGN.get(t, 1): E("map misaligned type %x off %d" % (t, o))
        if o >= fsz: E("map offset beyond file")
    if items[-1][0] != 0x1000 or items[-1][3] != moff: E("map_list not last/consistent")
    mp = {t: (c, o) for t, _, c, o in items}
    for t, cnt in ((1, sn), (2, tn), (3, pn), (4, fn), (5, mn), (6, cn)):
        if mp.get(t, (0,))[0] != cnt: E("map count type %d" % t)
    # strings
    S = []
    for i in range(sn):
        off = struct.unpack_from('<I', b, so + 4*i)[0]
        if off < doff or off >= fsz: E("string off"); break
        ul, p = uleb(b, off); e = b.index(b'\0', p); raw = b[p:e]; k = mkey(raw)
        if len(k) != ul: E("string %d utf16 size %d != %d" % (i, ul, len(k)))
        S.append((k, raw))
    for i in range(1, len(S)):
        if not S[i-1][0] < S[i][0]: E("strings not strictly ascending at %d" % i); break
    strs = [x[1] for x in S]
    cls_re = re.compile(rb'^L[^;\[\x00]+;$'); 
    def valid_desc(d): return bool(re.match(rb'^(V|[ZBSCIJFD]|\[+([ZBSCIJFD]|L[^;\[\x00]+;)|L[^;\[\x00]+;)$', d))
    T = [struct.unpack_from('<I', b, to + 4*i)[0] for i in range(tn)]
    for i in range(1, tn):
        if not T[i-1] < T[i]: E("type_ids not strictly ascending"); break
    tdesc = [strs[x] for x in T]
    for d in tdesc:
        if not valid_desc(d): E("bad descriptor %r" % d); break
    def tlist(off):
        if not off: return ()
        if off % 4: E("type_list misaligned")
        k = struct.unpack_from('<I', b, off)[0]; return tuple(struct.unpack_from('<H', b, off + 4 + 2*j)[0] for j in range(k))
    P = []
    sh = lambda d: chr(d[0]) if d[:1] not in (b'L', b'[') else 'L'
    for i in range(pn):
        s_, r_, pl = struct.unpack_from('<3I', b, po + 12*i); ps = tlist(pl); P.append((r_, ps))
        want = (sh(tdesc[r_]) + "".join(sh(tdesc[x]) for x in ps)).encode()
        if strs[s_] != want: E("shorty mismatch proto %d" % i); break
    for i in range(1, pn):
        if not P[i-1] < P[i]: E("protos not strictly ascending"); break
    F = [struct.unpack_from('<HHI', b, fo + 8*i) for i in range(fn)]
    for i in range(1, fn):
        a, c = F[i-1], F[i]
        if not (a[0], a[2], a[1]) < (c[0], c[2], c[1]): E("fields not ascending"); break
    M = [struct.unpack_from('<HHI', b, mo + 8*i) for i in range(mn)]
    for i in range(1, mn):
        a, c = M[i-1], M[i]
        if not (a[0], a[2], a[1]) < (c[0], c[2], c[1]): E("methods not ascending"); break
    for c, p, n_ in M:
        if tdesc[c][:1] not in (b'L', b'['): E("method class not class type")
    # classes
    seen = {}; CD = []
    for i in range(cn):
        ci, acc, sc, io, sf, ao, cdo, sv = struct.unpack_from('<8I', b, co + 32*i)
        if ci in seen: E("duplicate class_def"); 
        seen[ci] = i
        for dep in ([sc] if sc != dm.NO else []) + list(tlist(io)):
            if dep in seen and seen[dep] >= i: E("class %d defined before its supertype" % i)
        CD.append((ci, acc, sc, io, cdo))
    pending = {}   # supertypes defined later
    for i, (ci, acc, sc, io, cdo) in enumerate(CD):
        for dep in ([sc] if sc != dm.NO else []) + list(tlist(io)):
            if dep in seen and seen[dep] > i: E("supertype of class %d appears later" % i)
    code_range = (mp[0x2001][1], 10**12) if 0x2001 in mp else (0, 0); ncode = 0
    cbound = [x for x in items if x[0] == 0x2001]
    def inmap(t, o):
        if t not in mp: return False
        idx = [x for x in items if x[0] == t][0]; nxt = [x for x in items if x[3] > idx[3]]; end = min(x[3] for x in nxt)
        return idx[3] <= o < end
    codeseen = set(); nins = 0
    for ci, acc, sc, io, cdo in CD:
        if not cdo: continue
        if not inmap(0x2000, cdo): E("class_data offset outside section")
        sfn, o = uleb(b, cdo); ifn, o = uleb(b, o); dmn, o = uleb(b, o); vmn, o = uleb(b, o)
        for cnt, kind in ((sfn, 'f'), (ifn, 'f')):
            idx = -1
            for k in range(cnt):
                d, o = uleb(b, o); _, o = uleb(b, o)
                if k and d == 0: E("field idx diff 0")
                idx = idx + d if k else d
                if F[idx][0] != ci: E("field class mismatch")
        for cnt in (dmn, vmn):
            idx = -1
            for k in range(cnt):
                d, o = uleb(b, o); fl, o = uleb(b, o); code, o = uleb(b, o)
                if k and d == 0: E("method idx diff 0")
                idx = idx + d if k else d
                if M[idx][0] != ci: E("method class mismatch")
                if fl & (0x400 | 0x100):
                    if code: E("abstract/native with code")
                elif not code: E("concrete method without code")
                if code:
                    if code % 4 or not inmap(0x2001, code): E("code offset"); continue
                    regs, ins, outs, nt, dbg, isz = struct.unpack_from('<4HII', b, code)
                    if ins > regs: E("ins > regs")
                    u = struct.unpack_from('<%dH' % isz, b, code + 16); i = 0
                    proto = P[M[idx][1]]; pcount = len(proto[1]) + (0 if fl & 0x8 else 1)
                    pregs = sum(2 if tdesc[x] in (b'J', b'D') else 1 for x in proto[1]) + (0 if fl & 0x8 else 1)
                    if pregs != ins: E("ins_size %d != proto regs %d (method %d)" % (ins, pregs, idx))
                    while i < isz:
                        w = u[i]; op = w & 0xff
                        if op == 0 and w in (0x100, 0x200, 0x300): i += payload_width(u, i); continue
                        for off_, kind in KINDS.get(op, ()):
                            lim = {'s': sn, 't': tn, 'f': fn, 'm': mn, 'p': pn, 'cs': 0, 'mh': 0, 'sj': sn}[kind]
                            v = u[i+1] | (u[i+2] << 16) if kind == 'sj' else u[i+off_]
                            if v >= lim: E("operand index out of range op %x" % op)
                            if kind in ('cs', 'mh'): E("call-site/method-handle operand remains")
                        if op in (0x6e, 0x6f, 0x70, 0x71, 0x72):
                            tgt = M[u[i+1]]; tp = P[tgt[1]]; need = sum(2 if tdesc[x] in (b'J', b'D') else 1 for x in tp[1]) + (0 if op == 0x71 else 1)
                            if (w >> 12) != need: E("invoke arg count %d != %d for op %x" % (w >> 12, need, op))
                            if need > outs: E("outs_size too small")
                        if op in (0x74, 0x75, 0x76, 0x77, 0x78):
                            tgt = M[u[i+1]]; tp = P[tgt[1]]; need = sum(2 if tdesc[x] in (b'J', b'D') else 1 for x in tp[1]) + (0 if op == 0x77 else 1)
                            if (w >> 8) != need: E("invoke/range arg count")
                        i += W[op]
                    if i != isz: E("insn stream desync")
                    codeseen.add(code); nins += 1
    if len(codeseen) != mp[0x2001][0]: E("code items referenced %d vs map %d" % (len(codeseen), mp[0x2001][0]))
    return errs, dict(strings=sn, types=tn, protos=pn, fields=fn, methods=mn, classes=cn, code_items=len(codeseen))
if __name__ == '__main__':
    import zipfile
    for name, b in (('ORIGINAL (reference, must be clean under my checker)', zipfile.ZipFile(APK).read('classes.dex')), ('FIXED', open('classes.fixed.dex', 'rb').read())):
        e, st = check(b); print("%-55s %s | %s" % (name, "OK" if not e else "%d ERRORS" % len(e), st))
        for x in e[:12]: print("    ", x)
