import os
HERE = os.path.dirname(os.path.abspath(__file__))
APK = os.environ.get('LUNAR_APK', 'LunarOptimizer-3.0.2.apk')
KS = os.environ.get('LUNAR_KEYSTORE', 'lunar-debug.keystore')
import sys, zipfile
sys.path.insert(0, HERE); import dexmodel as dm
B = dm.Reader(open('classes.fixed.dex', 'rb').read()); UN = object()
newc = [c for c in B.classes if b'LunarLambda$' in c['cls']]
OBJ_INIT = (b'Ljava/lang/Object;', b'<init>', (b'V', ()))
BOXV = {(b'Ljava/lang/Integer;', b'valueOf'), (b'Ljava/lang/Boolean;', b'valueOf'), (b'Ljava/lang/Long;', b'valueOf')}
BOXU = {b'intValue', b'booleanValue', b'longValue'}
class Obj:
    def __init__(s, t): s.t = t; s.f = {}
codes = {}
for c in B.classes:
    if c['data']:
        for l in (c['data']['dm'], c['data']['vm']):
            for e in l:
                if e[2] is not None and b'LunarLambda$' in e[0][0]: codes[e[0]] = e
log = []
def run(msym, args):
    code = codes[msym][2]; regs = [UN] * code.regs; base = code.regs - code.ins
    assert len(args) == code.ins, (msym, len(args), code.ins)
    for i, v in enumerate(args): regs[base + i] = v
    refs = {p: (k, s) for p, k, s in code.refs}; u = code.units; pc = 0; res = None
    def R(i):
        assert regs[i] is not UN, "read of uninitialized register v%d in %r" % (i, msym[1]); return regs[i]
    while True:
        w = u[pc]; op = w & 0xff; A_ = (w >> 8) & 0xf; B_ = w >> 12; AA = w >> 8
        if op == 0x0e: return None
        if op in (0x0f, 0x10, 0x11): return R(AA)
        if op == 0x07: regs[A_] = R(B_); pc += 1; continue
        if op in (0x0a, 0x0b, 0x0c): regs[AA] = res; (op == 0x0b) and regs.__setitem__(AA + 1, res); pc += 1; continue
        k, sym = refs[pc + 1]
        if op == 0x22: regs[AA] = Obj(sym); pc += 2; continue
        if op == 0x1f:
            v = R(AA)
            if sym == b'Ljava/lang/Integer;': assert isinstance(v, int) and not isinstance(v, bool), ("bad Integer cast", v)
            if sym == b'Ljava/lang/Boolean;': assert isinstance(v, bool), ("bad Boolean cast", v)
            pc += 2; continue
        if op in (0x52, 0x54, 0x55): regs[A_] = R(B_).f[sym[2]]; pc += 2; continue
        if op in (0x59, 0x5b, 0x5c): R(B_).f[sym[2]] = R(A_); pc += 2; continue
        if op == 0x70 or op == 0x6e or op == 0x71:
            n = w >> 12; rr = [(u[pc+2] >> (4*i)) & 0xf for i in range(4)] + [(w >> 8) & 0xf]; a = [R(x) for x in rr[:n]]
            if op == 0x70 and sym == OBJ_INIT: pass
            elif op == 0x6e: assert sym[1] in BOXU; res = a[0]
            elif op == 0x71 and (sym[0], sym[1]) in BOXV: res = a[0]
            else: log.append((sym, a)); res = ret_for(sym)
            pc += 3; continue
        if op in (0x76, 0x77):
            n = AA; first = u[pc+2]; a = [R(first + i) for i in range(n)]
            if op == 0x76: run(sym, a)
            else: log.append((sym, a)); res = ret_for(sym)
            pc += 3; continue
        raise AssertionError("unemulated opcode %x" % op)
cnt = [0]
def ret_for(sym):
    r = sym[2][0]; cnt[0] += 1
    if r in (b'I',): return 42
    if r == b'Z': return True
    if r == b'J': return 99
    return ('ret', cnt[0])
fails = 0; checked = 0
import desugar
sites = desugar.read_sites(dm.Reader(zipfile.ZipFile(APK).read('classes.dex')))
for n, st in enumerate(sites):
    cdesc = [c['cls'] for c in newc if c['cls'].endswith(b'LunarLambda$%d;' % n)][0]
    cap = list(st['fac'][1]); impl = st['impl']; iparams = list(impl[2][1]); sam_ret, sam_params = st['sam']
    capv = [7 if t == b'I' else (True if t == b'Z' else ('cap', i)) for i, t in enumerate(cap)]
    create_m = (cdesc, b'create', (st['fac'][0], tuple(cap))); sam_m = (cdesc, st['name'], st['sam'])
    o = run(create_m, capv); assert isinstance(o, Obj) and o.t == cdesc
    samv = []
    for j in range(len(sam_params)):
        t = iparams[len(cap) + j]; samv.append(5 if t == b'I' else (True if t == b'Z' else ('arg', j)))
    log.clear(); out = run(sam_m, [o] + samv)
    ok = len(log) == 1 and log[0][0] == impl and log[0][1] == capv + samv
    iret = impl[2][0]
    if iret[:1] in (b'L', b'['): ok = ok and out == ('ret', cnt[0])
    elif iret == b'I': ok = ok and out == 42
    elif iret == b'Z': ok = ok and out is True
    elif iret == b'J': ok = ok and out == 99
    checked += 1; fails += (not ok)
    if not ok: print("FAIL site", n, impl, log, out)
print("adapters executed: %d, failures: %d (each: create -> SAM call -> impl got captured+converted args -> correct boxed/unboxed return; no uninitialized-register reads)" % (checked, fails))
