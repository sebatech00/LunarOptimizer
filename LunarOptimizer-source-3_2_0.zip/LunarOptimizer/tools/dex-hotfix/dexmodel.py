"""Symbolic DEX reader/writer (pure Python). All references are held as symbols so tables can grow."""
import struct, zlib, hashlib
NO = 0xffffffff

def uleb(b, o):
    r = s = 0
    while True:
        x = b[o]; o += 1; r |= (x & 0x7f) << s; s += 7
        if x < 0x80: return r, o
def sleb(b, o):
    r = s = 0
    while True:
        x = b[o]; o += 1; r |= (x & 0x7f) << s; s += 7
        if x < 0x80:
            if x & 0x40: r -= 1 << s
            return r, o
def wuleb(n):
    out = bytearray()
    while True:
        x = n & 0x7f; n >>= 7
        if n: out.append(x | 0x80)
        else: out.append(x); return bytes(out)
def wsleb(n):
    out = bytearray()
    while True:
        x = n & 0x7f; n >>= 7
        if (n == 0 and not x & 0x40) or (n == -1 and x & 0x40): out.append(x); return bytes(out)
        out.append(x | 0x80)

def mkey(bs):
    out = []; i = 0; n = len(bs)
    while i < n:
        c = bs[i]
        if c < 0x80: out.append(c); i += 1
        elif c & 0xe0 == 0xc0: out.append(((c & 0x1f) << 6) | (bs[i+1] & 0x3f)); i += 2
        else: out.append(((c & 0x0f) << 12) | ((bs[i+1] & 0x3f) << 6) | (bs[i+2] & 0x3f)); i += 3
    return tuple(out)

W = [1]*256
for op in (0x02,0x05,0x08,0x13,0x15,0x16,0x19,0x1a,0x1c,0x1f,0x20,0x22,0x23,0x29,0xfe,0xff): W[op] = 2
for op in (0x03,0x06,0x09,0x14,0x17,0x1b,0x24,0x25,0x26,0x2a,0x2b,0x2c,0xfc,0xfd): W[op] = 3
W[0x18] = 5
for op in range(0x2d, 0x3e): W[op] = 2
for op in range(0x44, 0x6e): W[op] = 2
for op in list(range(0x6e,0x73)) + list(range(0x74,0x79)): W[op] = 3
for op in range(0x90, 0xb0): W[op] = 2
for op in range(0xd0, 0xe3): W[op] = 2
W[0xfa] = W[0xfb] = 4
KINDS = {0x1a: [(1,'s')], 0x1b: [(1,'sj')], 0xfa: [(1,'m'),(3,'p')], 0xfb: [(1,'m'),(3,'p')], 0xfc: [(1,'cs')], 0xfd: [(1,'cs')], 0xfe: [(1,'mh')], 0xff: [(1,'p')]}
for op in (0x1c,0x1f,0x20,0x22,0x23,0x24,0x25): KINDS[op] = [(1,'t')]
for op in range(0x52, 0x6e): KINDS[op] = [(1,'f')]
for op in list(range(0x6e,0x73)) + list(range(0x74,0x79)): KINDS[op] = [(1,'m')]

def payload_width(u, i):
    w = u[i]
    if w == 0x0100: return u[i+1]*2 + 4
    if w == 0x0200: return u[i+1]*4 + 2
    return ((u[i+2] | (u[i+3] << 16)) * u[i+1] + 1) // 2 + 4

class Code:
    pass

class Model:
    pass

def shorty_char(d): return 'L' if d[:1] in (b'L', b'[') else d.decode()

class Reader:
    def __init__(s, b):
        s.b = b
        (s.map_off, sn, so, tn, to, pn, po, fn, fo, mn, mo, cn, co) = struct.unpack_from('<13I', b, 0x34)
        s.magic = b[:8]
        S = []
        for i in range(sn):
            off = struct.unpack_from('<I', b, so + 4*i)[0]; _, p = uleb(b, off); S.append(b[p:b.index(b'\0', p)])
        s.strs = S
        s.types = [S[struct.unpack_from('<I', b, to + 4*i)[0]] for i in range(tn)]
        s.protos = []
        for i in range(pn):
            _, rt, pl = struct.unpack_from('<3I', b, po + 12*i)
            s.protos.append((s.types[rt], s.typelist(pl)))
        s.fields = [(s.types[c], s.types[t], S[n]) for c, t, n in (struct.unpack_from('<HHI', b, fo + 8*i) for i in range(fn))]
        s.methods = [(s.types[c], S[n], s.protos[p]) for c, p, n in (struct.unpack_from('<HHI', b, mo + 8*i) for i in range(mn))]
        s.cache = {}
        s.classes = [s.read_class(struct.unpack_from('<8I', b, co + 32*i)) for i in range(cn)]
    def typelist(s, off):
        if not off: return ()
        n = struct.unpack_from('<I', s.b, off)[0]
        return tuple(s.types[struct.unpack_from('<H', s.b, off + 4 + 2*k)[0]] for k in range(n))
    def memo(s, key, fn):
        if key not in s.cache: s.cache[key] = fn()
        return s.cache[key]
    def value(s, o):
        b = s.b; h = b[o]; o += 1; t = h & 0x1f; a = h >> 5
        if t in (0x00,0x02,0x03,0x04,0x06,0x10,0x11): return ('raw', t, a, b[o:o+a+1]), o + a + 1
        if t in (0x15,0x16,0x17,0x18,0x19,0x1a,0x1b):
            idx = int.from_bytes(b[o:o+a+1], 'little'); o += a + 1
            if t == 0x15: return ('mtype', s.protos[idx]), o
            if t == 0x16: raise ValueError("method handle value unsupported")
            return ({0x17:('str', s.strs), 0x18:('type', s.types), 0x19:('field', s.fields), 0x1a:('method', s.methods), 0x1b:('enum', s.fields)}[t][0], ({0x17:s.strs,0x18:s.types,0x19:s.fields,0x1a:s.methods,0x1b:s.fields}[t])[idx]), o
        if t == 0x1c:
            n, o = uleb(b, o); v = []
            for _ in range(n): x, o = s.value(o); v.append(x)
            return ('array', v), o
        if t == 0x1d:
            a_, o = s.annotation(o); return ('ann', a_), o
        return ('raw', t, a, b''), o
    def annotation(s, o):
        b = s.b; ti, o = uleb(b, o); n, o = uleb(b, o); els = []
        for _ in range(n):
            ni, o = uleb(b, o); v, o = s.value(o); els.append((s.strs[ni], v))
        return (s.types[ti], els), o
    def aitem(s, off):
        def f():
            vis = s.b[off]; a, _ = s.annotation(off + 1); return ('item', vis, a)
        return s.memo(('ai', off), f)
    def aset(s, off):
        if not off: return None
        def f():
            n = struct.unpack_from('<I', s.b, off)[0]
            return tuple(s.aitem(struct.unpack_from('<I', s.b, off + 4 + 4*k)[0]) for k in range(n))
        return s.memo(('as', off), f)
    def asetref(s, off):
        def f():
            n = struct.unpack_from('<I', s.b, off)[0]
            return tuple(s.aset(struct.unpack_from('<I', s.b, off + 4 + 4*k)[0]) for k in range(n))
        return s.memo(('ar', off), f)
    def adir(s, off):
        if not off: return None
        def f():
            b = s.b; co, fs, ms, ps = struct.unpack_from('<4I', b, off); o = off + 16
            fa = []; ma = []; pa = []
            for _ in range(fs): fi, ao = struct.unpack_from('<2I', b, o); fa.append((s.fields[fi], s.aset(ao))); o += 8
            for _ in range(ms): mi, ao = struct.unpack_from('<2I', b, o); ma.append((s.methods[mi], s.aset(ao))); o += 8
            for _ in range(ps): mi, ao = struct.unpack_from('<2I', b, o); pa.append((s.methods[mi], s.asetref(ao))); o += 8
            return {'cls': s.aset(co), 'f': fa, 'm': ma, 'p': pa}
        return s.memo(('ad', off), f)
    def debug(s, off):
        if not off: return None
        def f():
            b = s.b; o = off; ls, o = uleb(b, o); ps, o = uleb(b, o); params = []
            for _ in range(ps):
                v, o = uleb(b, o); params.append(None if v == 0 else s.strs[v-1])
            ops = []
            while True:
                op = b[o]; o += 1
                if op == 0: break
                elif op == 1: v, o = uleb(b, o); ops.append(('pc', v))
                elif op == 2: v, o = sleb(b, o); ops.append(('line', v))
                elif op in (3, 4):
                    r, o = uleb(b, o); n, o = uleb(b, o); t, o = uleb(b, o); sg = None
                    if op == 4: sg, o = uleb(b, o); sg = None if sg == 0 else s.strs[sg-1]
                    ops.append(('start', op, r, None if n == 0 else s.strs[n-1], None if t == 0 else s.types[t-1], sg))
                elif op in (5, 6): r, o = uleb(b, o); ops.append(('reg', op, r))
                elif op in (7, 8): ops.append(('flag', op))
                elif op == 9: n, o = uleb(b, o); ops.append(('file', None if n == 0 else s.strs[n-1]))
                else: ops.append(('sp', op))
            return (ls, tuple(params), tuple(ops))
        return s.memo(('dbg', off), f)
    def code(s, off):
        if not off: return None
        def f():
            b = s.b; c = Code()
            c.regs, c.ins, c.outs, nt, dbg, isz = struct.unpack_from('<4HII', b, off)
            c.units = list(struct.unpack_from('<%dH' % isz, b, off + 16)); o = off + 16 + 2*isz
            c.debug = s.debug(dbg); c.tries = []; c.handlers = []
            if nt:
                if isz % 2: o += 2
                traw = [struct.unpack_from('<IHH', b, o + 8*i) for i in range(nt)]; o += 8*nt
                hstart = o; hn, o = uleb(b, o); relmap = {}
                for hi in range(hn):
                    relmap[o - hstart] = hi; sz, o = sleb(b, o); pairs = []
                    for _ in range(abs(sz)): ti, o = uleb(b, o); ad, o = uleb(b, o); pairs.append((s.types[ti], ad))
                    ca = None
                    if sz <= 0: ca, o = uleb(b, o)
                    c.handlers.append((tuple(pairs), ca))
                c.tries = [(a, n, relmap[h]) for a, n, h in traw]
            c.refs = []; u = c.units; i = 0
            cs = lambda x: ('cs', x); mh = lambda x: ('mh', x)
            while i < isz:
                w = u[i]; op = w & 0xff
                if op == 0 and w in (0x100, 0x200, 0x300): i += payload_width(u, i); continue
                for off_, kind in KINDS.get(op, ()):
                    if kind == 'sj': c.refs.append((i+1, 'sj', s.strs[u[i+1] | (u[i+2] << 16)]))
                    else:
                        idx = u[i+off_]
                        sym = {'s': lambda x: s.strs[x], 't': lambda x: s.types[x], 'f': lambda x: s.fields[x], 'm': lambda x: s.methods[x], 'p': lambda x: s.protos[x], 'cs': cs, 'mh': mh}[kind](idx)
                        c.refs.append((i+off_, kind, sym))
                i += W[op]
            assert i == isz
            return c
        return s.memo(('code', off), f)
    def class_data(s, off):
        if not off: return None
        b = s.b; sf, o = uleb(b, off); inf, o = uleb(b, o); dm, o = uleb(b, o); vm, o = uleb(b, o)
        def fl(n, o):
            out = []; idx = 0
            for _ in range(n): d, o = uleb(b, o); fg, o = uleb(b, o); idx += d; out.append((s.fields[idx], fg))
            return out, o
        def ml(n, o):
            out = []; idx = 0
            for _ in range(n):
                d, o = uleb(b, o); fg, o = uleb(b, o); co, o = uleb(b, o); idx += d; out.append([s.methods[idx], fg, s.code(co)])
            return out, o
        r = {}
        r['sf'], o = fl(sf, o); r['if'], o = fl(inf, o); r['dm'], o = ml(dm, o); r['vm'], o = ml(vm, o)
        return r
    def read_class(s, cd):
        ci, acc, sc, io, sfi, ao, cdo, sv = cd; b = s.b
        c = {'cls': s.types[ci], 'acc': acc, 'sup': None if sc == NO else s.types[sc], 'ifs': s.typelist(io),
             'src': None if sfi == NO else s.strs[sfi], 'ann': s.adir(ao), 'data': s.class_data(cdo), 'sv': None}
        if sv:
            n, o = uleb(b, sv); vals = []
            for _ in range(n): x, o = s.value(o); vals.append(x)
            c['sv'] = vals
        return c

# ---------------------------------------------------------------- writer
class Tables:
    def __init__(s):
        s.strs = set(); s.types = set(); s.protos = set(); s.fields = set(); s.methods = set()
    def string(s, x): s.strs.add(x); return x
    def type(s, d): s.strs.add(d); s.types.add(d); return d
    def proto(s, p):
        s.type(p[0]); [s.type(x) for x in p[1]]
        s.strs.add((shorty_char(p[0]) + "".join(shorty_char(x) for x in p[1])).encode()); s.protos.add(p); return p
    def field(s, f): s.type(f[0]); s.type(f[1]); s.strs.add(f[2]); s.fields.add(f); return f
    def method(s, m): s.type(m[0]); s.strs.add(m[1]); s.proto(m[2]); s.methods.add(m); return m
    def seed(s, r):
        for x in r.strs: s.strs.add(x)
        for x in r.types: s.type(x)
        for x in r.protos: s.proto(x)
        for x in r.fields: s.field(x)
        for x in r.methods: s.method(x)
    def finalize(s):
        s.S = sorted(s.strs, key=mkey); s.si = {x: i for i, x in enumerate(s.S)}
        s.T = sorted(s.types, key=lambda d: s.si[d]); s.ti = {x: i for i, x in enumerate(s.T)}
        s.P = sorted(s.protos, key=lambda p: (s.ti[p[0]], tuple(s.ti[x] for x in p[1]))); s.pi = {x: i for i, x in enumerate(s.P)}
        s.F = sorted(s.fields, key=lambda f: (s.ti[f[0]], s.si[f[2]], s.ti[f[1]])); s.fi = {x: i for i, x in enumerate(s.F)}
        s.M = sorted(s.methods, key=lambda m: (s.ti[m[0]], s.si[m[1]], s.pi[m[2]])); s.mi = {x: i for i, x in enumerate(s.M)}

def align(n, a): return (n + a - 1) // a * a

def write_dex(classes, tb, magic=b'dex\n038\0'):
    tb.finalize(); si, ti, pi, fi, mi = tb.si, tb.ti, tb.pi, tb.fi, tb.mi
    def enc_val(v):
        k = v[0]
        if k == 'raw': return bytes([(v[2] << 5) | v[1]]) + v[3]
        if k == 'array': return bytes([0x1c]) + wuleb(len(v[1])) + b''.join(enc_val(x) for x in v[1])
        if k == 'ann': return bytes([0x1d]) + enc_ann(v[1])
        idx, t = {'str': (lambda x: si[x], 0x17), 'type': (lambda x: ti[x], 0x18), 'field': (lambda x: fi[x], 0x19), 'method': (lambda x: mi[x], 0x1a), 'enum': (lambda x: fi[x], 0x1b), 'mtype': (lambda x: pi[x], 0x15)}[k]
        n = idx(v[1]); sz = max(1, (n.bit_length() + 7) // 8)
        return bytes([((sz - 1) << 5) | t]) + n.to_bytes(sz, 'little')
    def enc_ann(a):
        els = sorted(a[1], key=lambda e: si[e[0]])
        return wuleb(ti[a[0]]) + wuleb(len(els)) + b''.join(wuleb(si[n]) + enc_val(v) for n, v in els)
    # ---- collect unique objects (identity) per section
    seen = {}
    def reg(kind, obj):
        key = (kind, id(obj))
        if key not in seen: seen[key] = [obj, None]; return True
        return False
    asets = []; arefs = []; aitems = []; adirs = []; codes = []; dbgs = []; cdatas = []
    def add_set(st):
        if st is None or not reg('set', st): return
        asets.append(st)
        for it in st:
            if reg('item', it): aitems.append(it)
    def add_ref(r):
        if reg('ref', r):
            arefs.append(r)
            for st in r: add_set(st)
    for c in classes:
        d = c['ann']
        if d is not None and reg('dir', d):
            adirs.append(d); add_set(d['cls'])
            for _, st in d['f']: add_set(st)
            for _, st in d['m']: add_set(st)
            for _, r in d['p']: add_ref(r)
        if c['data']:
            cdatas.append(c['data'])
            for lst in (c['data']['dm'], c['data']['vm']):
                for m in lst:
                    if m[2] is not None and reg('code', m[2]):
                        codes.append(m[2])
                        if m[2].debug is not None and reg('dbg', m[2].debug): dbgs.append(m[2].debug)
    # type lists
    tls = {}
    def tl(t):
        if t: tls.setdefault(tuple(t), None)
    for p in tb.P: tl(p[1])
    for c in classes: tl(c['ifs'])
    # ---- sizes (all independent of offsets)
    string_bytes = [wuleb(len(mkey(x))) + x + b'\0' for x in tb.S]
    def enc_dbg(d):
        ls, params, ops = d; out = bytearray(wuleb(ls) + wuleb(len(params)))
        for p in params: out += wuleb(0 if p is None else si[p] + 1)
        for op in ops:
            k = op[0]
            if k == 'pc': out += b'\x01' + wuleb(op[1])
            elif k == 'line': out += b'\x02' + wsleb(op[1])
            elif k == 'start':
                out += bytes([op[1]]) + wuleb(op[2]) + wuleb(0 if op[3] is None else si[op[3]] + 1) + wuleb(0 if op[4] is None else ti[op[4]] + 1)
                if op[1] == 4: out += wuleb(0 if op[5] is None else si[op[5]] + 1)
            elif k == 'reg': out += bytes([op[1]]) + wuleb(op[2])
            elif k == 'flag': out += bytes([op[1]])
            elif k == 'file': out += b'\x09' + wuleb(0 if op[1] is None else si[op[1]] + 1)
            else: out.append(op[1])
        out.append(0); return bytes(out)
    dbg_bytes = {id(d): enc_dbg(d) for d in dbgs}
    item_bytes = {id(it): bytes([it[1]]) + enc_ann(it[2]) for it in aitems}
    def code_units(c):
        u = list(c.units)
        for pos, kind, sym in c.refs:
            if kind == 'sj': n = si[sym]; u[pos] = n & 0xffff; u[pos+1] = n >> 16
            else:
                n = {'s': si, 't': ti, 'f': fi, 'm': mi, 'p': pi}[kind][sym]
                assert n < 65536, "index overflow"; u[pos] = n
        return u
    def code_tail(c):
        out = bytearray()
        if c.tries:
            if len(c.units) % 2: out += b'\0\0'
            hb = bytearray(wuleb(len(c.handlers))); offs = []
            for pairs, ca in c.handlers:
                offs.append(len(hb)); hb += wsleb(-len(pairs) if ca is not None else len(pairs))
                for t, a in pairs: hb += wuleb(ti[t]) + wuleb(a)
                if ca is not None: hb += wuleb(ca)
            for a, n, h in c.tries: out += struct.pack('<IHH', a, n, offs[h])
            out += hb
        return bytes(out)
    code_size = {id(c): align(16 + 2*len(c.units) + len(code_tail(c)), 4) for c in codes}
    # ---- layout
    n_str, n_ty, n_pr, n_fl, n_me, n_cl = len(tb.S), len(tb.T), len(tb.P), len(tb.F), len(tb.M), len(classes)
    off = 0x70; o_str = off; off += 4*n_str; o_ty = off; off += 4*n_ty; o_pr = off; off += 12*n_pr
    o_fl = off; off += 8*n_fl; o_me = off; off += 8*n_me; o_cl = off; off += 32*n_cl; data_off = off
    secs = []   # (type, count, offset)
    def section(t, count, size_fn, a=4):
        nonlocal off
        if count == 0: return None
        off = align(off, a) if a else off; start = off; secs.append((t, count, start)); return start
    pos = {}
    s = section(0x1002, len(arefs), None)
    if s is not None:
        for r in arefs: pos[('ref', id(r))] = off; off += 4 + 4*len(r)
    s = section(0x1003, len(asets), None)
    if s is not None:
        for st in asets: pos[('set', id(st))] = off; off += 4 + 4*len(st)
    s = section(0x2001, len(codes), None)
    if s is not None:
        for c in codes: off = align(off, 4); pos[('code', id(c))] = off; off += code_size[id(c)]
    s = section(0x2006, len(adirs), None)
    if s is not None:
        for d in adirs: pos[('dir', id(d))] = off; off += 16 + 8*(len(d['f']) + len(d['m']) + len(d['p']))
    tl_list = list(tls)
    s = section(0x1001, len(tl_list), None)
    if s is not None:
        for t in tl_list: off = align(off, 4); tls[t] = off; off += 4 + 2*len(t)
    s = section(0x2002, n_str, None, 1); sd_off = []
    for x in string_bytes: sd_off.append(off); off += len(x)
    s = section(0x2003, len(dbgs), None, 1)
    if s is not None:
        for d in dbgs: pos[('dbg', id(d))] = off; off += len(dbg_bytes[id(d)])
    s = section(0x2004, len(aitems), None, 1)
    if s is not None:
        for it in aitems: pos[('item', id(it))] = off; off += len(item_bytes[id(it)])
    sv_bytes = {}
    for i, c in enumerate(classes):
        if c['sv'] is not None: sv_bytes[i] = wuleb(len(c['sv'])) + b''.join(enc_val(v) for v in c['sv'])
    s = section(0x2005, len(sv_bytes), None, 1)
    if s is not None:
        for i in sv_bytes: pos[('sv', i)] = off; off += len(sv_bytes[i])
    # class_data (uleb code offsets known now)
    def enc_cd(cd):
        out = bytearray(wuleb(len(cd['sf'])) + wuleb(len(cd['if'])) + wuleb(len(cd['dm'])) + wuleb(len(cd['vm'])))
        for lst in (cd['sf'], cd['if']):
            prev = 0
            for f, fl in sorted(lst, key=lambda x: fi[x[0]]): n = fi[f]; out += wuleb(n - prev) + wuleb(fl); prev = n
        for lst in (cd['dm'], cd['vm']):
            prev = 0
            for m, fl, code in sorted(lst, key=lambda x: mi[x[0]]):
                n = mi[m]; out += wuleb(n - prev) + wuleb(fl) + wuleb(0 if code is None else pos[('code', id(code))]); prev = n
        return bytes(out)
    cd_bytes = {id(cd): enc_cd(cd) for cd in cdatas}
    s = section(0x2000, len(cdatas), None, 1)
    if s is not None:
        for cd in cdatas: pos[('cd', id(cd))] = off; off += len(cd_bytes[id(cd)])
    off = align(off, 4); map_off = off
    secs.append((0x1000, 1, map_off)); map_size = 4 + 12 * (7 + len(secs) + 0)
    fixed = [(0, 1, 0), (1, n_str, o_str), (2, n_ty, o_ty), (3, n_pr, o_pr), (4, n_fl, o_fl), (5, n_me, o_me), (6, n_cl, o_cl)]
    fixed = [x for x in fixed if x[1] > 0 or x[0] == 0]
    mapitems = fixed + secs; map_size = 4 + 12 * len(mapitems); file_size = align(map_off + map_size, 4)
    out = bytearray(file_size)
    # ---- write
    struct.pack_into('<8s', out, 0, magic)
    struct.pack_into('<IIIIII', out, 0x20, file_size, 0x70, 0x12345678, 0, 0, map_off)
    struct.pack_into('<12I', out, 0x38, n_str, o_str, n_ty, o_ty, n_pr, o_pr, n_fl, o_fl, n_me, o_me, n_cl, o_cl)
    struct.pack_into('<II', out, 0x68, file_size - data_off, data_off)
    for i, o_ in enumerate(sd_off): struct.pack_into('<I', out, o_str + 4*i, o_)
    for i, x in enumerate(string_bytes): out[sd_off[i]:sd_off[i]+len(x)] = x
    for i, d in enumerate(tb.T): struct.pack_into('<I', out, o_ty + 4*i, si[d])
    for i, p in enumerate(tb.P):
        sh = (shorty_char(p[0]) + "".join(shorty_char(x) for x in p[1])).encode()
        struct.pack_into('<3I', out, o_pr + 12*i, si[sh], ti[p[0]], tls[tuple(p[1])] if p[1] else 0)
    for i, f in enumerate(tb.F): struct.pack_into('<HHI', out, o_fl + 8*i, ti[f[0]], ti[f[1]], si[f[2]])
    for i, m in enumerate(tb.M): struct.pack_into('<HHI', out, o_me + 8*i, ti[m[0]], pi[m[2]], si[m[1]])
    for t, o_ in tls.items():
        if t: struct.pack_into('<I', out, o_, len(t)); [struct.pack_into('<H', out, o_ + 4 + 2*k, ti[x]) for k, x in enumerate(t)]
    for r in arefs:
        o_ = pos[('ref', id(r))]; struct.pack_into('<I', out, o_, len(r))
        for k, st in enumerate(r): struct.pack_into('<I', out, o_ + 4 + 4*k, 0 if st is None else pos[('set', id(st))])
    for st in asets:
        o_ = pos[('set', id(st))]; struct.pack_into('<I', out, o_, len(st))
        for k, it in enumerate(sorted(st, key=lambda it: ti[it[2][0]])): struct.pack_into('<I', out, o_ + 4 + 4*k, pos[('item', id(it))])
    for it in aitems: o_ = pos[('item', id(it))]; out[o_:o_+len(item_bytes[id(it)])] = item_bytes[id(it)]
    for d in dbgs: o_ = pos[('dbg', id(d))]; out[o_:o_+len(dbg_bytes[id(d)])] = dbg_bytes[id(d)]
    for i, b_ in sv_bytes.items(): o_ = pos[('sv', i)]; out[o_:o_+len(b_)] = b_
    for cd in cdatas: o_ = pos[('cd', id(cd))]; out[o_:o_+len(cd_bytes[id(cd)])] = cd_bytes[id(cd)]
    for c in codes:
        o_ = pos[('code', id(c))]; dp = 0 if c.debug is None else pos[('dbg', id(c.debug))]
        struct.pack_into('<4HII', out, o_, c.regs, c.ins, c.outs, len(c.tries), dp, len(c.units))
        u = code_units(c); struct.pack_into('<%dH' % len(u), out, o_ + 16, *u)
        t = code_tail(c); out[o_ + 16 + 2*len(u): o_ + 16 + 2*len(u) + len(t)] = t
    for d in adirs:
        o_ = pos[('dir', id(d))]
        struct.pack_into('<4I', out, o_, 0 if d['cls'] is None else pos[('set', id(d['cls']))], len(d['f']), len(d['m']), len(d['p'])); o_ += 16
        for f, st in sorted(d['f'], key=lambda x: fi[x[0]]): struct.pack_into('<2I', out, o_, fi[f], pos[('set', id(st))]); o_ += 8
        for m, st in sorted(d['m'], key=lambda x: mi[x[0]]): struct.pack_into('<2I', out, o_, mi[m], pos[('set', id(st))]); o_ += 8
        for m, r in sorted(d['p'], key=lambda x: mi[x[0]]): struct.pack_into('<2I', out, o_, mi[m], pos[('ref', id(r))]); o_ += 8
    for i, c in enumerate(classes):
        struct.pack_into('<8I', out, o_cl + 32*i, ti[c['cls']], c['acc'], NO if c['sup'] is None else ti[c['sup']], tls[tuple(c['ifs'])] if c['ifs'] else 0,
                         NO if c['src'] is None else si[c['src']], 0 if c['ann'] is None else pos[('dir', id(c['ann']))],
                         0 if c['data'] is None else pos[('cd', id(c['data']))], pos.get(('sv', i), 0))
    struct.pack_into('<I', out, map_off, len(mapitems))
    for k, (t, n, o_) in enumerate(mapitems): struct.pack_into('<HHII', out, map_off + 4 + 12*k, t, 0, n, o_)
    out[32:] = out[32:]; sig = hashlib.sha1(bytes(out[32:])).digest(); out[12:32] = sig
    struct.pack_into('<I', out, 8, zlib.adler32(bytes(out[12:])) & 0xffffffff)
    return bytes(out)
