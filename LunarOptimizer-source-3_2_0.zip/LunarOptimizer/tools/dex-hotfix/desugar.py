import os
HERE = os.path.dirname(os.path.abspath(__file__))
APK = os.environ.get('LUNAR_APK', 'LunarOptimizer-3.0.2.apk')
KS = os.environ.get('LUNAR_KEYSTORE', 'lunar-debug.keystore')
import sys, struct, collections
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..'))
import dexmodel as dm
from verify_dex import parse_value

OBJ = b'Ljava/lang/Object;'
BOX = {b'I': (b'Ljava/lang/Integer;', b'intValue'), b'Z': (b'Ljava/lang/Boolean;', b'booleanValue'), b'J': (b'Ljava/lang/Long;', b'longValue')}
is_ref = lambda d: d[:1] in (b'L', b'[')

def read_sites(r):
    b = r.b; n = struct.unpack_from('<I', b, r.map_off)[0]; m = {}
    for i in range(n):
        t, _, sz, off = struct.unpack_from('<HHII', b, r.map_off + 4 + 12*i); m[t] = (sz, off)
    mh = [struct.unpack_from('<HHHH', b, m[8][1] + 8*i) for i in range(m[8][0])]
    sites = []
    for i in range(m[7][0]):
        co = struct.unpack_from('<I', b, m[7][1] + 4*i)[0]; k, p = dm.uleb(b, co); vals = []
        for _ in range(k): t, v, p = parse_value(b, p); vals.append((t, v))
        boot = r.methods[mh[vals[0][1]][2]]
        assert boot[0] == b'Ljava/lang/invoke/LambdaMetafactory;' and boot[1] == b'metafactory', boot
        assert len(vals) == 6
        mt, _, mid, _ = mh[vals[4][1]]; assert mt == 4, "impl must be invoke-static"
        sites.append({'name': r.strs[vals[1][1]], 'fac': r.protos[vals[2][1]], 'sam': r.protos[vals[3][1]], 'impl': r.methods[mid]})
    return sites

class Asm:
    def __init__(s): s.u = []; s.refs = []
    def i35c(s, op, regs, kind, sym):
        n = len(regs); x = list(regs) + [0]*(5-n); assert all(v < 16 for v in x)
        s.refs.append((len(s.u)+1, kind, sym)); s.u += [(n << 12) | (x[4] << 8) | op, 0, (x[3] << 12) | (x[2] << 8) | (x[1] << 4) | x[0]]
    def i3rc(s, op, first, count, kind, sym):
        assert count < 256 and first < 65536
        s.refs.append((len(s.u)+1, kind, sym)); s.u += [(count << 8) | op, 0, first]
    def i22c(s, op, a, b, kind, sym):
        assert a < 16 and b < 16; s.refs.append((len(s.u)+1, kind, sym)); s.u += [(b << 12) | (a << 8) | op, 0]
    def i21c(s, op, aa, kind, sym): s.refs.append((len(s.u)+1, kind, sym)); s.u += [(aa << 8) | op, 0]
    def i11x(s, op, aa): s.u.append((aa << 8) | op)
    def i12x(s, op, a, b): assert a < 16 and b < 16; s.u.append((b << 12) | (a << 8) | op)

def mkcode(a, regs, ins, outs):
    c = dm.Code(); c.regs, c.ins, c.outs = regs, ins, outs; c.units = a.u; c.refs = a.refs; c.tries = []; c.handlers = []; c.debug = None; return c

def desugar(r, tb):
    sites = read_sites(r); classes = r.classes
    by_method = {}
    for c in classes:
        if c['data']:
            for lst in (c['data']['dm'], c['data']['vm']):
                for e in lst: by_method[e[0]] = e
    obj_init = tb.method((OBJ, b'<init>', (b'V', ())))
    box_valueof = {k: tb.method((v[0], b'valueOf', (v[0], (k,)))) for k, v in BOX.items()}
    box_value = {k: tb.method((v[0], v[1], (k, ()))) for k, v in BOX.items()}
    new_classes = []; create_of = {}; report = []; relaxed = 0
    for n, st in enumerate(sites):
        impl = st['impl']; cap = list(st['fac'][1]); iface = st['fac'][0]; sam_ret, sam_params = st['sam']
        iparams = list(impl[2][1]); iret = impl[2][0]
        assert len(iparams) == len(cap) + len(sam_params), (n, impl)
        assert all(is_ref(t) or t in (b'I', b'Z') for t in cap), (n, cap)
        assert all(is_ref(t) for t in sam_params), (n, sam_params)
        pkg = impl[0][1:-1].rsplit(b'/', 1)[0]
        cdesc = tb.type(b'L' + pkg + b'/LunarLambda$' + str(n).encode() + b';')
        fields = [tb.field((cdesc, t, b'f%d' % i)) for i, t in enumerate(cap)]
        init_m = tb.method((cdesc, b'<init>', (b'V', tuple(cap)))); create_m = tb.method((cdesc, b'create', (iface, tuple(cap)))); sam_m = tb.method((cdesc, st['name'], st['sam']))
        iget = lambda t: 0x54 if is_ref(t) else (0x55 if t == b'Z' else 0x52)
        iput = lambda t: 0x5b if is_ref(t) else (0x5c if t == b'Z' else 0x59)
        # <init>
        a = Asm(); a.i35c(0x70, [0], 'm', obj_init)
        for k, t in enumerate(cap): a.i22c(iput(t), 1 + k, 0, 'f', fields[k])
        a.i11x(0x0e, 0); init_c = mkcode(a, 1 + len(cap), 1 + len(cap), 1)
        # create
        a = Asm(); a.i21c(0x22, 0, 't', cdesc); a.i3rc(0x76, 0, 1 + len(cap), 'm', init_m); a.i11x(0x11, 0)
        create_c = mkcode(a, 1 + len(cap), len(cap), 1 + len(cap))
        # SAM method
        m_ = len(iparams); loc = max(m_, 2); a = Asm(); this = loc
        for k, t in enumerate(cap): a.i22c(iget(t), k, this, 'f', fields[k])
        for j in range(len(sam_params)):
            dest = len(cap) + j; src = loc + 1 + j; t = iparams[dest]
            a.i12x(0x07, dest, src)
            if t == OBJ: pass
            elif is_ref(t): a.i21c(0x1f, dest, 't', t)
            else:
                a.i21c(0x1f, dest, 't', BOX[t][0]); a.i35c(0x6e, [dest], 'm', box_value[t]); a.i11x(0x0a, dest)
        if m_ == 0: a.i35c(0x71, [], 'm', impl)
        else: a.i3rc(0x77, 0, m_, 'm', impl)
        assert iret != b'V'
        if is_ref(iret):
            assert is_ref(sam_ret); a.i11x(0x0c, 0)
            if sam_ret not in (OBJ, iret): a.i21c(0x1f, 0, 't', sam_ret)
            a.i11x(0x11, 0)
        elif iret in (b'I', b'Z'):
            a.i11x(0x0a, 0)
            if sam_ret == iret: a.i11x(0x0f, 0)
            else: assert sam_ret == OBJ; a.i35c(0x71, [0], 'm', box_valueof[iret]); a.i11x(0x0c, 0); a.i11x(0x11, 0)
        elif iret == b'J':
            assert sam_ret == OBJ; a.i11x(0x0b, 0); a.i35c(0x71, [0, 1], 'm', box_valueof[b'J']); a.i11x(0x0c, 0); a.i11x(0x11, 0)
        else: raise AssertionError(iret)
        sam_c = mkcode(a, loc + 1 + len(sam_params), 1 + len(sam_params), max(m_, 2))
        cls = {'cls': cdesc, 'acc': 0x1011, 'sup': OBJ, 'ifs': (iface,), 'src': None, 'ann': None, 'sv': None,
               'data': {'sf': [], 'if': [(f, 0x1012) for f in fields], 'dm': [[init_m, 0x10001, init_c], [create_m, 0x9, create_c]], 'vm': [[sam_m, 0x1, sam_c]]}}
        new_classes.append(cls); create_of[n] = create_m
        e = by_method[impl]
        if e[1] & 0x2: e[1] &= ~0x2; relaxed += 1
        report.append((n, cdesc, iface, cap, st['name'], impl))
    # rewrite call sites
    converted = 0
    for c in classes:
        if not c['data']: continue
        for lst in (c['data']['dm'], c['data']['vm']):
            for e in lst:
                code = e[2]
                if code is None: continue
                for k, (pos, kind, sym) in enumerate(code.refs):
                    if kind == 'cs':
                        op = code.units[pos-1] & 0xff; assert op in (0xfc, 0xfd)
                        code.units[pos-1] = (code.units[pos-1] & 0xff00) | (0x71 if op == 0xfc else 0x77)
                        code.refs[k] = (pos, 'm', create_of[sym[1]]); converted += 1
    assert converted == len(sites), (converted, len(sites))
    for c in classes:
        if c['data']:
            for lst in (c['data']['dm'], c['data']['vm']):
                for e in lst:
                    if e[2] is not None: assert not any(x[1] in ('cs', 'mh') for x in e[2].refs)
    return new_classes, report, relaxed, converted

if __name__ == '__main__':
    import zipfile
    b = zipfile.ZipFile(APK).read('classes.dex')
    r = dm.Reader(b); tb = dm.Tables(); tb.seed(r)
    new, rep, relaxed, conv = desugar(r, tb)
    print("sites converted:", conv, "| adapter classes:", len(new), "| impl methods made package-private:", relaxed)
    caps = collections.Counter(len(x[3]) for x in rep); print("captured-arg counts:", dict(caps))
    out = dm.write_dex(r.classes + new, tb)
    open('classes.fixed.dex', 'wb').write(out)
    print("wrote classes.fixed.dex: %d bytes (original %d); DEX magic %r" % (len(out), len(b), out[:8]))
