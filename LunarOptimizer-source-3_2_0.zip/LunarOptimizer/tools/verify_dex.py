#!/usr/bin/env python3
"""Build gate: fail if an APK/DEX contains invoke-custom (invokedynamic) call sites.

Why: the legacy dx tool emits DEX 038 `invoke-custom` for Java 8 lambdas found in
libraries such as kotlin-stdlib 2.x. Android has no LambdaMetafactory bootstrap, so
the app dies at runtime with "No static method metafactory(...)". D8/R8 desugar these
away; this script proves none survived in the final APK.

Usage:  python3 tools/verify_dex.py app.apk [--list]
Exit:   0 = clean, 1 = invoke-custom found, 2 = usage/parse error
Pure Python 3 standard library. Offline.
"""
import struct, sys, zipfile, collections

def uleb(b, o):
    r = s = 0
    while True:
        x = b[o]; o += 1; r |= (x & 0x7f) << s
        if x < 0x80: return r, o
        s += 7

def parse_value(b, o):
    h = b[o]; o += 1; t = h & 0x1f; a = h >> 5
    if t in (0x00,0x02,0x03,0x04,0x06,0x10,0x11,0x15,0x16,0x17,0x18,0x19,0x1a,0x1b):
        n = a + 1; return t, int.from_bytes(b[o:o+n], 'little'), o + n
    if t == 0x1c:
        n, o = uleb(b, o); v = []
        for _ in range(n):
            tt, x, o = parse_value(b, o); v.append((tt, x))
        return t, v, o
    if t == 0x1d:
        _, o = uleb(b, o); n, o = uleb(b, o)
        for _ in range(n):
            _, o = uleb(b, o); _, _, o = parse_value(b, o)
        return t, None, o
    if t in (0x1e, 0x1f): return t, None, o
    raise ValueError("unknown encoded_value type 0x%x" % t)

# Dalvik instruction widths in 16-bit code units.
W = [1] * 256
for op in (0x02,0x05,0x08,0x13,0x15,0x16,0x19,0x1a,0x1c,0x1f,0x20,0x22,0x23,0x29,0xfe,0xff): W[op] = 2
for op in (0x03,0x06,0x09,0x14,0x17,0x1b,0x24,0x25,0x26,0x2a,0x2b,0x2c,0xfc,0xfd): W[op] = 3
W[0x18] = 5
for op in range(0x2d, 0x3e): W[op] = 2
for op in range(0x44, 0x6e): W[op] = 2
for op in list(range(0x6e, 0x73)) + list(range(0x74, 0x79)): W[op] = 3
for op in range(0x90, 0xb0): W[op] = 2
for op in range(0xd0, 0xe3): W[op] = 2
W[0xfa] = W[0xfb] = 4

class Dex:
    def __init__(s, b):
        s.b = b; s.magic = b[:8]
        if not b.startswith(b'dex\n'): raise ValueError("not a DEX file")
        (s.map_off, sn, so, tn, to, pn, po, fn, fo, mn, mo, cn, co) = struct.unpack_from('<13I', b, 0x34)
        s.mo, s.mn, s.co, s.cn = mo, mn, co, cn
        s.strings = []
        for i in range(sn):
            off = struct.unpack_from('<I', b, so + 4*i)[0]; _, p = uleb(b, off)
            s.strings.append(b[p:b.index(b'\0', p)].decode('utf-8', 'replace'))
        s.types = [s.strings[struct.unpack_from('<I', b, to + 4*i)[0]] for i in range(tn)]
        s.protos = []
        for i in range(pn):
            _, rt, pl = struct.unpack_from('<3I', b, po + 12*i); ps = []
            if pl:
                n = struct.unpack_from('<I', b, pl)[0]
                ps = [s.types[struct.unpack_from('<H', b, pl + 4 + 2*k)[0]] for k in range(n)]
            s.protos.append("(%s)%s" % ("".join(ps), s.types[rt]))
        s.methods = [struct.unpack_from('<HHI', b, mo + 8*i) for i in range(mn)]
        n = struct.unpack_from('<I', b, s.map_off)[0]; m = {}
        for i in range(n):
            t, _, sz, off = struct.unpack_from('<HHII', b, s.map_off + 4 + 12*i); m[t] = (sz, off)
        mh = []
        if 0x0008 in m:
            sz, off = m[0x0008]
            mh = [struct.unpack_from('<HHHH', b, off + 8*i) for i in range(sz)]
        s.callsites = []
        if 0x0007 in m:
            sz, off = m[0x0007]
            for i in range(sz):
                p0 = struct.unpack_from('<I', b, off + 4*i)[0]; n, p = uleb(b, p0); vals = []
                for _ in range(n):
                    t, v, p = parse_value(b, p); vals.append(v)
                s.callsites.append((s.mname(mh[vals[0]][2]), s.strings[vals[1]]))
    def mname(s, mid):
        c, p, n = s.methods[mid]
        return "%s->%s%s" % (s.types[c], s.strings[n], s.protos[p])
    def indy_methods(s):
        b = s.b
        for i in range(s.cn):
            _, _, _, _, _, _, cdo, _ = struct.unpack_from('<8I', b, s.co + 32*i)
            if not cdo: continue
            sfn, o = uleb(b, cdo); ifn, o = uleb(b, o); dmn, o = uleb(b, o); vmn, o = uleb(b, o)
            for _ in range(sfn + ifn): _, o = uleb(b, o); _, o = uleb(b, o)
            for cnt in (dmn, vmn):
                mid = 0
                for _ in range(cnt):
                    d, o = uleb(b, o); _, o = uleb(b, o); code, o = uleb(b, o); mid += d
                    if code and s.has_indy(code): yield mid
    def has_indy(s, code):
        b = s.b; isz = struct.unpack_from('<I', b, code + 12)[0]
        u = struct.unpack_from('<%dH' % isz, b, code + 16); i = 0
        while i < isz:
            w = u[i]; op = w & 0xff
            if op == 0 and w in (0x0100, 0x0200, 0x0300):
                if w == 0x0100: i += u[i+1] * 2 + 4
                elif w == 0x0200: i += u[i+1] * 4 + 2
                else: i += ((u[i+2] | (u[i+3] << 16)) * u[i+1] + 1) // 2 + 4
                continue
            if op in (0xfc, 0xfd): return True
            i += W[op]
        return False

def main(argv):
    if len(argv) < 2: print(__doc__); return 2
    path, show = argv[1], '--list' in argv
    try:
        if path.endswith('.dex'): blobs = {path: open(path, 'rb').read()}
        else:
            z = zipfile.ZipFile(path); blobs = {n: z.read(n) for n in sorted(z.namelist()) if n.endswith('.dex')}
        if not blobs: print("no .dex files found"); return 2
        bad = False
        for name, b in blobs.items():
            d = Dex(b); ms = list(d.indy_methods())
            hist = collections.Counter(c[0] for c in d.callsites)
            print("%s: DEX %s, %d classes, %d call_site_ids, %d methods with invoke-custom" % (name, d.magic[4:7].decode(), d.cn, len(d.callsites), len(ms)))
            for k, v in hist.most_common(): print("    bootstrap x%d  %s" % (v, k))
            if ms:
                bad = True
                byc = collections.Counter(d.types[d.methods[m][0]] for m in ms)
                for k, v in byc.most_common(): print("    %3d in %s" % (v, k))
                if show:
                    for m in sorted(ms, key=d.mname): print("      ", d.mname(m))
        print("RESULT: " + ("FAIL - invoke-custom present, will crash at runtime on Android" if bad else "PASS - no invoke-custom call sites"))
        return 1 if bad else 0
    except Exception as e:
        print("error:", type(e).__name__, e); return 2

if __name__ == '__main__': sys.exit(main(sys.argv))
