#!/usr/bin/env bash
# Downloads the build toolchain into ./toolchain (no root needed). Needs: curl, unzip, JDK 17+ on PATH.
# Kotlin compiler, Android command-line tools, platform android-34 and build-tools 34.0.0.
# Android SDK licences are NOT accepted for you: answer the sdkmanager prompt, or set ACCEPT_ANDROID_LICENSES=yes
# (CI does this as the repository owner's explicit acceptance).
# Downloads are not checksum-pinned yet: SHA-256 values are printed so they can be pinned after a first verified run.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd); TC=${TC:-$ROOT/toolchain}; mkdir -p "$TC"
KOTLIN_VERSION=${KOTLIN_VERSION:-2.1.0}
CMDLINE_URL=${CMDLINE_URL:-https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip}
PLATFORM=${PLATFORM:-android-34}; BT=${BUILD_TOOLS_VERSION:-34.0.0}
for t in curl unzip java; do command -v "$t" >/dev/null || { echo "MISSING $t"; exit 1; }; done
fetch() { curl -fL --retry 3 -o "$2" "$1" && echo "sha256 $(sha256sum "$2" | cut -d' ' -f1)  $(basename "$2")"; }

if [ ! -x "$TC/kotlinc/bin/kotlinc" ]; then
  fetch "https://github.com/JetBrains/kotlin/releases/download/v$KOTLIN_VERSION/kotlin-compiler-$KOTLIN_VERSION.zip" "$TC/kotlin.zip"
  unzip -q -o "$TC/kotlin.zip" -d "$TC"; rm -rf "$TC/kotlinc.tmp"; rm -f "$TC/kotlin.zip"
fi
SDK="$TC/sdk"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  fetch "$CMDLINE_URL" "$TC/cmdline.zip"; mkdir -p "$SDK/cmdline-tools"
  unzip -q -o "$TC/cmdline.zip" -d "$SDK/cmdline-tools.tmp"; rm -rf "$SDK/cmdline-tools/latest"
  mv "$SDK/cmdline-tools.tmp/cmdline-tools" "$SDK/cmdline-tools/latest"; rm -rf "$SDK/cmdline-tools.tmp" "$TC/cmdline.zip"
fi
SM="$SDK/cmdline-tools/latest/bin/sdkmanager"
if [ "${ACCEPT_ANDROID_LICENSES:-}" = yes ]; then yes | "$SM" --sdk_root="$SDK" --licenses >/dev/null; else "$SM" --sdk_root="$SDK" --licenses; fi
"$SM" --sdk_root="$SDK" "platforms;$PLATFORM" "build-tools;$BT"
cat > "$TC/env.sh" <<ENV
export KOTLIN_HOME="$TC/kotlinc"
export ANDROID_JAR="$SDK/platforms/$PLATFORM/android.jar"
export BUILD_TOOLS="$SDK/build-tools/$BT"
ENV
echo "Toolchain ready. Next: ./build.sh"
