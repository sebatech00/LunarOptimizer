#!/usr/bin/env bash
# JVM unit tests (no device, no Android runtime): compiles the pure-Kotlin sources + tests and runs them with JUnit 4.
# Needs: kotlinc (KOTLIN_HOME or ./toolchain/kotlinc), android.jar (ANDROID_JAR, compile-time only), JUnit 4 + hamcrest-core jars (JUNIT_DIR, default /usr/share/java), JDK 17+.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd); [ -f "$ROOT/toolchain/env.sh" ] && . "$ROOT/toolchain/env.sh"
KH=${KOTLIN_HOME:-/home/claude/tc/k19/kotlinc}; AJ=${ANDROID_JAR:-/home/claude/tc/android.jar}; JD=${JUNIT_DIR:-/usr/share/java}
export JAVA_OPTS="${JAVA_OPTS:--Xmx3200m -Xss16m}"
B="$ROOT/build-test"; rm -rf "$B"; mkdir -p "$B/main" "$B/test"
SRC="$ROOT/app/src/main/java/com/lunaroptimizer/app"; TST="$ROOT/app/src/test/java/com/lunaroptimizer/app"
CP="$AJ:$ROOT/libs/shizuku-api.jar"
echo "== compile app sources"; "$KH/bin/kotlinc" "$SRC"/*.kt -cp "$CP" -jvm-target 1.8 -Xlambdas=class -Xsam-conversions=class -no-reflect -nowarn -d "$B/main" > "$B/k1.log" 2>&1 || { grep -E "error" -A2 "$B/k1.log" | head -40; exit 1; }
echo "== compile tests"; "$KH/bin/kotlinc" "$TST"/*.kt -cp "$B/main:$CP:$JD/junit4.jar:$JD/hamcrest-core.jar" -jvm-target 1.8 -nowarn -d "$B/test" > "$B/k2.log" 2>&1 || { grep -E "error" -A2 "$B/k2.log" | head -40; exit 1; }
echo "== run"; CLS=$(cd "$B/test" && find . -name '*Test.class' | sed 's|^\./||; s|\.class$||; s|/|.|g' | grep -v '\$' | tr '\n' ' ')
java -cp "$B/test:$B/main:$KH/lib/kotlin-stdlib.jar:$JD/junit4.jar:$JD/hamcrest-core.jar" org.junit.runner.JUnitCore $CLS
