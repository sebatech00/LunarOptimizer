# Lunar Optimizer 3.0.2: audit, checkpoint 1 (2026-11-07)

Scope: static review of the supplied source plus offline analysis of the supplied APK.
Nothing here was compiled, run on a device, or measured on a device. Line numbers refer to the 3.0.2 source as supplied.
Status words: **VERIFIED-IN-CODE** (read in the source, traced by hand), **VERIFIED-IN-APK** (checked in the shipped binary), **NOT VERIFIED** (needs a device or a toolchain).

## 1. LambdaMetafactory crash: cause confirmed

Evidence (`tools/verify_dex.py` on the supplied APK, VERIFIED-IN-APK):
- `classes.dex` is DEX 038 with 72 call sites, all bootstrapped by `LambdaMetafactory.metafactory`, in 69 methods.
- All 69 are in `kotlin/*` classes (29 classes). 0 are in `com/lunaroptimizer/*`. The app's own code is clean because `build.sh` passes `-Xlambdas=class -Xsam-conversions=class`; the precompiled kotlin-stdlib 2.1.0 is not.
- Cause: stdlib 2.x compiles lambdas as invokedynamic. `dx --min-sdk-version=26` copies them into DEX as `invoke-custom` instead of desugaring. Android does not provide a `LambdaMetafactory` bootstrap, so the first call into such a method throws.
- Exact hit, certain: `Regex.findAll` contains an invoke-custom site and is called from `Pipeline.measure` and `Boost.dexStats` (via `findAll$default`).
- Not proven: the longer lambda/sequence chains my call-graph pass listed. They rely on virtual-dispatch over-approximation. Treat as suspects only.
- Proper fix: dex everything with D8 (or R8), which desugars these. Rewriting individual stdlib calls is a band-aid and cannot be shown complete without rebuilding and re-running the gate.

## 2. Previous review findings

| # | Finding | Status | Evidence |
|---|---|---|---|
| 1a | `TE.revert` erases the saved original before verifying | VERIFIED-IN-CODE | Sh.kt:172 `Sh.exec(put/del); Store.clearOrig(...)`, read-back only at :173. The command result is never checked. |
| 1b | `Pipeline.restoreKey` same defect | VERIFIED-IN-CODE | Pipeline.kt:40, clears before the read-back and ignores exit code. |
| 2 | `Pack.fixAnim` erases animation backups, overwrites user scales | VERIFIED-IN-CODE | Pack.kt:16 `clearOrig` runs for all three keys even when nothing was changed. :15 overwrites any scale equal to 0.5 (a value a user may choose deliberately). It runs automatically from Pages.kt:87 on Home show. |
| 3 | Failed DNS change re-applied later without validation | VERIFIED-IN-CODE | `Pack.apply` checks `Net.blocked()` (Pack.kt:27) and reverts. It still sets `packAuto = true` (:31). `Pack.ensure` (:39-48) then re-applies `dnsad` on a later launch through `TE.apply` with no connectivity check. |
| 4 | `TweaksPage.profile` uses stale state with overlapping refresh-rate tweaks | VERIFIED-IN-CODE (trace) | Tweaks.kt:118 snapshots `cur` once. `hzpeak` and `hz120` share `peak_refresh_rate`. Choosing Performance reverts `hzpeak` (not in its list), which restores `peak_refresh_rate`, but stale `cur["hz120"]==true` skips re-applying `hz120`. It ends half-applied (min=120, peak=original). Simplest trigger by trace: tap Performance while Performance is already active. Not reproduced on device. |
| 5 | AppOps/standby rollback inexact; MSA notification denial not undone | VERIFIED-IN-CODE | Pack.kt:36 resets to `default`/`working_set`. Engine.kt:55 reads the original bucket but keeps it only if a `Run` object is passed, and `Pack.apply` passes null (Pack.kt:30). AppOps originals are never read. Engine.kt:54 denies `POST_NOTIFICATION` for `com.miui.msa.global`; nothing restores it. |
| 6 | DeviceConfig sync changes global, no original state, no coordination | VERIFIED-IN-CODE | Sh.kt:113-114 and :124-127: `phantom`, `cached`, `compact`, `freezer` run `set_sync_disabled_for_tests persistent` before applying and never record the prior sync mode. Reverting any one runs `... none` (:176) even while other device_config tweaks remain, so server flags may overwrite them. Verbs verified in AOSP source: `none`, `persistent` (survives reboot, stored in settings) and `until_reboot` (not stored); a `get_sync_disabled_for_tests` verb exists, so the prior mode could have been recorded. Behaviour on this exact HyperOS build: not checked on device. |
| 7 | `Sh.exec`/`Sh.stream` can wait without limit | VERIFIED-IN-CODE | Sh.kt:30-32 and :43-44 bound only `t1.join(timeout)`. If stdout closes while the process lives, `p.waitFor()` blocks forever. On timeout, `destroy()` stops the remote `sh`, not necessarily its children. The bundled API already has `waitForTimeout(long, TimeUnit)` (ShizukuRemoteProcess.java:114, AIDL `waitForTimeout`). Shizuku API 13.1.5 declares `waitForTimeout(long, TimeUnit)` and `alive()` (secondary source: published API declarations; upstream source not fetched). Whether the Shizuku server running on the phone supports the call: NOT VERIFIED, so keep a fallback (`timeout` binary in the shell command). |
| 8 | "Keep 48 apps cached" assumes 48 raises the limit | VERIFIED-IN-CODE (no pre-check); effect NOT VERIFIED | Sh.kt:125 writes 48 unconditionally. The current effective value was never read. AOSP raised `DEFAULT_MAX_CACHED_PROCESSES` from 32 to 1024, and the official cached-apps-freezer page says supported Android 14+ devices have it significantly increased, so on a stock-default device 48 would LOWER the limit. OEMs can customise it (`config_customizedMaxCachedProcesses`), and HyperOS's value is NOT VERIFIED (needs `dumpsys activity settings`). Pipeline.evalCached (:110-120) checks for 96, has no callers, and relies on cold-start data that is never collected. Read-only commands for the owner are in HANDOVER.md. |

## 3. Additional defects found while checking the same paths

| ID | Defect | Status |
|---|---|---|
| A1 | `Pack.ensure` re-applies every pack tweak on launch, including ones the user switched off individually (`packAuto` stays true). Overrides user choices. | VERIFIED-IN-CODE (Pack.kt:39-48, Tweaks.kt:105) |
| A2 | `Pipeline.disable` records packages that were already disabled by the user as Lunar-owned (Pipeline.kt:48). `restoreAll` (:54-58) also re-enables the whole static `DEBLOAT` list whether or not Lunar disabled it. Restore can undo state Lunar never changed. | VERIFIED-IN-CODE |
| A3 | `TE.apply` and `Pipeline.put` store the "original" without checking the read command succeeded. A failed read yields `""` which is later written back. | VERIFIED-IN-CODE (Sh.kt:157-158, Pipeline.kt:33-34) |
| A4 | `Pipeline.measure` returns placeholders: jank -1, p50/p90/p95/p99 -1, frames 0, cold starts empty (Pipeline.kt:106). Only memory, storage, thermal status and max temperature are real. No fluidness, jank or cold-start number exists anywhere in the app. | VERIFIED-IN-CODE |
| A5 | Home polls every 1 s and, when Shizuku is granted, spawns a new Shizuku shell process per poll (`Tele.read`, Sh.kt:79; Pages.kt:51,105). Foreground only (stops in `onHide`). Each tick also removes and rebuilds the `dyn` cards (Pages.kt:~97). Costs CPU and perturbs any measurement taken while Lunar is open. | VERIFIED-IN-CODE; cost NOT MEASURED |
| A6 | Profiles "Performance"/"Battery" and the checklist include disabling window blur and a 60 Hz lock (Tweaks.kt:112-113, OptimizePage.kt checklist). They conflict with the stated fluidness goal. They are opt-in, but must never be part of any default. | VERIFIED-IN-CODE |
| A7 | "Optimize Now" runs `cmd package compile -m speed-profile -f -a` with a 40 min cap (Pipeline.kt:71). Forcing a recompile of everything costs battery and flash writes. The benefit is unmeasured. Should be optional or tied to OS/app updates. | VERIFIED-IN-CODE; benefit NOT VERIFIED |
| A8 | `largeHeap="true"` in the manifest for a View-only UI. Probably unnecessary. | VERIFIED-IN-CODE; impact NOT MEASURED |
| A9 | The only test (`tests/ClassifyTest.kt`) covers package classification. Nothing covers rollback or failure paths. It is not wired into `build.sh`. | VERIFIED-IN-CODE |
| A10 | Lunar's shell layer depends on `Shizuku#newProcess` (the patched jar makes it public). Upstream states it intends to remove it in favour of UserService, so a future Shizuku release could break every Lunar command. | VERIFIED (upstream README text); timing unknown |

## 4. Privacy and telemetry audit

- DEX contents (VERIFIED-IN-APK): only `kotlin`, `com.lunaroptimizer`, `rikka.shizuku`, `moe.shizuku` and 4 stub `androidx.annotation` classes. No analytics, crash-reporting, ads or HTTP client library.
- Source search (VERIFIED-IN-CODE): the only network activity is `InetAddress.getByName` in `Net.blocked()` (Engine.kt:20-30): one lookup of `example.com` plus six Xiaomi tracker hostnames, to check that DNS works and whether trackers are blocked. This is why `INTERNET` is declared. It is DNS resolution, sent to whatever resolver the phone uses (including a Private DNS provider if one is set).
- The Shizuku "Get" button opens `https://github.com/RikkaApps/Shizuku/releases` in the browser (Pages.kt:34). User-initiated.
- Diagnostics: crash text is written to a local file (LunarApp.kt:14) and shown on next launch; the console log and errors are kept in memory/SharedPreferences. The only export is a manual clipboard copy (Ui.kt:144). Nothing is uploaded.
- Not yet checked: no privacy/terms/about screens exist; no notice text exists.

## 5. Licensing state (verified against registries/upstream pages on 2026-11-08; see docs/SOURCES.md)

- No LICENSE, NOTICE or third-party text exists anywhere in the tree (VERIFIED-IN-CODE).
- Shizuku-API (`libs/shizuku-api.jar`, built from `tc-extras/`): **MIT** (Maven Central POM and upstream metadata). The Shizuku app itself is Apache-2.0 with extra terms: do not use "Shizuku" as an app name, do not use `moe.shizuku.privileged.api` as an application id, do not declare `moe.shizuku.manager.permission.*`. Lunar should only *use* that permission (to check in the manifest). The patch (public `newProcess`, lambdas replaced) must be recorded and the MIT notice kept. The `tc-extras` sources carry no headers; the upstream MIT text and copyright line must ship in NOTICE.
- Inter fonts: **SIL OFL 1.1**, copyright The Inter Project Authors, "Inter" is a Reserved Font Name. Bundling is allowed if each copy ships with the copyright notice and licence text. If the bundled OTFs were subsetted or modified, they must not keep the name "Inter". Whether they were modified: NOT VERIFIED.
- kotlin-stdlib: **Apache-2.0** (Maven Central POM). NOTICE with licence text required.
- `bg_lunar.jpg`, `lunar_logo.png`, `ic_launcher_fg.png`: provenance and licence unknown; only the owner can state them.

## 6. Signing

The supplied APK is signed with v2 and v3 only (no v1). Certificate subject `CN=Lunar Optimizer Debug`, SHA-256 `46ab3ec9faa2b0e353e95a807f9d4c4ea023acfac7007555eefe5c257d49aa46`, valid 2026-10-29 to 2054-03-16 (VERIFIED-IN-APK). The keystore is not in this workspace. Android will refuse an update signed by any other key.
