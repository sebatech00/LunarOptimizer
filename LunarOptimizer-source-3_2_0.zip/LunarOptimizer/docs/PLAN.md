# Work plan (approved scope, 2026-11-08). All of it needs a compiler; none is implemented yet.
Owner chose: all six improvements, plus small extra optimise tweaks and more Lunar Pack entries.
Rules for every change: visual design untouched; experimental options off by default; a tweak ships only if it has a mechanism, a default-state read, a verified apply, a rollback and a measurement; "unavailable" is shown where no data exists.

## A. Safety and rollback (first; blocks everything else)
1. One serialized mutation executor (single thread + lock); every Shizuku call bounded by `waitForTimeout` with a `timeout <n>` fallback in the shell command; kill on expiry.
2. Journal per change: `{key, kind, original, applied, state}`. Snapshot only a validated original (command succeeded; explicit "null" vs value). Delete the record only after read-back equals the original; on failure keep it, mark RESTORE_FAILED, say so.
3. `TE.revert`, `Pipeline.restoreKey`, `Pack.fixAnim`: use the journal; `fixAnim` touches only values Lunar itself recorded, never clears records it did not use, and asks before changing a value the user may have chosen.
4. `Pack.ensure`: never silent. Per-tweak "user turned off" flag respected; DNS re-validated (`Net.blocked()`) before any re-apply; otherwise show a prompt on Home.
5. `TweaksPage.profile`: re-read state between phases; apply overlapping tweaks (hz*, peak/min refresh) as one transaction.
6. App ops / standby / notifications: record the previous `cmd appops get` value and standby bucket per package; undo restores exactly that; include `POST_NOTIFICATION` for `com.miui.msa.global`.
7. DeviceConfig sync: read `get_sync_disabled_for_tests` first; use `until_reboot` (self-heals) instead of `persistent`; restore only what Lunar changed, and only when no other Lunar device_config tweak is still applied.
8. `Pipeline.disable` tracks only packages Lunar actually disabled; `restoreAll` re-enables only those.
9. Tests: JVM unit tests with a fake `Sh` for success, command failure, timeout, partial restore, restart mid-restore, overlapping tweaks. Failure paths first.

## B. Measurement (real numbers or "unavailable")
- Cold/warm start: `am start -W` (TotalTime/ThisTime/WaitTime). Note: `-W` blocks until launch completes, so it cannot be used for the interrupt test.
- Fluidness (synthetic): one persistent shell loop of plain `am start <app>`, a fixed delay inside the opening animation, `input keyevent KEYCODE_HOME`, next app; launcher `dumpsys gfxinfo <launcher> reset` before and dump after (janky frames, percentiles); optional `dumpsys SurfaceFlinger --frametimeline -jank`. Label as synthetic: not identical to finger gestures; compare only same-script runs.
- Battery: `dumpsys batterystats --reset` then charge counter deltas, screen-on and screen-off reported separately, with a minimum duration before any figure is shown.
- Delete the placeholder fields in `Pipeline.measure`; show "unavailable".

## C. Tweaks and Lunar Pack (evidence-backed list only)
Ready to implement once a compiler exists (mechanism documented, see SOURCES.md):
1. Optimize Now: replace `compile -m speed-profile -f -a` by letting the system do it (`cmd package bg-dexopt-job`, cancellable with `--cancel`) or at least dropping `-f`. Benefit unmeasured until B exists.
2. "Keep N apps cached": read `CUR_MAX_CACHED_PROCESSES` from `dumpsys activity settings` first; apply only if it would raise the limit; record the previous device_config value (delete if it was unset).
3. DeviceConfig tweaks: `until_reboot` + journal (A7).
4. Lunar Pack contents are re-validated one by one against A; anything that cannot be verified or rolled back moves to "experimental, off".
Not added until read-only device checks and measurement exist (nothing is invented): any further setting, flag or app-ops change. Candidates are collected from primary docs, then each is checked on the phone with a read-only default read first.

## D. Privacy, Terms, About, licences
Privacy (no telemetry; only DNS lookups, listed), Terms, About, dependency notices as pages in the existing style; LICENSE (owner chooses), NOTICE (Shizuku-API MIT text + patch note, Inter OFL text + copyright, kotlin-stdlib Apache-2.0), build instructions that match reality. Check the manifest uses (not declares) `moe.shizuku.manager.permission.API_V23`.

## E. Lightweight monitoring
Poll 2-3 s instead of 1 s; one persistent shell instead of a new process per poll; rebuild cards only when values change; no polling when the screen is off. Visual output identical.

## F. Release
D8 build via `./build.sh`, gate passes, tests pass, sign with the original key, report what was and was not tested on the phone.

# Added 2026-11-08 (owner request): automatic mode, wider Deep Clean, better optimizer, more Pack tweaks
Design is grounded in research (docs/SOURCES.md). Nothing here is implemented; it needs the compiler and section A (journal/rollback) first, because these features change system state automatically.

## G. Automatic mode (in tweak selection)
Goal: scan the phone, find useless packages and background drains, and disable/restrict them in one step.
- Read-only scan inputs (all via Shizuku; exact verbs to be re-checked with `<cmd> help` on the phone): `pm list packages` (all, system, disabled), `dumpsys batterystats` (per-uid wakelocks, jobs, alarms, background network), `dumpsys usagestats` (last used, standby bucket), `dumpsys procstats`, `dumpsys alarm`, `dumpsys jobscheduler`, `dumpsys deviceidle`, `cmd appops get`, role holders.
- Evidence per package: background wakelock/job/alarm/CPU time, days since last use, has launcher icon, current bucket/app-ops.
- Protected, never touched: `Pipeline.BLOCK`, role holders (launcher, dialer, SMS, browser, keyboard, assistant), accessibility services, VPNs, device admins, notification listeners, active media sessions, alarm-clock/alarm users, location-sharing apps (always-on location + foreground service), push (GMS), the owner's own "keep" list, and anything in the user's deviceidle whitelist.
- Tiers (modelled on the 4-tier scheme community debloat lists use; Lunar builds its own list, see licence note):
  0. Telemetry/ads packages from a curated list: disable.
  1. Used rarely + measured background activity: *restrict* (app-ops background ignore + restricted bucket), not disable. Reversible, lower risk.
  2. Curated bloat unused for N days: `pm disable-user --user 0`.
  3. Anything else, system-critical or unknown: report only.
- Flow: scan -> one review screen with reasons and a one-tap "Apply recommended" -> journaled apply -> verified -> one-tap undo. "Apply without review" exists but is off by default. A package whose removal changes a default handler is skipped.
- Licence note: the UAD-NG tool is GPLv3 and its preinstalled-lists data licence was not verified. Do not copy their lists into Lunar until checked; build Lunar's own list from on-device evidence plus the existing `Pipeline.DEBLOAT`.

## H. Deep Clean: "scan everything", act only on proven problems
- Scan: all processes including system/native (`dumpsys meminfo`), cached/empty process counts, swap/zram and free memory, per-app cache sizes, storage junk (thumbnails, logs/tmp, empty dirs, residual APKs, stale dexopt artifacts), top background CPU/wakelock users.
- Act: caches via `pm trim-caches` only when storage is low; junk files after a preview; force-stop only an app the scan flagged as a background offender and only with a visible reason. No blanket process killing: Android's low-memory killer already evicts background apps by oom score, and killing everything makes apps relaunch, costing CPU and battery.
- Report honestly: RAM "freed" is transient; show app relaunch cost where measured. Success is judged with section B numbers, not by free RAM.

## I. Optimizer improvements
Journaled steps only; dry-run available; skip a step when there is no evidence it helps; ART step via the system job instead of forced recompiling; trim-caches only when needed; run when charging and idle; measure before/after with section B and show "unavailable" where no data exists; no placebo steps; never disable blur, shorten animations or force 60 Hz.

## J. Lunar Pack additions (evidence-backed only)
1. System dexopt job after OS/app updates (C1). 2. Conditional cached-apps limit (C2). 3. Per-phone background restrictions chosen by automatic mode tier 1 (replaces a fixed package list). 4. Existing telemetry-package disables, moved onto the journal. Everything else stays out until it passes: mechanism documented, default read, verified apply, rollback, measured benefit.
Honest note on fluidness: on a locked-bootloader, non-root phone the real levers are few (compiled code, low background CPU load, free storage, thermal headroom, adaptive refresh). Most circulating "smoothness tweaks" (animation scale cuts, blur off, forced 60/120 Hz, mass process killing) either contradict your goals or have no evidence, so they are not in the Pack.

## K. Audio (owner request: best possible sound from the phone)
Verified facts (docs/SOURCES.md): by default Android's mixer mixes all sources and applies volume control and effects; bit-perfect USB output is an optional vendor feature that the *playing app* requests through an Android 14+ API, so Lunar cannot switch it on system-wide. Xiaomi 14 Bluetooth codecs: AAC, aptX, aptX HD, aptX Adaptive, LDAC, LHDC 5.0; aptX Lossless needs Snapdragon Sound on both ends. Spotify Premium offers Lossless (up to 24-bit/44.1 kHz) and an "auto adjust quality" toggle; its "Loud" normalization setting reduces dynamics.
Assumed path: wired earphones through a USB-C DAC/dongle (Bluetooth secondary).
There is no stock-Android system setting that improves fidelity beyond the source and the DAC. Audio "boost"/build.prop-style mods need root or an unlocked bootloader and are not available here; no non-root equivalent was found. So no fake audio tweaks go into the Pack. Lunar scope instead:
1. Audio page, read-only "audio path report": active output (speaker / USB DAC / Bluetooth), mixer sample rate and format, active effect chains, Bluetooth codec if applicable. Commands to verify on the phone first: `dumpsys audio`, `dumpsys media.audio_flinger`, `dumpsys bluetooth_manager`. Show "unavailable" if output cannot be parsed. Style identical to the existing pages.
2. Checklist (static text, like the existing Checklist page): Spotify -> Lossless, auto-adjust off, normalization Normal/Quiet or off (not Loud), EQ flat/off; Xiaomi sound effects (Dolby / Mi Sound) off if a flat signal is wanted (menu names to be verified on HyperOS 3); use a player that supports USB bit-perfect if wanted; do not bypass safe-volume limits.
3. Never restrict a media-session app in automatic mode or the Pack (already in section G's protected list); keep music playback exempt from background limits.
