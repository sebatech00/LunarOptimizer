# Sources used for verified statements (checked 2026-11-08)
Status words as in AUDIT.md. "Secondary" = mirror/aggregator of a primary source; re-check against the primary when network access exists.

| Claim | Source |
|---|---|
| Shizuku-API is MIT | Maven Central POM for `dev.rikka.shizuku:provider` 13.1.5 (central.sonatype.com/artifact/dev.rikka.shizuku/provider); upstream repo github.com/RikkaApps/Shizuku-API |
| Shizuku app is Apache-2.0 with name/id/permission restrictions | upstream README (mirror: upd.dev/RikkaApps/Shizuku). Secondary |
| `device_config set_sync_disabled_for_tests` accepts none / persistent / until_reboot; persistent survives reboot, until_reboot is not stored; `get_sync_disabled_for_tests` exists | AOSP frameworks/base `DeviceConfig`/`Settings.Config` and SettingsProvider shell command (e Foundation GitLab mirror: gitlab.e.foundation/e/os/android_frameworks_base, commits c94778ce, b8e316c4, 9f47ce09). Secondary mirror of AOSP |
| `set_sync_disabled_for_tests persistent` / `none` usage | developers.google.com/privacy-sandbox/relevance/setup/android/troubleshooting; AOSP ART odrefresh test |
| AOSP `DEFAULT_MAX_CACHED_PROCESSES` 32 -> 1024; OEM `config_customizedMaxCachedProcesses`; effective value is `CUR_MAX_CACHED_PROCESSES` | AOSP commit "Boost MAX_CACHED_PROCESSES and reduce freezer timeout" (mirror commit 912a866d) and ActivityManagerConstants commits (d18b8b32, c6de36e6). Secondary mirror |
| Android 14+ supported devices have MAX_CACHED_PROCESSES significantly increased; override/revert commands | source.android.com/docs/core/perf/cached-apps-freezer (primary) |
| `cmd package compile -f` forces dexopt even if the filter is not better; `bg-dexopt-job` behaves like the real background job (subset of apps, downgrades unused apps when storage is low, cleans obsolete files); `--reset` | `cmd package` help text, quoted at blog.csdn.net/zhangphil/article/details/147557654. Secondary; re-check with `cmd package help` on the phone |
| Shizuku API 13.1.5 declares `ShizukuRemoteProcess.waitForTimeout` and `alive()` | published API declarations (unpkg.com `@sm003/autojs6-dts` files for rikka.shizuku.api 13.1.5). Secondary |
| Upstream intends to remove `Shizuku#newProcess` in favour of UserService | Shizuku-API README text as mirrored at github.com/t3149/Shizuku-API. Secondary |
| `am start -W` reports ThisTime/TotalTime/WaitTime | multiple Android testing write-ups; AOSP `system/extras/tests/workloads/systemapps.sh` uses `am` start timing plus jank/latency percentiles |
| `dumpsys gfxinfo <pkg>` gives total/janky frames and percentiles for one app process; needs real rendering activity | Android testing write-ups (secondary) |
| `dumpsys SurfaceFlinger --frametimeline [-jank|-all]` exists | AOSP frameworks/native commit "Dumpsys for FrameTimeline" (mirror: gerrit.omnirom.org). Secondary |
| Inter: SIL OFL 1.1, Reserved Font Name "Inter", bundling allowed with copyright + licence text | github.com/rsms/inter; fontsquirrel.com/license/inter |
| kotlin-stdlib is Apache-2.0 | Maven Central POM (central.sonatype.com/artifact/org.jetbrains.kotlin/kotlin-stdlib/2.1.20), mvnrepository.com |
| Community debloat lists use four removal tiers (Recommended / Advanced / Expert / Unsafe) with descriptions and dependency data; one MIUI package removal is reported to bootloop devices | UAD-NG wiki/FAQ and release notes (github.com/Universal-Debloater-Alliance/universal-android-debloater-next-generation; github.com/0x192/universal-android-debloater). Secondary; the tool is GPLv3, the preinstalled-lists repo licence NOT verified |
| Android's low-memory killer kills background apps first, ordered by oom_adj_score | developer.android.com/topic/performance/memory-management (primary) |
| Killing all background apps can worsen performance and battery (relaunch cost); only targeted killing of one misbehaving app is defensible | Android community write-ups (droid-life, How-To Geek). Secondary/opinion; consistent with the LMK design above |
| Android 14 preferred mixer attributes for USB audio are developer APIs for apps; default framework mixer applies volume control and effects; BIT_PERFECT is optional, vendor/HAL-dependent, USB only | source.android.com/docs/core/audio/preferred-mixer-attr (primary) |
| Xiaomi 14 Bluetooth 5.4: AAC, aptX, aptX HD, aptX Adaptive, LDAC, LHDC 5.0 | mi.com support FAQ KA-243615 (primary, vendor) |
| aptX Lossless needs Snapdragon Sound support on phone and earbuds, otherwise falls back to aptX Adaptive | mychooz.com Xiaomi earbuds guide. Secondary |
| Spotify Premium: Very high and Lossless tiers; turn off auto-adjust to hold quality; Lossless is 24-bit/44.1 kHz FLAC; "Loud" normalization reduces dynamics | Spotify support (support.spotify.com volume normalization), Engadget, RouteNote 2026 guide. Support page primary, others secondary |
