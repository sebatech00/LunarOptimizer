#!/usr/bin/env bash
# Lunar Optimizer build: kotlinc + aapt + D8 + zipalign + apksigner, then a DEX safety gate.
#
# D8 replaces dx. dx cannot desugar the invokedynamic lambdas inside kotlin-stdlib 2.x, which is what
# crashed "Optimize Now" with a LambdaMetafactory error. The gate (tools/verify_dex.py) fails the build
# if any such call site survives.
#
# Toolchain: run tools/get-toolchain.sh once (writes toolchain/env.sh), or export these yourself:
#   KOTLIN_HOME  dir with bin/kotlinc and lib/kotlin-stdlib.jar (Kotlin 2.1.0 compiler)
#   ANDROID_JAR  .../platforms/android-34/android.jar
#   BUILD_TOOLS  .../build-tools/34.0.0  (aapt, d8, zipalign, apksigner)
# Needs on PATH: java/jar/keytool (JDK 17+), python3, zip (optional).
# Signing: KEYSTORE (default ./lunar-debug.keystore), KS_PASS (default android), KEY_ALIAS (default lunar), KEY_PASS.
# A freshly generated keystore will NOT be able to update an APK signed by the original key.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
[ -f "$ROOT/toolchain/env.sh" ] && . "$ROOT/toolchain/env.sh"
INSTALLED_SHA256=46ab3ec9faa2b0e353e95a807f9d4c4ea023acfac7007555eefe5c257d49aa46   # cert of the APK on the owner's phone
need() { [ -e "$2" ] || { echo "MISSING $1: $2   (run tools/get-toolchain.sh, or set $1)"; exit 1; }; }
: "${KOTLIN_HOME:=}"; : "${ANDROID_JAR:=}"; : "${BUILD_TOOLS:=}"
for v in KOTLIN_HOME ANDROID_JAR BUILD_TOOLS; do [ -n "${!v}" ] || { echo "$v is not set (run tools/get-toolchain.sh, or export it)"; exit 1; }; done
need KOTLIN_HOME "$KOTLIN_HOME/bin/kotlinc"; need KOTLIN_HOME "$KOTLIN_HOME/lib/kotlin-stdlib.jar"
need ANDROID_JAR "$ANDROID_JAR"
for t in aapt d8 zipalign apksigner; do need BUILD_TOOLS "$BUILD_TOOLS/$t"; done
for t in java jar keytool; do command -v "$t" >/dev/null || { echo "MISSING $t on PATH (install a JDK 17+)"; exit 1; }; done
[ "${SKIP_DEX_GATE:-0}" = 1 ] || command -v python3 >/dev/null || { echo "python3 is required for the DEX gate (SKIP_DEX_GATE=1 to bypass, not recommended)"; exit 1; }

G="$ROOT/app/build.gradle.kts"
VERSION_CODE=$(sed -n 's/.*versionCode = \([0-9][0-9]*\).*/\1/p' "$G" | head -1)
VERSION_NAME=$(sed -n 's/.*versionName = "\([^"]*\)".*/\1/p' "$G" | head -1)
[ -n "$VERSION_CODE" ] && [ -n "$VERSION_NAME" ] || { echo "cannot read versionCode/versionName from $G"; exit 1; }
B="$ROOT/build"; SRC="$ROOT/app/src/main"; OUT="$ROOT/LunarOptimizer-$VERSION_NAME-d8.apk"
echo "== Lunar Optimizer $VERSION_NAME (build $VERSION_CODE)"
rm -rf "$B" "$OUT"; mkdir -p "$B/classes" "$B/dex"

echo "== kotlinc"
"$KOTLIN_HOME/bin/kotlinc" "$SRC"/java/com/lunaroptimizer/app/*.kt -cp "$ANDROID_JAR:$ROOT/libs/shizuku-api.jar" \
  -jvm-target 1.8 -Xlambdas=class -Xsam-conversions=class -Xstring-concat=inline -no-reflect -nowarn -d "$B/classes" > "$B/kotlinc.log" 2>&1 \
  || { grep -E "error" -A2 "$B/kotlinc.log" | head -60; echo "KOTLIN COMPILE FAILED (full log: $B/kotlinc.log)"; exit 1; }
jar cf "$B/app.jar" -C "$B/classes" .

echo "== D8"
cp "$KOTLIN_HOME/lib/kotlin-stdlib.jar" "$B/stdlib.jar"
command -v zip >/dev/null && zip -qd "$B/stdlib.jar" 'META-INF/versions/*' module-info.class >/dev/null 2>&1 || true
"$BUILD_TOOLS/d8" --release --min-api 30 --lib "$ANDROID_JAR" --output "$B/dex" "$B/app.jar" "$B/stdlib.jar" "$ROOT/libs/shizuku-api.jar" > "$B/d8.log" 2>&1 \
  || { head -40 "$B/d8.log"; echo "D8 FAILED (full log: $B/d8.log)"; exit 1; }
ls "$B"/dex/*.dex >/dev/null 2>&1 || { echo "D8 produced no .dex"; exit 1; }
grep -ciE "warning" "$B/d8.log" >/dev/null 2>&1 && echo "   (D8 warnings in $B/d8.log)" || true

echo "== package"
sed "s|<manifest |<manifest package=\"com.lunaroptimizer.app\" android:versionCode=\"$VERSION_CODE\" android:versionName=\"$VERSION_NAME\" |" "$SRC/AndroidManifest.xml" > "$B/AndroidManifest.xml"
"$BUILD_TOOLS/aapt" package -f -M "$B/AndroidManifest.xml" -S "$SRC/res" -A "$SRC/assets" -I "$ANDROID_JAR" --min-sdk-version 30 --target-sdk-version 34 -F "$B/base.apk"
(cd "$B/dex" && for f in *.dex; do "$BUILD_TOOLS/aapt" add -k "$B/base.apk" "$f" >/dev/null; done)
"$BUILD_TOOLS/zipalign" -f -p 4 "$B/base.apk" "$B/aligned.apk"

echo "== sign"
KEYSTORE=${KEYSTORE:-$ROOT/lunar-debug.keystore}; KS_PASS=${KS_PASS:-android}; KEY_ALIAS=${KEY_ALIAS:-lunar}; KEY_PASS=${KEY_PASS:-$KS_PASS}
if [ ! -f "$KEYSTORE" ]; then
  echo "WARNING: no keystore at $KEYSTORE. Generating a NEW key. This APK cannot update the installed Lunar Optimizer."
  keytool -genkeypair -keystore "$KEYSTORE" -storepass "$KS_PASS" -keypass "$KEY_PASS" -alias "$KEY_ALIAS" -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Lunar Optimizer Debug" >/dev/null 2>&1
fi
"$BUILD_TOOLS/apksigner" sign --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true \
  --ks "$KEYSTORE" --ks-pass pass:"$KS_PASS" --ks-key-alias "$KEY_ALIAS" --key-pass pass:"$KEY_PASS" --out "$OUT" "$B/aligned.apk"
CERTS=$("$BUILD_TOOLS/apksigner" verify --verbose --print-certs "$OUT")
echo "$CERTS" | head -6
SHA=$(echo "$CERTS" | sed -n 's/.*certificate SHA-256 digest: *//p' | head -1)
if [ "$SHA" = "$INSTALLED_SHA256" ]; then echo "SIGNING: same key as the installed APK (in-place update possible)"
else echo "SIGNING: DIFFERENT key from the installed APK. Android will refuse an in-place update; uninstall is required (back up / restore first)."; fi

if [ "${SKIP_DEX_GATE:-0}" != 1 ]; then
  echo "== DEX gate"
  python3 "$ROOT/tools/verify_dex.py" "$OUT" || { echo "BUILD REJECTED by DEX gate; $OUT must not be installed"; mv "$OUT" "$OUT.REJECTED"; exit 1; }
fi
ls -la "$OUT"
echo "DONE: $OUT"
