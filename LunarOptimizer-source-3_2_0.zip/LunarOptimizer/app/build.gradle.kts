plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
dependencies { implementation(files("../libs/shizuku-api.jar")) }
android {
    namespace = "com.lunaroptimizer.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.lunaroptimizer.app"; minSdk = 30; targetSdk = 34; versionCode = 16; versionName = "3.2.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_1_8; targetCompatibility = JavaVersion.VERSION_1_8 }
    kotlinOptions { jvmTarget = "1.8" }
    sourceSets["main"].java.srcDir("src/main/java")
}
