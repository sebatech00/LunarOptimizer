package com.lunaroptimizer.app

/** In-memory stand-in for Shizuku shell: simulates settings, device_config, appops, standby buckets and package state, with fault injection. */
class Crash : RuntimeException("simulated process death")

class FakeShell : Shell {
    val settings = HashMap<String, String>()      // "global.key"
    val dc = HashMap<String, String>()            // "ns.key"
    var sync = "none"
    val ops = HashMap<String, String>()           // "pkg|OP"
    val buckets = HashMap<String, Int>()
    val installed = HashSet<String>(); val disabled = HashSet<String>()
    val log = ArrayList<String>()
    /** Settings keys that the "system" silently refuses to change (put succeeds, value stays). */
    val ignore = HashSet<String>()

    private class Rule(val re: Regex, var times: Int, val kind: String, val effect: Boolean, val code: Int, val err: String, var skip: Int = 0)
    private val rules = ArrayList<Rule>()
    /** command fails with exit code (effect=false: nothing happens). */
    fun failWhen(re: String, times: Int = 1, code: Int = 1, err: String = "boom", effect: Boolean = false, skip: Int = 0) { rules.add(Rule(Regex(re), times, "fail", effect, code, err, skip)) }
    /** command times out (-3). effect=true: the command did take effect before the timeout fired. */
    fun hangWhen(re: String, times: Int = 1, effect: Boolean = false, skip: Int = 0) { rules.add(Rule(Regex(re), times, "hang", effect, -3, "timeout after 15s", skip)) }
    /** process dies. effect=true: command executed, then the app died before it could record the result. */
    fun crashWhen(re: String, times: Int = 1, effect: Boolean = false, skip: Int = 0) { rules.add(Rule(Regex(re), times, "crash", effect, 0, "", skip)) }
    fun garbage(re: String, out: String, times: Int = 1, skip: Int = 0) { rules.add(Rule(Regex(re), times, "garbage:$out", false, 0, "", skip)) }

    fun count(re: String) = log.count { Regex(re).containsMatchIn(it) }

    override fun exec(cmd: String, log: Boolean, timeoutMs: Long): Sh.R {
        this.log.add(cmd)
        val r = rules.firstOrNull { it.times > 0 && it.re.containsMatchIn(cmd) }
        if (r != null && r.skip > 0) { r.skip--; return run(cmd) }
        if (r != null) {
            r.times--
            when {
                r.kind == "fail" || r.kind == "hang" -> { if (r.effect) run(cmd); return Sh.R("", r.err, r.code) }
                r.kind == "crash" -> { if (r.effect) run(cmd); throw Crash() }
                r.kind.startsWith("garbage:") -> return Sh.R(r.kind.substring(8), "", 0)
            }
        }
        return run(cmd)
    }
    private fun ok(s: String = "") = Sh.R(s + (if (s.isNotEmpty()) "\n" else ""), "", 0)
    private fun run(cmd: String): Sh.R {
        Regex("^settings (get|put|delete) (\\w+) (\\S+)(?: (.*))?$").find(cmd)?.let { m ->
            val k = m.groupValues[2] + "." + m.groupValues[3]
            return when (m.groupValues[1]) { "get" -> ok(settings[k] ?: "null"); "put" -> { if (k !in ignore) settings[k] = m.groupValues[4]; ok() }; else -> { settings.remove(k); ok("Deleted") } }
        }
        Regex("^device_config (get|put|delete) (\\w+) (\\S+)(?: (.*))?$").find(cmd)?.let { m ->
            val k = m.groupValues[2] + "." + m.groupValues[3]
            return when (m.groupValues[1]) { "get" -> ok(dc[k] ?: "null"); "put" -> { dc[k] = m.groupValues[4]; ok() }; else -> { dc.remove(k); ok() } }
        }
        if (cmd == "device_config get_sync_disabled_for_tests") return ok(sync)
        Regex("^device_config set_sync_disabled_for_tests (\\S+)$").find(cmd)?.let { sync = it.groupValues[1]; return ok() }
        Regex("^cmd appops get (\\S+) (\\S+)$").find(cmd)?.let { m -> val v = ops[m.groupValues[1] + "|" + m.groupValues[2]]; return if (v == null) ok("No operations.") else ok("${m.groupValues[2]}: $v") }
        Regex("^cmd appops set (\\S+) (\\S+) (\\S+)$").find(cmd)?.let { m -> val k = m.groupValues[1] + "|" + m.groupValues[2]; if (m.groupValues[3] == "default") ops.remove(k) else ops[k] = m.groupValues[3]; return ok() }
        Regex("^am get-standby-bucket (\\S+)$").find(cmd)?.let { return ok((buckets[it.groupValues[1]] ?: 10).toString()) }
        Regex("^am set-standby-bucket (\\S+) (\\S+)$").find(cmd)?.let { m ->
            val n = mapOf("active" to 10, "working_set" to 20, "frequent" to 30, "rare" to 40, "restricted" to 45)[m.groupValues[2]] ?: return Sh.R("", "bad bucket", 1)
            buckets[m.groupValues[1]] = n; return ok()
        }
        Regex("^pm list packages( -d)? --user 0 (\\S+)$").find(cmd)?.let { m ->
            val p = m.groupValues[2]; val l = if (m.groupValues[1].isNotEmpty()) installed.filter { it in disabled && it.contains(p) } else installed.filter { it.contains(p) }
            return ok(l.joinToString("\n") { "package:$it" })
        }
        Regex("^pm disable-user --user 0 (\\S+)$").find(cmd)?.let { if (it.groupValues[1] in installed) disabled.add(it.groupValues[1]); return ok() }
        Regex("^pm enable --user 0 (\\S+)$").find(cmd)?.let { disabled.remove(it.groupValues[1]); return ok() }
        return Sh.R("", "unknown command in fake: $cmd", 127)
    }
}

class MemKV : KV {
    val m = java.util.concurrent.ConcurrentHashMap<String, String>()
    override fun get(k: String) = m[k]
    override fun put(k: String, v: String) { m[k] = v }
    override fun remove(k: String) { m.remove(k) }
    override fun keys(prefix: String) = m.keys.filter { it.startsWith(prefix) }
}
