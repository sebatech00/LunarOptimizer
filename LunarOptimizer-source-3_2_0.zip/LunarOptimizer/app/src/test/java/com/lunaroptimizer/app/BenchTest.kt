package com.lunaroptimizer.app

import org.junit.Assert.*
import org.junit.Test

class BenchTest {
    private fun r(app: String, s: Long, on: Boolean, t: Float = 30f) = BenchRun(1L, app, s, t, on)
    @Test fun logRoundTripsAndIgnoresGarbage() {
        val l = listOf(r("com.a|b", 1000, true, 31.5f), r("com.x", 2000, false)); val d = BenchLogic.decode(BenchLogic.encode(l) + "\nrubbish\n1|2|x|y|1")
        assertEquals(2, d.size); assertEquals("com.a/b", d[0].app); assertEquals(31.5f, d[0].tempC, 0.01f); assertTrue(d[0].modeOn); assertFalse(d[1].modeOn)
    }
    @Test fun verdictNeverClaimsAGainWithoutEnoughRuns() {
        val one = BenchLogic.stat(listOf(r("a", 1100, true)), "a", true); val off = BenchLogic.stat(listOf(r("a", 1000, false)), "a", false)
        assertTrue(BenchLogic.verdict(one, off).contains("Not enough runs")); assertTrue(BenchLogic.verdict(null, off).contains("on and off"))
    }
    @Test fun verdictCallsSmallDifferenceNoise() {
        val on = BenchLogic.stat((1..3).map { r("a", 1010, true) }, "a", true); val off = BenchLogic.stat((1..3).map { r("a", 1000, false) }, "a", false)
        assertTrue(BenchLogic.verdict(on, off).contains("noise"))
    }
    @Test fun verdictReportsRealDifference() {
        val on = BenchLogic.stat((1..3).map { r("a", 1100, true) }, "a", true); val off = BenchLogic.stat((1..3).map { r("a", 1000, false) }, "a", false)
        assertTrue(BenchLogic.verdict(on, off).contains("+10.0%")); assertEquals(1100L, on!!.best)
    }
    @Test fun readinessFlagsHeatChargingSaverAndLowRam() {
        val ok = BenchLogic.readiness(29f, 0, false, false, 50); assertTrue(ok.all { it.ok })
        val bad = BenchLogic.readiness(38f, 2, true, true, 20); assertTrue(bad.none { it.ok })
    }
    @Test fun parsesColdStartOnly() {
        assertEquals(523, Parse.startTotalMs("Starting: Intent\nStatus: ok\nLaunchState: COLD\nTotalTime: 523\nWaitTime: 530\n"))
        assertNull(Parse.startTotalMs("Status: ok\nLaunchState: WARM\nTotalTime: 90")); assertNull(Parse.startTotalMs("Status: timeout\nTotalTime: 0"))
    }
    @Test fun resolvesActivityAndGameModeAnswers() {
        assertEquals("com.x/.Main", Parse.resolveActivity("priority=0 preferredOrder=0\ncom.x/.Main\n")); assertNull(Parse.resolveActivity("No activity found"))
        assertTrue(Parse.gameModeOk("", 0)); assertFalse(Parse.gameModeOk("Exception: package not supported", 0)); assertFalse(Parse.gameModeOk("", 255))
        assertEquals(mapOf("a" to 5, "b" to 7), ColdStart.parse("a=5,b=7,junk,c=x"))
    }
}
