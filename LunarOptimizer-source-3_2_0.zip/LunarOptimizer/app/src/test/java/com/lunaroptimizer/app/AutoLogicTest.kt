package com.lunaroptimizer.app

import org.junit.Assert.*
import org.junit.Test

class AutoLogicTest {
    private fun ev(pkg: String, system: Boolean = false, enabled: Boolean = true, launcher: Boolean = true, days: Int? = 40, bucket: Int? = null, rss: Int = 0, mah: Double? = null, cpu: Double? = null, wake: Double? = null,
                   curated: Boolean = false, bloat: Boolean = false, prot: String? = null) = Ev(pkg, pkg, system, enabled, launcher, days, bucket, rss, mah, cpu, wake, curated, bloat, prot)
    private fun cls(vararg e: Ev) = AutoLogic.classify(e.toList())

    @Test fun protectedAppsNeverAppearInAnyTier() {
        val r = cls(ev("a", curated = true, prot = "default app (HOME)"), ev("b", bloat = true, system = true, prot = "device admin"), ev("c", mah = 50.0, rss = 500, prot = "running foreground service"))
        assertTrue(r.isEmpty())
    }
    @Test fun curatedTelemetryIsTier0Disable() { val r = cls(ev("com.miui.analytics", system = true, curated = true, days = null)); assertEquals(1, r.size); assertEquals(0, r[0].tier); assertEquals(Act.DISABLE, r[0].act); assertTrue(r[0].sel) }
    @Test fun alreadyDisabledAppsAreIgnored() { assertTrue(cls(ev("x", curated = true, enabled = false)).isEmpty()) }
    @Test fun tier1NeedsUnusedDaysAndMeasuredActivity() {
        assertEquals(Act.RESTRICT, cls(ev("busy", days = 20, mah = 5.0)).single().act)
        assertTrue("recently used is never restricted", cls(ev("recent", days = 3, mah = 9.0, rss = 400)).none { it.tier == 1 })
        assertTrue("idle in the background is left alone", cls(ev("quiet", days = 60, mah = 0.2, rss = 20)).isEmpty())
        assertTrue("no usage data means no claim that it is unused", cls(ev("nodata", days = null, mah = 9.0)).none { it.tier == 1 })
    }
    @Test fun tier1SkipsSystemAppsAndAlreadyRestrictedOnes() {
        assertTrue(cls(ev("sys", system = true, days = 60, mah = 9.0)).none { it.tier == 1 })
        assertTrue(cls(ev("done", days = 60, mah = 9.0, bucket = 45)).isEmpty())
        assertTrue("no launcher icon: background component, not a forgotten app", cls(ev("svc", launcher = false, days = 60, mah = 9.0)).none { it.tier == 1 })
    }
    @Test fun tier2NeedsLowRiskBloatUnusedForTheLongerWindow() {
        assertEquals(Act.DISABLE, cls(ev("com.facebook.appmanager", system = true, bloat = true, days = 45)).single().let { assertEquals(2, it.tier); it.act })
        assertTrue(cls(ev("bloat", system = true, bloat = true, days = 10)).isEmpty()); assertTrue(cls(ev("bloat2", system = true, bloat = true, days = null)).isEmpty())
    }
    @Test fun heavyButNotActionableAppsAreReportOnly() {
        val r = cls(ev("sysheavy", system = true, mah = 40.0, days = 1)); assertEquals(Act.REPORT, r.single().act); assertFalse(r.single().sel)
    }
    @Test fun orderingIsTierThenDrain() {
        val r = cls(ev("t1small", days = 30, mah = 4.0), ev("tel", curated = true, system = true), ev("t1big", days = 30, mah = 8.0))
        assertEquals(listOf("tel", "t1big", "t1small"), r.map { it.ev.pkg })
    }
    @Test fun parseExtrasIdleUserAndDexStatus() {
        assertEquals(setOf("com.a"), Parse.idleUser("system-excidle,android,1000\nuser,com.a,10100\nsystem,com.b,10101"))
        assertEquals("speed-profile", Parse.dexStatus("[com.x]\n  path: /data/app/x.apk\n    arm64: [status=speed-profile] [reason=bg-dexopt]"))
        assertNull(Parse.dexStatus("nothing"))
    }
}
