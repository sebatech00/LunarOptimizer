package com.lunaroptimizer.app

import org.junit.Assert.*
import org.junit.Test

/** Samples below are written from the documented AOSP formats (NOT captured from the phone). They prove the parsers do what the code says; they do not prove HyperOS 3 prints this exact text. */
class ParseTest {
    @Test fun curMaxCachedPrefersCurValue() {
        assertEquals(32, Parse.curMaxCached("  CUR_MAX_CACHED_PROCESSES=32\n  max_cached_processes=48"))
        assertEquals(48, Parse.curMaxCached("  max_cached_processes=48")); assertNull(Parse.curMaxCached("nothing here"))
    }
    @Test fun meminfoGroupsProcessesAndReadsZram() {
        val d = """
Total PSS by OOM adjustment:
    552,640K: Native
                 106,880K: surfaceflinger (pid 703)
    1,206,234K: System
                 400,100K: system_server (pid 1500)
    1,045,100K: Cached
                 150,172K: com.foo.app (pid 5555 / activities)
                  90,000K: com.bar.app (pid 5600)

Total PSS by category:
Total RAM: 11,420,000K (status normal)
 Free RAM: 3,000,000K (   100,000K cached pss +  2,000,000K cached kernel +   900,000K free)
 ZRAM: 120,000K physical used for 400,000K in swap (6,000,000K total swap)
"""
        val m = Parse.meminfo(d)!!
        assertEquals(setOf("Native", "System", "Cached"), m.groups.keys); assertEquals(552640L, m.groups["Native"]); assertEquals(4, m.procs.size)
        assertEquals("Cached", m.procs.first { it.name == "com.bar.app" }.group); assertEquals(5600, m.procs.first { it.name == "com.bar.app" }.pid)
        assertEquals(120000L, m.zramUsedKb); assertEquals(400000L, m.zramSwapKb); assertEquals(11420000L, m.totalKb); assertEquals(3000000L, m.freeKb)
        assertNull(Parse.meminfo("garbage"))
    }
    @Test fun diskCachesPairsNamesWithSizesAndRejectsMismatch() {
        val d = "Package Names: [\"com.a\",\"com.b\",\"com.c\"]\nApp Sizes: [1,2,3]\nCache Sizes: [100, 900, 50]\n"
        assertEquals(listOf("com.b" to 900L, "com.a" to 100L, "com.c" to 50L), Parse.diskCaches(d))
        assertTrue(Parse.diskCaches("Package Names: [\"x\"]\nCache Sizes: [1,2]").isEmpty()); assertTrue(Parse.diskCaches("").isEmpty())
    }
    @Test fun uidMappingMatchesBatterystatsNaming() {
        assertEquals("u0a233", Parse.uidKey(10233)); assertEquals("u10a5", Parse.uidKey(1010005)); assertEquals("1000", Parse.uidKey(1000))
        assertEquals(mapOf("com.a" to 10233, "com.b" to 10234), Parse.uidMap("package:com.a uid:10233\npackage:com.b uid:10234\n"))
    }
    @Test fun battUidsReadsPowerAndComponents() {
        val d = "Other stuff\n  Estimated power use (mAh):\n    Capacity: 4610, Computed drain: 600\n    Uid u0a233: 3.67 ( cpu=3.5 wifi=0.17 wakelock=0.4 )\n    Uid 1000: 10.2\n    Uid u0a99: 0.01\n\n  Something else\n    Uid u0a1: 99\n"
        val m = Parse.battUids(d); assertEquals(3, m.size); assertEquals(3.67, m["u0a233"]!!.mah, 0.001); assertEquals(3.5, m["u0a233"]!!.cpu!!, 0.001); assertEquals(0.4, m["u0a233"]!!.wake!!, 0.001); assertNull(m["u0a99"]!!.cpu); assertTrue(Parse.battUids("nope").isEmpty())
    }
    @Test fun foregroundServicesOnlyCountWhenForeground() {
        val d = "  * ServiceRecord{abc u0 com.spotify.music/.PlayerService}\n    isForeground=true foregroundId=1\n  * ServiceRecord{def u0 com.x.sync/.SyncService}\n    isForeground=false\n  * ServiceRecord{12f u0 com.nav.app/.NavService}\n    app=ProcessRecord\n    isForeground=true\n"
        assertEquals(setOf("com.spotify.music", "com.nav.app"), Parse.fgServices(d))
    }
    @Test fun idleWhitelistAndComponentLists() {
        assertEquals(setOf("android", "com.a"), Parse.idleWhitelist("system-excidle,android,1000\nuser,com.a,10100\n"))
        assertEquals(setOf("com.a", "com.b"), Parse.componentPkgs("com.a/.S1:com.b/x.Y")); assertTrue(Parse.componentPkgs("null").isEmpty())
        assertEquals(setOf("com.adm"), Parse.adminPkgs("Enabled Device Admins (User 0):\n  admin=ComponentInfo{com.adm/com.adm.Admin}:\n"))
        assertTrue("com.spotify.music" in Parse.pkgTokens("Sessions Stack\n  com.spotify.music/Spotify userId=0"))
    }
    private val af = """
Output thread 0xb4000074 , name AudioOut_D, tid 1234, type 0 (MIXER):
  I/O handle: 13
  Standby: no
  Sample rate: 48000 Hz
  HAL format: 0x5 (AUDIO_FORMAT_PCM_FLOAT)
  Output devices: 0x4000000 (AUDIO_DEVICE_OUT_USB_DEVICE)
  Effect ID 5: foo
  Effect ID 6: bar
Output thread 0xb4000075, name AudioOut_15, tid 1300, type 3 (OFFLOAD):
  Standby: yes
  Sample rate: 44100 Hz
  HAL format: 0x1 (AUDIO_FORMAT_PCM_16_BIT)
  Output device: 0x2 (AUDIO_DEVICE_OUT_SPEAKER)
"""
    @Test fun audioFlingerThreads() {
        val t = Parse.audioFlinger(af); assertEquals(2, t.size)
        assertEquals("MIXER", t[0].type); assertEquals(48000, t[0].rateHz); assertEquals("PCM_FLOAT", t[0].format); assertEquals(listOf("USB_DEVICE"), t[0].devices); assertEquals(false, t[0].standby); assertEquals(2, t[0].effectCount)
        assertEquals("OFFLOAD", t[1].type); assertEquals(true, t[1].standby); assertEquals(listOf("SPEAKER"), t[1].devices); assertTrue(Parse.audioFlinger("nothing").isEmpty())
    }
    @Test fun btCodecOnlyWhenRecognised() {
        val c = Parse.btCodec("A2dpService:\n  mCodecConfig: {codecName:LDAC, sampleRate=96000, bitsPerSample=24}\n")!!
        assertEquals("LDAC", c.codec); assertEquals(96000, c.rateHz); assertEquals(24, c.bits)
        assertNull(Parse.btCodec("bluetooth off")); assertEquals("APTX_HD", Parse.btCodec("A2dp\n  type SOURCE_CODEC_TYPE_APTX_HD\n")!!.codec)
    }
}
