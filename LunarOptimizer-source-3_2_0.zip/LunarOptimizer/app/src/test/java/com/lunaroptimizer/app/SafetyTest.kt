package com.lunaroptimizer.app

import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Section A9. Failure paths first, then the happy paths and the overlap/ownership rules. */
class SafetyTest {
    private val fake = FakeShell(); private val kv = MemKV()
    private var m = Mutator(fake, kv)
    private fun restart() { m = Mutator(fake, kv) }
    private val foo = SettingT("global", "foo")
    private fun key(k: String) = "global.$k"

    // ---------- command failure
    @Test fun unreadableOriginalIsNeverSnapshottedAndNothingIsWritten() {
        fake.settings[key("foo")] = "1"; fake.failWhen("^settings get global foo")
        val o = m.change(foo, "5", "t"); assertFalse(o.ok)
        assertNull(m.entry(foo.key)); assertEquals("1", fake.settings[key("foo")]); assertEquals(0, fake.count("^settings put"))
    }
    @Test fun garbageReadIsRejectedAsOriginal() {
        fake.garbage("^settings get global foo", "Exception occurred while executing: java.lang.SecurityException")
        assertFalse(m.change(foo, "5", "t").ok); assertTrue(m.entries().isEmpty()); assertEquals(0, fake.count("^settings put"))
    }
    @Test fun failedWriteLeavesSystemAndJournalClean() {
        fake.settings[key("foo")] = "1"; fake.failWhen("^settings put global foo 5")
        val o = m.change(foo, "5", "t"); assertFalse(o.ok); assertNull(m.entry(foo.key)); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun systemSilentlyIgnoringTheValueIsReportedAndNotRecorded() {
        fake.settings[key("foo")] = "1"; fake.ignore.add(key("foo"))
        val o = m.change(foo, "5", "t"); assertFalse(o.ok); assertTrue(o.detail.contains("did not keep")); assertNull(m.entry(foo.key))
    }
    @Test fun unsettableStandbyOriginalIsRefusedBeforeAnyWrite() {
        fake.buckets["p"] = 5
        assertFalse(m.change(BucketT("p"), "45", "q").ok); assertEquals(5, fake.buckets["p"]); assertEquals(0, fake.count("set-standby-bucket")); assertTrue(m.entries().isEmpty())
    }
    @Test fun absentPackageIsNeverDisabled() { assertFalse(m.change(PkgT("ghost"), "disabled", "a").ok); assertEquals(0, fake.count("pm disable-user")) }

    // ---------- timeout
    @Test fun writeTimeoutWithNoEffectLeavesNothingBehind() {
        fake.settings[key("foo")] = "1"; fake.hangWhen("^settings put global foo 5")
        val o = m.change(foo, "5", "t"); assertFalse(o.ok); assertNull(m.entry(foo.key)); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun writeTimeoutThatDidApplyIsAcceptedOnlyBecauseReadBackProvesIt() {
        fake.settings[key("foo")] = "1"; fake.hangWhen("^settings put global foo 5", effect = true)
        val o = m.change(foo, "5", "t"); assertTrue(o.ok); assertEquals(JState.APPLIED, m.entry(foo.key)!!.state)
    }
    @Test fun readBackTimeoutKeepsRecordPendingAndRecoverSettlesIt() {
        fake.settings[key("foo")] = "1"; fake.hangWhen("^settings get global foo", skip = 1)
        val o = m.change(foo, "5", "t"); assertFalse(o.ok); assertEquals(JState.PENDING, m.entry(foo.key)!!.state)
        restart(); val l = m.recover(); assertEquals(JState.APPLIED, m.entry(foo.key)!!.state); assertTrue(l.single().contains("confirmed"))
    }
    @Test fun restoreTimeoutKeepsRecordAsRestoreFailedThenRetrySucceeds() {
        fake.settings[key("foo")] = "1"; assertTrue(m.change(foo, "5", "t").ok)
        fake.hangWhen("^settings put global foo 1")
        val o = m.release(foo, "t"); assertFalse(o.ok); assertEquals(JState.RESTORE_FAILED, m.entry(foo.key)!!.state); assertEquals("5", fake.settings[key("foo")])
        assertEquals(1, m.failed().size); val r = m.retryFailed(); assertTrue(r.single().contains("restored")); assertNull(m.entry(foo.key)); assertEquals("1", fake.settings[key("foo")])
    }

    // ---------- partial restore
    @Test fun partialRestoreRestoresWhatItCanAndKeepsTheRest() {
        for (k in listOf("a", "b", "c")) fake.settings[key(k)] = "1"
        val ts = listOf("a", "b", "c").map { SettingT("global", it) }; for (t in ts) assertTrue(m.change(t, "9", "x").ok)
        fake.failWhen("^settings put global b 1", times = 5)
        val outs = ts.map { m.release(it, "x") }
        assertEquals(listOf(true, false, true), outs.map { it.ok })
        assertEquals("1", fake.settings[key("a")]); assertEquals("9", fake.settings[key("b")]); assertEquals("1", fake.settings[key("c")])
        assertEquals(listOf("s|global|b"), m.failed().map { it.key }); assertTrue(outs[1].detail.contains("RESTORE_FAILED"))
    }
    @Test fun failedRestoreSurvivesRestartAndStillRestoresLater() {
        fake.settings[key("foo")] = "1"; m.change(foo, "5", "t"); fake.failWhen("^settings put global foo 1", times = 1); m.release(foo, "t")
        restart(); assertEquals(JState.RESTORE_FAILED, m.entry(foo.key)!!.state); assertTrue(m.retryFailed().single().contains("restored")); assertEquals("1", fake.settings[key("foo")])
    }

    // ---------- restart mid-operation
    @Test fun restartMidRestoreAfterTheValueWasAlreadyPutBackClearsTheRecord() {
        fake.settings[key("foo")] = "1"; m.change(foo, "5", "t"); fake.crashWhen("^settings put global foo 1", effect = true)
        try { m.release(foo, "t"); fail("expected crash") } catch (c: Crash) {}
        assertEquals(JState.RESTORING, m.entry(foo.key)!!.state); restart(); m.recover()
        assertNull(m.entry(foo.key)); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun restartMidRestoreBeforeTheValueWasPutBackFinishesTheRestore() {
        fake.settings[key("foo")] = "1"; m.change(foo, "5", "t"); fake.crashWhen("^settings put global foo 1", effect = false)
        try { m.release(foo, "t"); fail("expected crash") } catch (c: Crash) {}
        assertEquals("5", fake.settings[key("foo")]); restart(); m.recover(); assertNull(m.entry(foo.key)); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun restartMidApplyIsSettledByReadingTheValue() {
        fake.settings[key("foo")] = "1"; fake.crashWhen("^settings put global foo 5", effect = true)
        try { m.change(foo, "5", "t"); fail("expected crash") } catch (c: Crash) {}
        assertEquals(JState.PENDING, m.entry(foo.key)!!.state); restart(); m.recover(); assertEquals(JState.APPLIED, m.entry(foo.key)!!.state)
        assertTrue(m.release(foo, "t").ok); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun restartMidApplyThatNeverWroteDropsThePendingRecord() {
        fake.settings[key("foo")] = "1"; fake.crashWhen("^settings put global foo 5", effect = false)
        try { m.change(foo, "5", "t"); fail("expected crash") } catch (c: Crash) {}
        restart(); m.recover(); assertNull(m.entry(foo.key)); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun valueChangedByTheUserAfterLunarIsNotOverwrittenOnRelease() {
        fake.settings[key("foo")] = "1"; m.change(foo, "5", "t"); fake.settings[key("foo")] = "9"
        val o = m.release(foo, "t"); assertTrue(o.ok); assertFalse(o.changed); assertEquals("9", fake.settings[key("foo")]); assertNull(m.entry(foo.key))
    }
    @Test fun explicitForceRestoreDoesOverwrite() {
        fake.settings[key("foo")] = "1"; m.change(foo, "5", "t"); fake.settings[key("foo")] = "9"
        assertTrue(m.restore(foo, true).ok); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun recoverNeverTouchesAValueSomebodyElseChanged() {
        fake.settings[key("foo")] = "1"; fake.crashWhen("^settings put global foo 5", effect = true)
        try { m.change(foo, "5", "t") } catch (c: Crash) {}
        fake.settings[key("foo")] = "7"; restart(); val l = m.recover(); assertEquals("7", fake.settings[key("foo")]); assertNull(m.entry(foo.key)); assertTrue(l.single().contains("changed outside"))
    }

    // ---------- happy paths and the validated-original rule
    @Test fun nullIsAnExplicitOriginalAndRestoreDeletes() {
        assertTrue(m.change(foo, "5", "t").ok); assertEquals("null", m.entry(foo.key)!!.original)
        assertTrue(m.release(foo, "t").ok); assertFalse(fake.settings.containsKey(key("foo"))); assertEquals(1, fake.count("^settings delete global foo"))
    }
    @Test fun alreadyAtTheValueRecordsNothingSoItIsNeverRolledBack() {
        fake.settings[key("foo")] = "5"; val o = m.change(foo, "5", "t"); assertTrue(o.ok); assertFalse(o.changed); assertTrue(m.entries().isEmpty())
        m.release(foo, "t"); assertEquals("5", fake.settings[key("foo")]); assertEquals(0, fake.count("^settings put"))
    }
    @Test fun secondApplyKeepsTheFirstOriginalNotTheAppliedValue() {
        fake.settings[key("foo")] = "1"; m.change(foo, "5", "a"); m.change(foo, "5", "a"); assertEquals("1", m.entry(foo.key)!!.original)
        m.release(foo, "a"); assertEquals("1", fake.settings[key("foo")])
    }
    @Test fun numericEqualityIgnoresFormat() {
        fake.settings["system.peak_refresh_rate"] = "60.0"; val t = SettingT("system", "peak_refresh_rate")
        assertTrue(m.change(t, "120", "t").ok); assertTrue(m.release(t, "t").ok); assertEquals("60.0", fake.settings["system.peak_refresh_rate"])
    }
    @Test fun journalCodecSurvivesCommasNewlinesPercentAndSeparators() {
        val v = "inactive_to=60000,motion_inactive_to=60000,100%x\u001Fy"; fake.dc["activity_manager.k"] = v
        val t = DcT("activity_manager", "k"); fake.dc["activity_manager.k"] = v
        assertTrue(m.changeDc(t, "2", "o,wner%").ok); restart(); assertEquals(v, m.entry(t.key)!!.original); assertTrue(m.releaseDc(t, "o,wner%").ok); assertEquals(v, fake.dc["activity_manager.k"])
        val nl = "a\nb,c%d\u001Fe"; assertTrue(m.importLegacy("o|global||x", nl)); restart(); assertEquals(nl, m.entry("s|global|x")!!.original)
    }
    @Test fun legacyRecordsAreImportedAndHonoured() {
        fake.settings[key("window_animation_scale")] = "0.5"
        assertTrue(m.importLegacy("o|global||window_animation_scale", "1.0")); assertFalse(m.importLegacy("junk", "x"))
        assertTrue(m.release(SettingT("global", "window_animation_scale"), "any").ok); assertEquals("1.0", fake.settings[key("window_animation_scale")])
    }

    // ---------- overlapping tweaks
    @Test fun overlappingTweaksShareOneOriginalAndRestoreOnlyWhenTheLastOwnerLeaves() {
        val peak = SettingT("system", "peak_refresh_rate"); fake.settings["system.peak_refresh_rate"] = "60.0"
        assertTrue(m.change(peak, "120.0", "hzpeak").ok); assertTrue(m.change(peak, "120.0", "hz120").ok)
        assertEquals("60.0", m.entry(peak.key)!!.original)
        val a = m.release(peak, "hzpeak"); assertTrue(a.ok); assertFalse(a.changed); assertEquals("120.0", fake.settings["system.peak_refresh_rate"])
        assertTrue(m.release(peak, "hz120").changed); assertEquals("60.0", fake.settings["system.peak_refresh_rate"]); assertTrue(m.entries().isEmpty())
    }
    @Test fun transactionRollsBackEarlierOpsWhenALaterOneIsRejected() {
        fake.settings["system.peak_refresh_rate"] = "60.0"; fake.settings["system.min_refresh_rate"] = "0.0"; fake.ignore.add("system.min_refresh_rate")
        val tx = m.transaction(listOf(Triple(SettingT("system", "peak_refresh_rate") as Target, "120.0", "hz120"), Triple(SettingT("system", "min_refresh_rate") as Target, "120.0", "hz120")))
        assertFalse(tx.ok); assertEquals(1, tx.rolledBack); assertEquals("60.0", fake.settings["system.peak_refresh_rate"]); assertTrue(m.entries().isEmpty())
    }
    @Test fun transactionThatSucceedsKeepsEverything() {
        fake.settings["system.peak_refresh_rate"] = "60.0"; fake.settings["system.min_refresh_rate"] = "0.0"
        val tx = m.transaction(listOf(Triple(SettingT("system", "peak_refresh_rate") as Target, "120.0", "hz120"), Triple(SettingT("system", "min_refresh_rate") as Target, "120.0", "hz120")))
        assertTrue(tx.ok); assertEquals(2, m.entries().size)
    }

    // ---------- DeviceConfig sync
    private val cached = DcT("activity_manager", "max_cached_processes"); private val phantom = DcT("activity_manager", "max_phantom_processes")
    @Test fun syncUsesUntilRebootAndIsRestoredToWhatWasFound() {
        fake.sync = "persistent"; assertTrue(m.changeDc(cached, "48", "cached").ok); assertEquals("until_reboot", fake.sync)
        assertTrue(m.releaseDc(cached, "cached").ok); assertEquals("persistent", fake.sync)
        assertTrue(m.entries().isEmpty())
    }
    @Test fun syncStaysPausedUntilTheLastDeviceConfigTweakIsRemoved() {
        fake.sync = "none"; m.changeDc(cached, "48", "cached"); m.changeDc(phantom, "2147483647", "phantom")
        m.releaseDc(cached, "cached"); assertEquals("until_reboot", fake.sync); assertEquals(1, m.entries().count { it.key.startsWith("dc|") })
        m.releaseDc(phantom, "phantom"); assertEquals("none", fake.sync); assertTrue(m.entries().isEmpty())
    }
    @Test fun failedDeviceConfigChangeGivesTheSyncSwitchBack() {
        fake.sync = "none"; fake.failWhen("^device_config put activity_manager max_cached_processes"); val o = m.changeDc(cached, "48", "cached")
        assertFalse(o.ok); assertEquals("none", fake.sync); assertTrue(m.entries().isEmpty())
    }
    @Test fun neverPersistentIsWritten() { fake.sync = "none"; m.changeDc(cached, "48", "cached"); assertEquals(0, fake.count("set_sync_disabled_for_tests persistent")) }

    // ---------- app ops, buckets, packages
    @Test fun appOpsAndBucketsRestoreExactlyWhatWasThere() {
        fake.ops["p|RUN_ANY_IN_BACKGROUND"] = "allow"; fake.ops["p|POST_NOTIFICATION"] = "ignore"; fake.buckets["p"] = 20
        val ts = listOf<Pair<Target, String>>(OpT("p", "RUN_ANY_IN_BACKGROUND") to "deny", OpT("p", "RUN_IN_BACKGROUND") to "deny", OpT("p", "POST_NOTIFICATION") to "deny", BucketT("p") to "45")
        for ((t, v) in ts) assertTrue(t.label, m.change(t, v, "quiet").ok)
        assertEquals(45, fake.buckets["p"]); assertEquals("deny", fake.ops["p|RUN_ANY_IN_BACKGROUND"])
        for ((t, _) in ts) assertTrue(m.release(t, "quiet").ok)
        assertEquals("allow", fake.ops["p|RUN_ANY_IN_BACKGROUND"]); assertEquals("ignore", fake.ops["p|POST_NOTIFICATION"]); assertNull(fake.ops["p|RUN_IN_BACKGROUND"]); assertEquals(20, fake.buckets["p"]); assertTrue(m.entries().isEmpty())
    }
    @Test fun onlyPackagesLunarDisabledAreTrackedAndReEnabled() {
        fake.installed.addAll(listOf("a", "b")); fake.disabled.add("b")
        assertTrue(m.change(PkgT("a"), "disabled", "opt").changed); assertFalse(m.change(PkgT("b"), "disabled", "opt").changed)
        assertEquals(listOf("pkg|a"), m.entries().map { it.key })
        for (e in m.entries()) m.release(targetOf(e.key)!!, "opt"); assertEquals(setOf("b"), fake.disabled)
    }

    // ---------- serialization
    @Test fun concurrentChangesAreSerializedAndNoRecordIsLost() {
        for (i in 0 until 16) fake.settings[key("k$i")] = "0"
        val go = CountDownLatch(1); val done = CountDownLatch(16)
        for (i in 0 until 16) Thread { go.await(); m.change(SettingT("global", "k$i"), "1", "t"); done.countDown() }.start()
        go.countDown(); assertTrue(done.await(20, TimeUnit.SECONDS)); assertEquals(16, m.entries().size)
    }
    @Test fun nestedMutatorCallsOnTheWorkerThreadDoNotDeadlock() {
        fake.settings[key("foo")] = "1"; val r = m.serial { m.change(foo, "5", "t").ok && m.release(foo, "t").ok }; assertTrue(r)
    }
}
