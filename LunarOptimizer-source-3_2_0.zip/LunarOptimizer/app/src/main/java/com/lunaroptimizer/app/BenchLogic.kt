package com.lunaroptimizer.app

import java.util.Locale

// Pure logic for benchmark mode (JVM-testable): the score log, the honest comparison, and the readiness checks.
class BenchRun(val ts: Long, val app: String, val score: Long, val tempC: Float, val modeOn: Boolean)
class Ready(val ok: Boolean, val text: String)
class BStat(val n: Int, val avg: Double, val best: Long)

object BenchLogic {
    fun encode(l: List<BenchRun>) = l.joinToString("\n") { listOf(it.ts, it.app.replace("|", "/"), it.score, String.format(Locale.US, "%.1f", it.tempC), if (it.modeOn) 1 else 0).joinToString("|") }
    fun decode(s: String): List<BenchRun> = s.lines().mapNotNull { l -> val p = l.split("|"); if (p.size != 5) null else try { BenchRun(p[0].toLong(), p[1], p[2].toLong(), p[3].toFloat(), p[4] == "1") } catch (e: Exception) { null } }
    fun stat(l: List<BenchRun>, app: String, on: Boolean): BStat? = l.filter { it.app == app && it.modeOn == on }.let { r -> if (r.isEmpty()) null else BStat(r.size, r.map { it.score }.average(), r.maxOf { it.score }) }
    /** Never claims a gain without evidence: needs 3 runs per side, and anything under 3% is reported as noise. */
    fun verdict(on: BStat?, off: BStat?): String {
        if (on == null || off == null) return "Run it with the mode on and off to compare."
        if (on.n < 3 || off.n < 3) return "Not enough runs yet (${on.n} on, ${off.n} off). Need 3 of each; one run varies by a few percent on its own."
        val d = (on.avg - off.avg) / off.avg * 100
        return if (Math.abs(d) < 3.0) "%+.1f%% on average: within normal run-to-run noise, no proven difference.".format(Locale.US, d) else "%+.1f%% on average over ${on.n} runs with the mode on vs ${off.n} off.".format(Locale.US, d)
    }
    /** Rules of thumb, not guarantees: a hot or charging phone, battery saver or low free RAM all lower scores. */
    fun readiness(tempC: Float, thermal: Int?, charging: Boolean, saver: Boolean, availPct: Int): List<Ready> = listOf(
        Ready(tempC <= 32f, "Battery temperature %.1f °C (aim for 32 °C or less, let it cool first)".format(Locale.US, tempC)),
        Ready((thermal ?: 0) == 0, "Thermal status ${when (thermal) { null -> "not reported"; 0 -> "none"; 1 -> "light"; 2 -> "moderate"; 3 -> "severe"; else -> "critical" }}"),
        Ready(!charging, if (charging) "Charging: unplug it, charging heat lowers scores" else "Not charging"),
        Ready(!saver, if (saver) "Battery saver is on: turn it off" else "Battery saver off"),
        Ready(availPct >= 35, "$availPct% of RAM available (aim for 35% or more, run Prepare)"))
}
