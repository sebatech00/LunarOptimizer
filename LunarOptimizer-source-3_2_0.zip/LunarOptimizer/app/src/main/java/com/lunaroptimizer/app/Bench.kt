package com.lunaroptimizer.app

import android.app.AlertDialog
import android.content.Context
import android.provider.Settings
import android.text.InputType
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

/** Benchmark mode. Only does what can be verified or measured: quiet background apps (journaled), 120 Hz window (journaled),
 *  per-app Game Mode request (reported as accepted or refused), and a pre-run cleanup. It does NOT use fixed-performance mode
 *  (that sets a lower, steady clock and would lower a score) and does not touch thermal protection. Everything restores from the journal. */
object Bench {
    var on: Boolean get() = Store.getS("bench_on") == "1"; private set(v) { Store.putS("bench_on", if (v) "1" else "") }
    val since: Long get() = Store.getS("bench_since")?.toLongOrNull() ?: 0L
    fun log(): List<BenchRun> = BenchLogic.decode(Store.getS("bench_log") ?: "")
    fun addRun(r: BenchRun) { Store.putS("bench_log", BenchLogic.encode((log() + r).takeLast(80))) }
    private fun bootCount(c: Context) = try { Settings.Global.getInt(c.contentResolver, "boot_count", -1) } catch (e: Throwable) { -1 }
    @Volatile private var checked = false

    fun apps(a: MainActivity): List<Pair<String, String>> = Debloat.load(a).filter { it.installed && Regex("antutu|geekbench|primatelabs", RegexOption.IGNORE_CASE).containsMatchIn(it.id) }.map { it.id to it.label }

    private fun gameMode(a: MainActivity, enable: Boolean): List<String> {
        val ls = ArrayList<String>(); val rec = (Store.getS("bench_game") ?: "").split(",").filter { it.isNotEmpty() }.toMutableSet()
        val pk = if (enable) apps(a).map { it.first } else rec.toList()
        for (p in pk) { val r = Sh.exec("cmd game mode ${if (enable) "performance" else "standard"} $p", true, 20000); val ok = Parse.gameModeOk(r.out + r.err, r.code)
            if (ok) { if (enable) rec.add(p) else rec.remove(p) }
            ls.add(if (ok) "✓ Game Mode ${if (enable) "performance" else "standard"}: $p (accepted; effect on the score is not proven)" else "✗ Game Mode $p: refused (${(r.out + r.err).trim().take(70).ifEmpty { "exit ${r.code}" }}). Normal for apps that do not declare Game Mode support") }
        Store.putS("bench_game", rec.joinToString(",")); return ls
    }
    /** Candidates to quiet: running, non-protected third-party apps, biggest first (never the benchmark apps themselves). */
    private fun runningUsers(a: MainActivity, notes: MutableList<String>): List<Pair<Pkg, Int>> {
        val prot = Auto.protectedMap(a, notes); if (prot.containsKey("*")) return emptyList()
        val bench = apps(a).map { it.first }.toSet(); val rss = Auto.rss()
        return Debloat.load(a).filter { it.cat == Cat.USER && it.installed && it.enabled && it.id !in bench && !prot.containsKey(it.id) && (rss[it.id] ?: 0) > 0 }.map { it to (rss[it.id] ?: 0) }.sortedByDescending { it.second }.take(40)
    }
    /** Pre-run cleanup: force-stops the running candidates. They restart when opened. Safe to repeat before every run. */
    fun prepare(a: MainActivity, say: (String) -> Unit): List<String> {
        val notes = ArrayList<String>(); say("Checking what must stay untouched"); val u = runningUsers(a, notes)
        if (u.isEmpty()) return listOf(if (notes.isNotEmpty()) "✗ ${notes.first()}" else "✓ no running third-party apps to stop")
        var n = 0; var mb = 0
        for ((i, p) in u.withIndex()) { say("${i + 1}/${u.size}  ${p.first.label}"); if (Sh.exec("am force-stop ${p.first.id}", true, 20000).ok) { n++; mb += p.second } }
        Store.log("bench", "Prepare run", "stopped $n apps, ~$mb MB"); return listOf("✓ stopped $n running apps (about $mb MB resident). MemAvailable now ${Sys.fmt(Pipeline.mem().first, 1024)}")
    }
    fun enable(a: MainActivity, say: (String) -> Unit): List<String> {
        val ls = ArrayList<String>(); val notes = ArrayList<String>(); val u = runningUsers(a, notes); var q = 0
        for ((i, p) in u.withIndex()) { say("Restricting ${i + 1}/${u.size}  ${p.first.label}"); if (Engine.quietOne(p.first.id, "bench").ok) q++ }
        ls.add(if (u.isEmpty() && notes.isNotEmpty()) "✗ ${notes.first()}" else "✓ background-restricted $q of ${u.size} running apps (journaled, survives reboot)")
        val hz = try { a.display?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 0f } catch (e: Throwable) { 0f }
        if (hz >= 119f) { say("Refresh rate window"); for (k in listOf("peak_refresh_rate", "min_refresh_rate")) { val r = Pipeline.put("system", k, "120", false, "bench"); ls.add("${if (r.st == SS.FAILED || r.st == SS.IGNORED) "✗" else "✓"} $k: ${r.detail}") } } else ls.add("• panel does not offer 120 Hz: refresh window skipped")
        say("Game Mode"); ls.addAll(gameMode(a, true))
        say("Stopping running apps"); ls.addAll(prepare(a, say))
        Store.putS("bench_on", "1"); Store.putS("bench_since", System.currentTimeMillis().toString()); Store.putS("bench_boot", bootCount(a).toString()); checked = true
        Store.log("bench", "Benchmark mode ON", ls.joinToString("; ")); return ls
    }
    fun disable(a: MainActivity): List<String> {
        val ls = ArrayList<String>()
        for (e in Mut.m.entries().filter { "bench" in it.owners }) { val t = targetOf(e.key) ?: continue; val o = Mut.m.release(t, "bench"); ls.add((if (o.ok) "✓ " else "✗ ") + o.detail) }
        ls.addAll(gameMode(a, false)); Store.putS("bench_on", ""); Prompts.clear("bench"); Store.log("bench", "Benchmark mode OFF", ls.joinToString("; ")); return ls
    }
    /** After a reboot or app restart: the journaled parts persist, so just remind, and flag the reboot (a fresh boot is the best starting state). */
    fun ensure(a: MainActivity) {
        if (!on || checked) return; checked = true
        val rebooted = bootCount(a) != (Store.getS("bench_boot")?.toIntOrNull() ?: -1) && bootCount(a) >= 0
        val hrs = (System.currentTimeMillis() - since) / 3600000L
        Prompts.set(Prompts.P("bench", "Benchmark mode is on", (if (rebooted) "The phone rebooted since you turned it on: restrictions and the refresh window are still in place, a fresh boot is a good state for a run. " else "") + (if (hrs >= 6) "It has been on for ${hrs} h and costs battery. " else "") + "Open it to prepare a run or turn it off.", "Open", { a.ui { a.push(BenchPage(a)) } }))
        if (rebooted) Store.putS("bench_boot", bootCount(a).toString())
    }
}

class BenchPage(a: MainActivity) : Page(a) {
    private lateinit var host: LinearLayout
    private var busy = false
    private val df = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
    override fun build(): View = with(act) { scaffold("Benchmark mode", "AnTuTu and Geekbench") { host = col {}; add(host) } }
    override fun onShow() { render() }
    private fun progress(title: String, work: ((String) -> Unit) -> List<String>) {
        if (busy) return; busy = true
        val st = with(act) { host.removeAllViews(); tv("Starting…", 14f, cText) }; with(act) { host.card(4, 16) { add(tv(title, 16f, cText, "sans-serif-medium")); add(st, 8) } }
        act.bg { val ls = try { work { t -> act.ui { st.text = t } } } catch (e: Throwable) { Store.err("bench: " + e.stackTraceToString().take(400)); listOf("✗ failed: ${e.message}") }
            act.ui { busy = false; render(ls) } }
    }
    private fun askScore(pkg: String, label: String) = with(act) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "Score"; setTextColor(cText); setHintTextColor(cDim) }
        val b = Sys.battery(this)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Score for $label").setMessage("Mode is ${if (Bench.on) "ON" else "OFF"}, battery %.1f °C now.".format(Locale.US, b.tempC)).setView(et)
            .setPositiveButton("Save") { _, _ -> et.text.toString().toLongOrNull()?.let { Bench.addRun(BenchRun(System.currentTimeMillis(), pkg, it, b.tempC, Bench.on)); render() } }.setNegativeButton("Cancel", null).show()
    }
    private fun render(result: List<String>? = null): Unit = with(act) {
        host.removeAllViews(); val on = Bench.on; val apps = Bench.apps(act)
        host.card(4, 14, true) {
            add(tv(if (on) "ON since ${df.format(Date(Bench.since))}" else "OFF", 18f, if (on) cGood else cText, "sans-serif-semibold"))
            add(tv("Stays on across reboots until you turn it off. It restricts running third-party apps in the background, opens a 120 Hz window and asks the benchmark apps for Game Mode performance. Turning it off restores everything from the journal.", 11f, cDim), 6)
            add(btn(if (on) "Turn off and restore" else "Turn on", !on) {
                if (!Sh.granted()) { toast("Shizuku isn't authorized"); return@btn }
                if (on) progress("Restoring") { Bench.disable(act) } else dialog("Turn on benchmark mode?", "Running third-party apps are force-stopped and restricted in the background until you turn this off. Messaging apps and anything protected stay untouched.", "Turn on", "Cancel") { progress("Turning on") { say -> Bench.enable(act, say) } }
            }, 12)
        }
        if (result != null) host.card(10, 14) { add(tv("Result", 14f, cText, "sans-serif-medium")); for (l in result) add(tv(l, 11f, if (l.startsWith("✗")) cBad else if (l.startsWith("✓")) cGood else cDim), 3) }
        val b = Sys.battery(act); val m = Sys.memory(act); val rd = BenchLogic.readiness(b.tempC, b.thermal, b.charging, b.saver, if (m.total > 0) (m.avail * 100 / m.total).toInt() else 0)
        host.add(section("Before you run")); host.card(0, 14) { for (r in rd) add(tv((if (r.ok) "✓ " else "✗ ") + r.text, 12f, if (r.ok) cGood else cWarn), 3); add(btn("Prepare run (stop running apps)") { if (Sh.granted()) progress("Preparing") { say -> Bench.prepare(act, say) } else toast("Shizuku isn't authorized") }.compact(), 8, WRAP); add(btn("Re-check") { render() }.compact(), 6, WRAP) }
        host.add(section("Benchmark apps"))
        if (apps.isEmpty()) host.card(0, 14) { add(tv("No AnTuTu or Geekbench found. Install one, then reopen this page.", 13f, cDim)) }
        val lg = Bench.log()
        for ((pkg, label) in apps) host.card(8, 14) {
            add(tv(label, 14f, cText, "sans-serif-medium")); add(tv(pkg, 10f, cDim), 1)
            val v = BenchLogic.verdict(BenchLogic.stat(lg, pkg, true), BenchLogic.stat(lg, pkg, false)); add(tv(v, 11f, cDim), 4)
            BenchLogic.stat(lg, pkg, true)?.let { add(kv("Mode on", "avg ${it.avg.toLong()} · best ${it.best} · ${it.n} runs")) }; BenchLogic.stat(lg, pkg, false)?.let { add(kv("Mode off", "avg ${it.avg.toLong()} · best ${it.best} · ${it.n} runs")) }
            add(row { add(btn("Launch", true) { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }.compact(), w = WRAP); add(btn("Log a score") { askScore(pkg, label) }.compact(), w = WRAP, start = 8) }, 8)
        }
        host.add(section("Manual steps Lunar cannot do")); host.card(0, 14) { for (l in listOf("Settings > Battery: set Performance mode if your build offers it.", "Security app > Game Turbo: add the benchmark app.", "Take the case off and let the phone cool, unplug the charger.", "Reboot, then run only the benchmark. Run 3 times and compare averages.", "Scores change run to run by a few percent. Only the log above tells you whether this mode helps.")) add(tv("• $l", 11f, cDim), 4) }
        if (lg.isNotEmpty()) { host.add(section("Recent runs")); host.card(0, 14) { for (r in lg.takeLast(8).reversed()) add(tv("${df.format(Date(r.ts))}  ${r.app.substringAfterLast('.')}  ${r.score}  %.1f °C  ${if (r.modeOn) "on" else "off"}".format(Locale.US, r.tempC), 11f, cDim), 3) } }
    }
}
