package com.lunaroptimizer.app

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import kotlin.math.abs

/** Shizuku bridge: runs shell-level (uid 2000, or root if Shizuku runs as root) commands. */
object Sh : Shell {
    const val REQ = 4242
    class R(val out: String, val err: String, val code: Int) { val ok get() = code == 0; fun text() = (out + (if (err.isNotBlank()) "\n" + err else "")).trim() }
    fun installed(c: Context) = try { c.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true } catch (e: Exception) { false }
    @Volatile var err = ""
    fun running() = try { Shizuku.pingBinder() } catch (e: Throwable) { err = e.javaClass.simpleName + ": " + (e.message ?: ""); false }
    fun diag(): String = "provider calls ${ProvDiag.calls}" + (if (ProvDiag.last.isNotEmpty()) " (last ${ProvDiag.last})" else "") + " · ping ${running()}" + (if (err.isNotEmpty()) " · client error $err" else "") + (if (ProvDiag.err.isNotEmpty()) " · provider error ${ProvDiag.err}" else "")
    fun granted() = try { running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    fun uid() = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
    fun who() = when (val u = uid()) { 0 -> "root"; 2000 -> "shell"; -1 -> "n/a"; else -> "uid $u" }
    fun request() { try { Shizuku.requestPermission(REQ) } catch (e: Throwable) { Store.err("Shizuku request: ${e.message}") } }
    fun state(c: Context) = if (granted()) 3 else if (running()) 2 else if (installed(c)) 1 else 0

    @Volatile private var tmo: Boolean? = null
    /** Every command is bounded twice: by the shell's own `timeout` (when the device has it) and by the client-side wait below. */
    private fun hasTimeout(): Boolean { tmo?.let { return it }; val r = raw("command -v timeout", 6000); val v = r.code == 0 && r.out.contains("timeout"); tmo = v; return v }
    private fun wrap(cmd: String, ms: Long): String = if (!hasTimeout()) cmd else "timeout -k 2 ${maxOf(1L, ms / 1000 - 1)} sh -c '" + cmd.replace("'", "'\\''") + "'"
    private fun raw(cmd: String, timeoutMs: Long): R = try {
        val p = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
        val so = StringBuilder(); val se = StringBuilder()
        val t1 = Thread { try { so.append(p.inputStream.bufferedReader().readText()) } catch (e: Exception) {} }
        val t2 = Thread { try { se.append(p.errorStream.bufferedReader().readText()) } catch (e: Exception) {} }
        t1.start(); t2.start(); t1.join(timeoutMs)
        val timedOut = t1.isAlive
        val code = if (timedOut) { try { p.destroy() } catch (e: Throwable) {}; -3 } else try { if (p.waitForTimeout(3000, java.util.concurrent.TimeUnit.MILLISECONDS)) p.exitValue() else { try { p.destroy() } catch (e: Throwable) {}; -3 } } catch (e: Throwable) { -2 }
        t2.join(1500)
        R(so.toString(), if (code == -3) "timeout after ${timeoutMs / 1000}s" else se.toString(), code)
    } catch (e: Throwable) { Store.err("exec: ${e.javaClass.simpleName}: ${e.message}"); R("", e.message ?: "error", -2) }
    override fun exec(cmd: String, log: Boolean, timeoutMs: Long): R {
        if (!granted()) return R("", "Shizuku not authorized", -1)
        val t0 = System.nanoTime()
        var r = raw(wrap(cmd, timeoutMs), timeoutMs)
        if (r.code == 124 || r.code == 137) r = R(r.out, "timeout after ${timeoutMs / 1000}s", -3)
        val ms = (System.nanoTime() - t0) / 1_000_000
        if (log) Con.cmd(cmd, r, ms) else if (Con.verbose) Con.brief(cmd, r, ms)
        return r
    }
    fun stream(cmd: String, timeoutMs: Long, onLine: (String) -> Unit): R {
        if (!granted()) return R("", "Shizuku not authorized", -1)
        return try {
            val p = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null); val so = StringBuilder(); val se = StringBuilder()
            val t1 = Thread { try { p.inputStream.bufferedReader().forEachLine { so.append(it).append('\n'); onLine(it) } } catch (e: Exception) {} }
            val t2 = Thread { try { se.append(p.errorStream.bufferedReader().readText()) } catch (e: Exception) {} }
            t1.start(); t2.start(); t1.join(timeoutMs); val to = t1.isAlive
            val code = if (to) { try { p.destroy() } catch (e: Throwable) {}; -3 } else try { p.waitFor() } catch (e: Throwable) { -2 }
            t2.join(1500); R(so.toString(), if (to) "timeout" else se.toString(), code)
        } catch (e: Throwable) { R("", e.message ?: "error", -2) }
    }
    /** Fire-and-forget: runs detached so long jobs never block the UI or the pipe. */
    fun bgJob(cmd: String): R = exec("nohup sh -c '" + cmd.replace("'", "'\\''") + "' >/dev/null 2>&1 </dev/null & echo started", true, 15000)
}

object Con {
    private val lines = ArrayList<String>()
    @Volatile var sink: ((String) -> Unit)? = null
    @Volatile var verbose = false
    fun brief(c: String, r: Sh.R, ms: Long) { add("$ " + (if (c.length > 90) c.take(90) + "…" else c)); add("  [exit ${r.code} · $ms ms]") }
    @Synchronized fun add(s: String) { lines.add(s); if (lines.size > 500) lines.removeAt(0); sink?.invoke(s) }
    @Synchronized fun all(): List<String> = ArrayList(lines)
    @Synchronized fun clear() { lines.clear() }
    fun cmd(c: String, r: Sh.R, ms: Long) {
        add("$ " + (if (c.length > 140) c.take(140) + "…" else c))
        r.text().lines().filter { it.isNotBlank() }.take(8).forEach { add("  $it") }
        add("  [exit ${r.code} · $ms ms]")
    }
}

object Tele {
    class Snap(val cpu: Float?, val freqs: IntArray, val maxs: IntArray, val temps: Map<String, Float>, val hot: Pair<String, Float>?, val gpuMhz: Int?, val gpuBusy: Int?)
    private var prev: LongArray? = null
    private var types: Map<String, String>? = null
    private var maxF = IntArray(8)

    fun read(): Snap? {
        if (!Sh.granted()) return null
        if (types == null) {
            types = Sh.exec("grep -H . /sys/class/thermal/thermal_zone*/type 2>/dev/null", false).out.lines().mapNotNull { l -> val i = l.lastIndexOf(':'); if (i < 0) null else l.substring(0, i).substringBeforeLast('/') to l.substring(i + 1).trim() }.toMap()
            Sh.exec("grep -H . /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq 2>/dev/null", false).out.lines().forEach { l -> Regex("cpu(\\d+)/cpufreq/cpuinfo_max_freq:(\\d+)").find(l)?.let { m -> val i = m.groupValues[1].toInt(); if (i < 8) maxF[i] = m.groupValues[2].toInt() / 1000 } }
        }
        val r = Sh.exec("head -1 /proc/stat; echo @@; grep -H . /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq 2>/dev/null; echo @@; grep -H . /sys/class/thermal/thermal_zone*/temp 2>/dev/null; echo @@; cat /sys/class/kgsl/kgsl-3d0/gpuclk /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null", false)
        val p = r.out.split("@@"); if (p.size < 4) return null
        var cpu: Float? = null
        val n = p[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (n.size >= 5) {
            val cur = longArrayOf(n.take(8).sum(), n[3] + n[4]); val pv = prev; prev = cur
            if (pv != null && cur[0] > pv[0]) cpu = (100f * (1f - (cur[1] - pv[1]).toFloat() / (cur[0] - pv[0]))).coerceIn(0f, 100f)
        }
        val fr = IntArray(8)
        p[1].lines().forEach { l -> Regex("cpu(\\d+)/cpufreq/scaling_cur_freq:(\\d+)").find(l)?.let { m -> val i = m.groupValues[1].toInt(); if (i < 8) fr[i] = m.groupValues[2].toInt() / 1000 } }
        val grp = HashMap<String, Float>(); var hot: Pair<String, Float>? = null
        p[2].lines().forEach { l ->
            val i = l.lastIndexOf(':'); if (i < 0) return@forEach
            val v = l.substring(i + 1).trim().toLongOrNull() ?: return@forEach; val c = if (v > 1000) v / 1000f else v.toFloat(); if (c < 1f || c > 150f) return@forEach
            val t = types?.get(l.substring(0, i).substringBeforeLast('/')) ?: return@forEach; val lt = t.lowercase()
            val k = when { lt.contains("cpu") -> "CPU"; lt.contains("gpu") -> "GPU"; lt.contains("skin") -> "Skin"; lt.contains("batt") -> "Batt"; else -> null }
            if (k != null && (grp[k] ?: 0f) < c) grp[k] = c
            if (hot == null || c > hot!!.second) hot = t to c
        }
        val g = p[3].trim().lines(); val gv = g.getOrNull(0)?.trim()?.toLongOrNull()
        return Snap(cpu, fr, maxF.copyOf(), grp, hot, gv?.let { if (it > 1_000_000) (it / 1_000_000).toInt() else it.toInt() }, g.getOrNull(1)?.filter { it.isDigit() }?.toIntOrNull())
    }
}

class Ent(val kind: String, val ns: String, val key: String, val on: String) {
    fun read() = if (kind == "dc") "device_config get $ns $key" else "settings get $kind $key"
    fun put(v: String) = if (kind == "dc") "device_config put $ns $key $v" else "settings put $kind $key $v"
    fun del() = if (kind == "dc") "device_config delete $ns $key" else "settings delete $kind $key"
    val oKey get() = "o|$kind|$ns|$key"
}
class Tw(val id: String, val group: String, val name: String, val desc: String, val effect: String, val risk: String, val ents: List<Ent>,
         val pre: String? = null, val post: String? = null, val note: String = "")

object TE {
    private const val SYNC_OFF = "device_config set_sync_disabled_for_tests persistent"
    private const val SYNC_ON = "device_config set_sync_disabled_for_tests none"
    private fun g(k: String, v: String) = Ent("global", "", k, v)
    private fun sy(k: String, v: String) = Ent("system", "", k, v)
    private fun se(k: String, v: String) = Ent("secure", "", k, v)
    val all = listOf(
        Tw("blur", "Smoothness", "No window blur", "Disables compositor blur", "Less GPU work in shade, dialogs and recents.", "Flatter look.", listOf(g("disable_window_blurs", "1"))),
        Tw("hzpeak", "Smoothness", "Allow 120 Hz (adaptive)", "Peak refresh rate only", "System may use up to 120 Hz while LTPO keeps adapting.", "None.", listOf(sy("peak_refresh_rate", "120.0")), note = "HyperOS may ignore it"),
        Tw("hz120", "Smoothness", "Lock 120 Hz", "Peak and minimum refresh rate", "Constant 120 Hz.", "More battery use.", listOf(sy("peak_refresh_rate", "120.0"), sy("min_refresh_rate", "120.0")), note = "HyperOS may use its own key"),
        Tw("hz60", "Smoothness", "Lock 60 Hz", "Peak and minimum refresh rate", "Lower panel power draw.", "Less smooth.", listOf(sy("peak_refresh_rate", "60.0"), sy("min_refresh_rate", "60.0")), note = "HyperOS may use its own key"),
        Tw("longpress", "Smoothness", "Fast long-press", "Long-press delay 250 ms", "Menus and drag start sooner.", "Accidental long-presses are easier.", listOf(se("long_press_timeout", "250"))),
        Tw("phantom", "Memory", "Phantom-process killer off", "Stops child-process culling", "Helper processes of games and emulators survive.", "Slightly more background load.", listOf(g("settings_enable_monitor_phantom_procs", "false"), Ent("dc", "activity_manager", "max_phantom_processes", "2147483647")), SYNC_OFF, SYNC_ON),
        Tw("cached", "Memory", "Keep 48 apps cached", "Raises cached-process limit", "More apps stay warm, fewer cold starts.", "More RAM pressure.", listOf(Ent("dc", "activity_manager", "max_cached_processes", "48")), SYNC_OFF, SYNC_ON),
        Tw("compact", "Memory", "App memory compaction", "Compacts cached apps' memory", "More free RAM from idle apps.", "Small CPU cost.", listOf(Ent("dc", "activity_manager", "use_compaction", "true")), SYNC_OFF, SYNC_ON, "Effect unverified"),
        Tw("freezer", "Memory", "Freeze cached apps", "Freezes cached app processes", "Cached apps use no CPU.", "Needs kernel support.", listOf(Ent("dc", "activity_manager_native_boot", "use_freezer", "true")), SYNC_OFF, SYNC_ON, "Effect unverified"),
        Tw("doze", "Battery", "Faster Doze", "Deep idle after 1 min still", "Deep idle starts sooner when still and unplugged.", "Delays background sync for apps that are not exempt.", listOf(g("device_idle_constants", "inactive_to=60000,motion_inactive_to=60000,light_after_inactive_to=30000")), note = "Effect unverified on HyperOS 3"),
        Tw("scans", "Battery", "Stop background scans", "Wi-Fi and Bluetooth scanning", "Fewer idle wakeups.", "Location accuracy may drop.", listOf(g("wifi_scan_always_enabled", "0"), g("ble_scan_always_enabled", "0"))),
        Tw("saver", "Battery", "Battery Saver on", "Android Battery Saver", "Limits background work.", "Throttled performance.", listOf(g("low_power", "1"))),
        Tw("saver20", "Battery", "Auto Battery Saver at 20%", "Trigger level", "Saver starts by itself.", "None.", listOf(g("low_power_trigger_level", "20"))),
        Tw("adaptive", "Battery", "Adaptive Battery", "Learns app usage", "Restricts apps you rarely open.", "None.", listOf(g("adaptive_battery_management_enabled", "1"))),
        Tw("autorestrict", "Battery", "Auto-restrict rare apps", "Background limits for unused apps", "Less drain from forgotten apps.", "Delayed notifications.", listOf(g("app_auto_restriction_enabled", "true"))),
        Tw("mdalways", "Battery", "Mobile data off on Wi-Fi", "Stops keeping mobile data up", "Less radio drain on Wi-Fi.", "Slower Wi-Fi to mobile handover.", listOf(g("mobile_data_always_on", "0"))),
        Tw("timeout30", "Battery", "Screen timeout 30 s", "Screen-off delay", "Less screen-on time.", "Screen sleeps while reading.", listOf(sy("screen_off_timeout", "30000"))),
        Tw("dns", "Network", "Private DNS (Cloudflare)", "one.one.one.one over TLS", "Encrypted DNS.", "Speed benefit varies.", listOf(g("private_dns_mode", "hostname"), g("private_dns_specifier", "one.one.one.one"))),
        Tw("dnsad", "Network", "Block ads and trackers (DNS)", "AdGuard DNS over TLS", "Ad and tracker domains, including Xiaomi telemetry hosts, stop resolving.", "If the DNS server is unreachable lookups fail (Lunar Optimizer checks and reverts). Apps with their own DNS bypass it.", listOf(g("private_dns_mode", "hostname"), g("private_dns_specifier", "dns.adguard-dns.com")), note = "Needs internet"),
        Tw("wifinotif", "Network", "Mute open Wi-Fi notices", "Network-available prompts", "Fewer prompts and scans.", "None.", listOf(g("wifi_networks_available_notification_on", "0")))
    )
    fun byId(id: String) = all.first { it.id == id }
    private fun same(a: String, b: String): Boolean { val x = a.trim().toFloatOrNull(); val y = b.trim().toFloatOrNull(); return if (x != null && y != null) abs(x - y) < 0.001f else a.trim() == b.trim() }

    fun snapshot(): Map<String, String> {
        val out = Sh.exec("echo @@global; settings list global; echo @@system; settings list system; echo @@secure; settings list secure; echo @@activity_manager; device_config list activity_manager; echo @@activity_manager_native_boot; device_config list activity_manager_native_boot", false, 30000).out
        val m = HashMap<String, String>(); var sec = ""
        for (l in out.lines()) { if (l.startsWith("@@")) sec = l.substring(2) else { val i = l.indexOf('='); if (i > 0) m["$sec.${l.substring(0, i)}"] = l.substring(i + 1) } }
        return m
    }
    fun states(): Map<String, Boolean> {
        val m = snapshot()
        return all.associate { t -> t.id to t.ents.all { e -> same(m["${if (e.kind == "dc") e.ns else e.kind}.${e.key}"] ?: "null", e.on) } }
    }
    private fun tgt(e: Ent): Target = if (e.kind == "dc") DcT(e.ns, e.key) else SettingT(e.kind, e.key)
    /** Applies every entry of a tweak as one transaction through the journal (validated original, read-back verify, rollback on failure). */
    fun apply(t: Tw): Pair<Boolean, List<String>> {
        val m = Mut.m; val ls = ArrayList<String>(); var ok = true
        m.serial {
            val done = ArrayList<Ent>()
            for (e in t.ents) {
                val o = if (e.kind == "dc") m.changeDc(tgt(e) as DcT, e.on, t.id) else m.change(tgt(e), e.on, t.id)
                ls.add(o.detail + (if (o.ok) "  OK" else "  REJECTED"))
                if (!o.ok) { ok = false; break }
                done.add(e)
            }
            if (!ok) for (e in done.reversed()) { val r = if (e.kind == "dc") m.releaseDc(tgt(e) as DcT, t.id) else m.release(tgt(e), t.id); ls.add("rolled back: " + r.detail) }
        }
        if (ok) Store.addL("tweaks", 1)
        Store.log("tweak", t.name, (if (ok) "Applied, verified by read-back: " else "Not applied (all changes of this tweak rolled back): ") + ls.joinToString("; "))
        return ok to ls
    }
    fun revert(t: Tw): Pair<Boolean, List<String>> {
        val m = Mut.m; val ls = ArrayList<String>(); var ok = true
        m.serial {
            for (e in t.ents) {
                val o = if (e.kind == "dc") m.releaseDc(tgt(e) as DcT, t.id) else m.release(tgt(e), t.id)
                if (!o.ok || o.detail.contains("no Lunar record")) ok = false
                ls.add(o.detail + if (o.detail.contains("no Lunar record")) " (set outside Lunar: change it in system settings)" else "")
            }
        }
        Store.log("tweak", t.name + " reverted", ls.joinToString("; "))
        return ok to ls
    }
}

object Boost {
    class Res(val stor: Long, val ramB: Long, val ramA: Long, val pB: Int, val pA: Int, val ms: Long, val failed: List<String>, val compiled: Int, val total: Int)
    fun procs() = Sh.exec("ps -A | wc -l", false).out.trim().toIntOrNull() ?: -1
    fun dexStats(): Map<String, Int> {
        val o = Sh.exec("dumpsys package dexopt", false, 40000).out; val m = HashMap<String, Int>()
        Regex("\\[status=([a-z-]+)\\]").findAll(o).forEach { m[it.groupValues[1]] = (m[it.groupValues[1]] ?: 0) + 1 }; return m
    }
    fun run(c: Context, prog: (Int, String) -> Unit): Res {
        val t0 = System.currentTimeMillis(); val failed = ArrayList<String>()
        val ramB = Sys.memory(c).avail; val stB = Sys.storage(c).second; val pB = procs()
        prog(8, "Snapshot")
        prog(12, "Trimming app caches (only if storage is low)"); val (dt0, df0) = Pipeline.df(); if (dt0 > 0 && df0 * 100 / dt0 < 15 && !Sh.exec("pm trim-caches 999g", true, 120000).ok) failed.add("trim caches")
        prog(50, "Background apps are left alone (no blanket kill)")
        prog(70, "Starting TRIM and dexopt"); if (!Sh.bgJob("sm idle-maint run; cmd package bg-dexopt-job").ok) failed.add("maintenance jobs")
        prog(85, "Reading dexopt state"); val ds = dexStats()
        Thread.sleep(1200)
        val comp = (ds["speed-profile"] ?: 0) + (ds["speed"] ?: 0) + (ds["everything"] ?: 0)
        val r = Res(Sys.storage(c).second - stB, ramB, Sys.memory(c).avail, pB, procs(), System.currentTimeMillis() - t0, failed, comp, ds.values.sum())
        Store.addL("boosts", 1); if (r.stor > 0) Store.addL("trimmed", r.stor); Store.putS("last_boost", "${r.stor}|${r.ramB}|${r.ramA}|${r.pB}|${r.pA}|${r.ms}")
        Store.log("boost", "Lunar Boost", "Storage ${if (r.stor >= 0) "+" else ""}${Sys.fmt(r.stor)} free · RAM ${Sys.fmt(r.ramB, 1024)} -> ${Sys.fmt(r.ramA, 1024)} · processes ${r.pB} -> ${r.pA} · ${r.ms} ms")
        prog(100, "Done"); return r
    }
}
