package com.lunaroptimizer.app

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.*
import android.widget.*
import org.json.JSONArray
import java.util.Locale

/** mode 0 = full pipeline, 1 = post-reboot verification, 2 = compile phase only, 3 = dry run (shows what would run and why not, changes nothing) */
class OptimizePage(a: MainActivity, private val mode: Int = 0) : Page(a) {
    private lateinit var host: LinearLayout
    private lateinit var ring: RingView; private lateinit var opTv: TextView; private lateinit var timeTv: TextView
    private lateinit var list: LinearLayout; private lateinit var term: TextView; private lateinit var termSv: ScrollView
    private class RowV(val status: TextView, val bar: BarView, val detail: TextView)
    private val rows = ArrayList<RowV>()
    private var t0 = 0L; private var started = false; private var cancelled = false; private var curRow = -1; private var curStart = 0L; private var curLong = false; private var cd = 15
    private lateinit var cdTv: TextView
    private val tick = object : Runnable { override fun run() {
        if (::timeTv.isInitialized) { val s = (System.currentTimeMillis() - t0) / 1000; timeTv.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60) }
        if (curRow in rows.indices && curLong) { val s = (System.currentTimeMillis() - curStart) / 1000; rows[curRow].status.text = String.format(Locale.US, "running %02d:%02d", s / 60, s % 60) }
        act.handler.postDelayed(this, 1000) } }
    private val cdTick = object : Runnable { override fun run() { cd--; cdTv.text = "Rebooting in $cd s"; if (cd <= 0) reboot() else act.handler.postDelayed(this, 1000) } }

    override fun build(): View = with(act) { scaffold("Optimize", scroll = false) { host = col {}; add(host, 0, MATCH, 0, 1f) } }
    override fun onShow() { if (!started) { started = true; if (mode == 1) verify() else run() } }
    override fun onDestroy() { cancelled = true; act.handler.removeCallbacks(tick); act.handler.removeCallbacks(cdTick); Con.sink = null; Con.verbose = false }

    private fun progressView() = with(act) {
        host.removeAllViews(); rows.clear()
        host.card(0, 12, true) {
            ring = RingView(act); add(ring, 0, MATCH, dp(130)); ring.set(0f, "0%", "Phase 0", cViolet)
            opTv = tv("", 13f, cText).apply { gravity = Gravity.CENTER }; add(opTv, 2)
            timeTv = tv("00:00", 11f, cDim).apply { gravity = Gravity.CENTER }; add(timeTv, 2)
        }
        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }; list = col {}; sv.addView(list); host.add(sv, 8, MATCH, 0, 1f)
        host.card(8, 10) {
            background = GradientDrawable().apply { setColor(0xAA000000.toInt()); cornerRadius = dpf(16f); setStroke(dp(1), 0x33FFFFFF) }
            termSv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }; term = tv("", 10f, cSilver).apply { typeface = Typeface.MONOSPACE }; termSv.addView(term); add(termSv, 0, MATCH, dp(150))
        }
        host.add(btn("Cancel") { cancelled = true; opTv.text = "Stopping after this step…" }.compact(), 8)
        Con.clear(); Con.verbose = true; Con.sink = { l -> act.ui { term.append(l + "\n"); if (term.length() > 9000) term.text = term.text.toString().takeLast(6000); termSv.post { termSv.fullScroll(View.FOCUS_DOWN) } } }
        t0 = System.currentTimeMillis(); act.handler.removeCallbacks(tick); act.handler.post(tick)
    }
    private fun prog(p: Int, label: String, t: String) { ring.set(p / 100f, "$p%", label, if (p >= 100) cGood else cViolet); opTv.text = t }
    private fun finish() { act.handler.removeCallbacks(tick); Con.sink = null; Con.verbose = false }
    private fun msg(t: String, again: Boolean = true) = with(act) { host.removeAllViews(); host.card(4, 16) { add(tv(t, 14f, cText)); if (again) add(btn("Run again", true) { started = true; if (mode == 1) verify() else run() }, 12) } }
    private fun stColor(s: SS) = when (s) { SS.APPLIED -> cGood; SS.IGNORED -> cWarn; SS.FAILED -> cBad; SS.SKIPPED -> cDim }
    private fun stText(s: SS) = s.name.lowercase()
    private fun buildRows(steps: List<Step>) = with(act) {
        list.removeAllViews(); rows.clear()
        for (s in steps) list.card(6, 10) {
            val st = tv("0%", 12f, cDim, "sans-serif-medium"); add(row { add(tv(s.title, 12f, cText, "sans-serif-medium"), w = 0, weight = 1f); add(st, w = WRAP, start = 8) })
            val bar = BarView(act); add(bar, 6, MATCH, dp(4)); val dt = tv("Phase ${s.phase}", 10f, cDim); add(dt, 4); rows.add(RowV(st, bar, dt))
        }
    }
    private fun setRow(i: Int, text: String, color: Int, frac: Float, detail: String? = null) { if (i !in rows.indices) return; val r = rows[i]; r.bar.color = color; r.bar.v = frac; r.status.text = text; r.status.setTextColor(color); if (detail != null) r.detail.text = detail.take(120) }

    private fun run() {
        if (!Sh.granted()) { with(act) { host.removeAllViews(); host.card(4, 16) { add(tv("Shizuku isn't authorized.", 14f, cWarn)); add(btn("Open Settings", true) { switchTab(4) }, 12) } }; return }
        if (mode == 0) {
            val b = Sys.battery(act)
            if (!b.charging && b.pct < 50) { act.dialog("Better while charging", "Battery is ${b.pct}% and not charging. Optimizing runs compile and cleanup work that is best done plugged in and idle.", "Run anyway", "Cancel") { go(false) }; return }
            if ((b.thermal ?: 0) >= 2) { act.dialog("Phone is warm", "Thermal status is ${Sys.thermalText(b.thermal)}. Let it cool down first for a fair result.", "Run anyway", "Cancel") { go(false) }; return }
        }
        go(false)
    }
    private fun go(frame: Boolean) {
        cancelled = false; progressView()
        act.bg {
            try {
                val pl3 = if (mode == 3) Pipeline.plan(act) else null
                val steps = if (pl3 != null) pl3.map { it.step } else if (mode == 2) Pipeline.steps(act).filter { it.phase == 3 } else Pipeline.steps(act)
                if (mode == 0) {
                    Con.add("== Phase 0: baseline ==")
                    val base = Pipeline.measure(act) { s -> act.ui { prog(8, "Phase 0", s) } }
                    Store.putS("p0", base.json()); Con.add("baseline saved: MemAvailable ${Sys.fmt(base.memAvail, 1024)}, /data free ${Sys.fmt(base.dataFree)}")
                }
                act.ui { buildRows(steps) }
                if (mode == 3) {
                    val pl = pl3!!
                    act.ui { for ((i, p) in pl.withIndex()) setRow(i, if (p.run) "would run" else "skip", if (p.run) cIce else cDim, 1f, if (p.run) "evidence found" else p.why); finish(); prog(100, "Preview", "Dry run: nothing was changed") }
                    return@bg
                }
                val res = ArrayList<Triple<String, SS, String>>()
                for ((i, s) in steps.withIndex()) {
                    val pct = (if (mode == 0) 20 else 0) + (if (mode == 0) 75 else 100) * i / maxOf(1, steps.size)
                    if (cancelled) { res.add(Triple(s.title, SS.SKIPPED, "cancelled")); act.ui { setRow(i, "skipped", cDim, 1f, "cancelled") }; continue }
                    Con.add("== Phase ${s.phase}: ${s.title} ==")
                    act.ui { curRow = i; curStart = System.currentTimeMillis(); curLong = s.long; prog(pct, "Phase ${s.phase}", s.title); setRow(i, "running", cIce, 0.08f) }
                    val r = try { s.run(act) } catch (e: Throwable) { Store.err("step ${s.id}: " + e.stackTraceToString().take(300)); StepRes(SS.FAILED, e.message ?: e.javaClass.simpleName) }
                    Con.add("${stText(r.st)}: ${r.detail.take(110)}"); res.add(Triple(s.title, r.st, r.detail)); Store.log("pipeline", s.title, "${r.st}: ${r.detail.take(150)}")
                    act.ui { curRow = -1; curLong = false; setRow(i, stText(r.st), stColor(r.st), 1f, r.detail) }
                }
                val ja = JSONArray(); res.forEach { ja.put(JSONArray().put(it.first).put(it.second.name).put(it.third)) }; Store.putS("run_steps", ja.toString())
                if (mode == 0) { Store.putS("pending_verify", "1"); act.ui { finish(); prog(100, "Done", "Optimization finished"); showReboot(res) } }
                else act.ui { finish(); showResults(null, null, res, null) }
            } catch (e: Throwable) { Store.err("pipeline: " + e.stackTraceToString().take(500)); act.ui { finish(); msg("Failed: ${e.message}") } }
        }
    }

    private fun showReboot(res: List<Triple<String, SS, String>>) = with(act) {
        host.removeAllViews(); cd = 15
        host.card(4, 16, true) {
            add(tv("Optimization finished", 21f, cText, "sans-serif-semibold"))
            add(tv("${res.count { it.second == SS.APPLIED }} applied · ${res.count { it.second == SS.IGNORED }} ignored · ${res.count { it.second == SS.FAILED }} failed · ${res.count { it.second == SS.SKIPPED }} skipped", 13f, cSilver), 6)
            add(tv("A reboot finishes it. After the reboot start Shizuku again, then open Lunar Optimizer to verify against the baseline.", 12f, cDim), 8)
            cdTv = tv("Rebooting in $cd s", 16f, cWarn, "sans-serif-medium"); add(cdTv, 12)
        }
        host.add(btn("Reboot now", true) { act.handler.removeCallbacks(cdTick); reboot() }, 12)
        host.add(btn("Cancel reboot") { act.handler.removeCallbacks(cdTick); cdTv.text = "Reboot cancelled. Verification stays pending." }, 8)
        host.add(btn("Manual checklist") { act.handler.removeCallbacks(cdTick); cdTv.text = "Reboot paused."; push(ChecklistPage(act)) }, 8)
        act.handler.removeCallbacks(cdTick); act.handler.postDelayed(cdTick, 1000)
    }
    private fun reboot() { Store.log("reboot", "Pipeline", "svc power reboot"); act.bg { val r = Sh.exec("svc power reboot"); if (!r.ok) act.ui { act.toast("Reboot failed (exit ${r.code}). Reboot manually.") } } }

    private fun verify() {
        if (!Sh.granted()) { with(act) { host.removeAllViews(); host.card(4, 16) { val c = col {}; add(c); fillLink(act, c); add(btn("Check again", true) { started = true; verify() }, 12) } }; return }
        val b = Perf.from(Store.getS("p0")); if (b == null) { msg("No baseline stored. Run Optimize Now first.", false); return }
        verifyGo(b, false)
    }
    private fun verifyGo(b: Perf, frame: Boolean) {
        cancelled = false; progressView()
        act.bg {
            try {
                Con.add("== Phase 6: verify =="); val a2 = Pipeline.measure(act) { s -> act.ui { prog(40, "Phase 6", s) } }
                val ev: StepRes? = null
                val steps = try { val ja = JSONArray(Store.getS("run_steps") ?: "[]"); (0 until ja.length()).map { val x = ja.getJSONArray(it); Triple(x.getString(0), SS.valueOf(x.getString(1)), x.getString(2)) } } catch (e: Throwable) { emptyList() }
                Store.putS("pending_verify", ""); Store.addL("boosts", 1)
                act.ui { finish(); showResults(b, a2, steps, ev) }
            } catch (e: Throwable) { Store.err("verify: " + e.stackTraceToString().take(400)); act.ui { finish(); msg("Verification failed: ${e.message}") } }
        }
    }

    private fun showResults(b: Perf?, a2: Perf?, steps: List<Triple<String, SS, String>>, ev: StepRes?) = with(act) {
        val root = this@OptimizePage.host; root.removeAllViews()
        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false }; val body = col {}; sv.addView(body); root.add(sv, 0, MATCH, 0, 1f)
        val host = body
        host.card(4, 16, true) { add(tv(if (a2 != null) "Results after reboot" else "Compile finished", 21f, cText, "sans-serif-semibold")); add(tv("Real deltas only, including zero or negative ones.", 11f, cDim), 4) }
        if (b != null && a2 != null) {
            fun d(label: String, x: Float?, y: Float?, unit: String, lowerBetter: Boolean, dec: Int = 0) = host.let { _ ->
                val ok = x != null && y != null && x >= 0 && y >= 0
                val diff = if (ok) y!! - x!! else 0f
                val col = if (!ok || abs0(diff)) cText else if ((diff < 0) == lowerBetter) cGood else cBad
                val fmt = "%.${dec}f"
                list2.add(Triple(label, if (ok) "${String.format(Locale.US, fmt, x)} → ${String.format(Locale.US, fmt, y)}$unit (${if (diff > 0) "+" else ""}${String.format(Locale.US, fmt, diff)})" else "n/a", col))
            }
            list2.clear()
            d("MemAvailable", b.memAvail / 1048576f, a2.memAvail / 1048576f, " MB", false)
            d("Free storage", b.dataFree / 1e9f, a2.dataFree / 1e9f, " GB", false, 1)
            d("Thermal state", b.thermal.toFloat(), a2.thermal.toFloat(), "", true)
            host.add(section("Before and after"))
            host.card(0, 14) { for ((l, v, c) in list2) add(kv(l, v, c)); add(tv("MemAvailable varies run to run.", 10f, cDim), 6) }
        }
        host.add(section("Steps"))
        host.card(0, 14) {
            val all = steps + (if (ev != null) listOf(Triple("max_cached_processes post-reboot check", ev.st, ev.detail)) else emptyList())
            if (all.isEmpty()) add(tv("No steps recorded.", 12f, cDim))
            for ((i, t) in all.withIndex()) { if (i > 0) add(View(act).apply { setBackgroundColor(0x1AFFFFFF) }, 8, MATCH, 1); add(row { setPadding(0, dp(8), 0, 0); add(tv(t.first, 12f, cText, "sans-serif-medium"), w = 0, weight = 1f); add(tv(stText(t.second), 11f, stColor(t.second), "sans-serif-medium"), w = WRAP, start = 8) }); add(tv(t.third.take(160), 10f, cDim), 2) }
        }
        host.add(section("Options"))
        host.card(0, 14) {
            add(toggle("Refresh lock 120 Hz", "min = peak = 120. Costs battery; off restores your original minimum", Pipeline.lockOn()) { on -> bg { val r = Pipeline.setLock(on); ui { toast(r.take(120)) } } })
            add(toggle("Disable App Vault", "com.mi.globalminusscreen. Loses the swipe-left feed", Store.appVault) { on -> bg { val r = Pipeline.setVault(act, on); ui { toast(r.take(120)) } } })
        }
        host.add(btn("Restore all disabled apps") { bg { val l = Pipeline.restoreAll(act); ui { dialog("Restore all", l.joinToString("\n").ifEmpty { "Nothing was disabled" }) } } }, 12)
        host.add(btn("Manual checklist") { push(ChecklistPage(act)) }, 8)
        host.add(tv("Re-run the compile phase after every OS update or large app update. Home will suggest it.", 11f, cDim), 12)
        host.add(btn("Done", true) { pop() }, 12); host.add(View(act), 0, MATCH, dp(16))
    }
    private val list2 = ArrayList<Triple<String, String, Int>>()
    private fun abs0(f: Float) = Math.abs(f) < 0.0001f
}

class ChecklistPage(a: MainActivity) : Page(a) {
    private class It(val id: String, val title: String, val note: String, val label: String? = null, val go: (() -> Unit)? = null)
    override fun build(): View = with(act) {
        val (t, f) = Sys.storage(act); val dka = try { Settings.Global.getInt(contentResolver, "always_finish_activities", 0) } catch (e: Exception) { -1 }
        val items = listOf(
            It("mem", "Memory extension off or minimum", "Settings > Additional settings > Memory extension [Unverified path]", "Settings") { openSettings(Settings.ACTION_SETTINGS, "Settings") },
            It("fx", "Blur and heavy effects off", "Settings > Display, and Accessibility effects options", "Display") { openSettings(Settings.ACTION_DISPLAY_SETTINGS, "Display") },
            It("lw", "Live wallpaper off", "Use a static wallpaper", "Wallpaper") { open(Intent(Intent.ACTION_SET_WALLPAPER)) },
            It("car", "Lock screen carousel off", "Settings > Lock screen > Wallpaper carousel", "Settings") { openSettings(Settings.ACTION_SETTINGS, "Settings") },
            It("ads", "Ad services, personalized recommendations, diagnostic data off", "Settings > Privacy > Ad services, User Experience Program. Also inside GetApps (if enabled), Themes and Security", "Privacy") { openSettings(Settings.ACTION_PRIVACY_SETTINGS, "Privacy") },
            It("wid", "Remove unused widgets", "Long-press the home screen"),
            It("dev", "Developer options: background process limit Standard, Don't keep activities OFF", "Don't keep activities is currently ${if (dka == 1) "ON (turn it off)" else if (dka == 0) "OFF" else "unreadable"}. Never touch Force GPU rendering, Disable HW overlays or Force 4x MSAA.", "Developer") { openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, "Developer options") },
            It("perf", "Optional: Performance mode in Battery settings", "More heat and battery use; reviews say it isn't always faster when sustained", "Battery") { openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS, "Battery") },
            It("rec", "Lock main apps in recents", "Open recents, long-press the app card, tap the lock"),
            It("sto", "Keep 20%+ storage free", "Currently ${String.format(Locale.US, "%.0f", 100.0 * f / t)}% free"))
        scaffold("Manual checklist") {
            add(tv("Nothing here is automated. Tick items off as you do them.", 12f, cDim))
            for (i in items) card(8, 14) {
                add(row {
                    add(col { add(tv(i.title, 14f, cText, "sans-serif-medium")); add(tv(i.note, 11f, cDim), 3) }, w = 0, weight = 1f)
                    add(glassSwitch(Store.getS("chk_${i.id}") == "1").apply { setOnCheckedChangeListener { _, b -> Store.putS("chk_${i.id}", if (b) "1" else "") } }, w = WRAP, start = 10)
                })
                if (i.go != null) add(btn(i.label ?: "Open") { i.go.invoke() }.compact(), 10, WRAP)
            }
        }
    }
}
