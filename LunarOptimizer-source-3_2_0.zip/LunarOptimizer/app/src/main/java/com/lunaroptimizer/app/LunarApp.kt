package com.lunaroptimizer.app

import android.app.Application
import android.content.Context
import android.content.pm.ProviderInfo
import android.os.Bundle
import rikka.shizuku.ShizukuProvider
import java.io.File

object CrashLog {
    private fun f(c: Context) = File(c.filesDir, "last_crash.txt")
    fun install(c: Context) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e -> try { f(c).writeText(e.stackTraceToString().take(6000)) } catch (x: Throwable) {}; prev?.uncaughtException(t, e) }
    }
    fun take(c: Context): String? = try { val x = f(c); if (x.exists()) x.readText().also { x.delete() } else null } catch (e: Throwable) { null }
}

class LunarApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        CrashLog.install(base); Fonts.init(base)
        try { ShizukuProvider.disableAutomaticSuiInitialization() } catch (t: Throwable) {}
    }
}

object ProvDiag { @Volatile var calls = 0; @Volatile var last = ""; @Volatile var err = "" }

/** Provider that can never take the process down: no Sui reflection at startup, every call guarded. */
class LunarShizukuProvider : ShizukuProvider() {
    override fun attachInfo(context: Context?, info: ProviderInfo?) { try { super.attachInfo(context, info) } catch (t: Throwable) { } }
    override fun onCreate(): Boolean = true
    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        ProvDiag.calls++
        return try { val r = super.call(method, arg, extras); ProvDiag.last = "$method -> ping=${try { rikka.shizuku.Shizuku.pingBinder() } catch (e: Throwable) { false }}"; r }
        catch (t: Throwable) { ProvDiag.err = t.javaClass.simpleName + ": " + t.message + " @ " + t.stackTrace.firstOrNull(); ProvDiag.last = method; try { Store.err("provider.call: " + ProvDiag.err) } catch (x: Throwable) {}; null }
    }
}
