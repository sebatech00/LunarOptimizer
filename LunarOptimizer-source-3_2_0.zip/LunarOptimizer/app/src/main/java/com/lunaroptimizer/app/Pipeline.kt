package com.lunaroptimizer.app

import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs

enum class SS { APPLIED, IGNORED, FAILED, SKIPPED }
class StepRes(val st: SS, val detail: String)
class Step(val id: String, val phase: Int, val title: String, val long: Boolean = false, val run: (MainActivity) -> StepRes)
class Perf(val jank: Float, val p50: Int, val p90: Int, val p95: Int, val p99: Int, val frames: Int, val cold: Map<String, Int>, val memAvail: Long, val memTotal: Long, val dataFree: Long, val dataTotal: Long, val thermal: Int, val temp: Float?) {
    fun json(): String = JSONObject().put("j", jank.toDouble()).put("a", p50).put("b", p90).put("c", p95).put("d", p99).put("f", frames).put("m", memAvail).put("t", memTotal).put("df", dataFree).put("dt", dataTotal).put("th", thermal)
        .put("tp", temp?.toDouble() ?: -1.0).put("cold", JSONObject(cold as Map<*, *>)).toString()
    companion object { fun from(s: String?): Perf? = try { val o = JSONObject(s!!); val c = o.getJSONObject("cold"); Perf(o.getDouble("j").toFloat(), o.getInt("a"), o.getInt("b"), o.getInt("c"), o.getInt("d"), o.getInt("f"), c.keys().asSequence().associateWith { c.getInt(it) }, o.getLong("m"), o.getLong("t"), o.getLong("df"), o.getLong("dt"), o.getInt("th"), o.getDouble("tp").let { if (it < 0) null else it.toFloat() }) } catch (e: Throwable) { null } }
}

object Pipeline {
    val BLOCK = setOf("com.xiaomi.joyose", "com.xiaomi.xmsf", "com.miui.powerkeeper", "com.miui.securitycenter", "com.miui.home")
    val DEBLOAT = listOf("com.miui.analytics", "com.miui.msa.global", "com.miui.systemAdSolution", "com.miui.daemon", "com.miui.bugreport", "com.xiaomi.mipicks", "com.miui.hybrid", "com.miui.hybrid.accessory", "com.xiaomi.glgm")
    const val VAULT = "com.mi.globalminusscreen"
    private const val LOW_MEM = 0.20f
    private fun fl(s: String) = s.trim().toFloatOrNull()
    private fun eq(a: String, b: String) = if (fl(a) != null && fl(b) != null) abs(fl(a)!! - fl(b)!!) < 0.001f else a.trim() == b.trim()

    fun mem(): Pair<Long, Long> { var av = 0L; var t = 0L; try { File("/proc/meminfo").forEachLine { if (it.startsWith("MemAvailable:")) av = it.filter { c -> c.isDigit() }.toLong() * 1024; if (it.startsWith("MemTotal:")) t = it.filter { c -> c.isDigit() }.toLong() * 1024 } } catch (e: Exception) {}; return av to t }
    fun df(): Pair<Long, Long> { val l = Sh.exec("df -k /data", false).out.lines().lastOrNull { it.isNotBlank() }?.trim()?.split(Regex("\\s+")); return if (l != null && l.size >= 4) ((l[1].toLongOrNull() ?: 0) * 1024) to ((l[3].toLongOrNull() ?: 0) * 1024) else (0L to 0L) }

    // ---- journaled primitives (Section A): validated original, verified write, restore only when the last owner leaves
    fun put(ns: String, key: String, v: String, unv: Boolean = false, owner: String = "optimize"): StepRes {
        val o = Mut.m.change(SettingT(ns, key), v, owner)
        return when {
            o.ok && o.changed -> StepRes(SS.APPLIED, "${o.before} -> ${o.after}" + if (unv) " [Unverified: stored, effect not confirmed]" else "")
            o.ok -> StepRes(SS.SKIPPED, "already ${o.after}: nothing to change")
            o.rejected -> StepRes(SS.IGNORED, o.detail.substringAfter(": "))
            else -> StepRes(SS.FAILED, o.detail.substringAfter(": ").take(110))
        }
    }
    fun restoreKey(ns: String, key: String, owner: String = "optimize"): String = Mut.m.release(SettingT(ns, key), owner).detail.substringAfter(": ")
    fun lockOn() = fl(Sh.exec("settings get system min_refresh_rate", false).out) == 120f
    fun setLock(on: Boolean): String = if (on) put("system", "min_refresh_rate", "120", false, "lock").detail + "; " + put("secure", "miui_refresh_rate", "120", true, "lock").detail
        else "min_refresh_rate: ${restoreKey("system", "min_refresh_rate", "lock")}; miui_refresh_rate: ${restoreKey("secure", "miui_refresh_rate", "lock")}"

    fun enabled(a: MainActivity, p: String): Boolean? = try { a.packageManager.getApplicationEnabledSetting(p).let { it < 2 } } catch (e: Exception) { null }
    /** Disables a package. Only packages Lunar itself disabled are recorded (and therefore ever re-enabled by Lunar). */
    fun disable(a: MainActivity, p: String, owner: String = "optimize"): StepRes {
        if (p in BLOCK) return StepRes(SS.SKIPPED, "blocklisted")
        val en = enabled(a, p) ?: return StepRes(SS.SKIPPED, "not installed")
        if (!en) return StepRes(SS.SKIPPED, "already disabled (not by Lunar, left as is)")
        val o = Mut.m.change(PkgT(p), "disabled", owner)
        return when { o.ok && o.changed -> StepRes(SS.APPLIED, "disabled, re-read: disabled"); o.rejected -> StepRes(SS.IGNORED, "command accepted, package still enabled"); o.ok -> StepRes(SS.SKIPPED, "already disabled"); else -> StepRes(SS.FAILED, o.detail.substringAfter(": ").take(100)) }
    }
    /** Re-enables exactly the packages in the journal (that Lunar disabled). Nothing else is touched. */
    fun restoreAll(a: MainActivity): List<String> {
        val ls = ArrayList<String>()
        for (e in Mut.m.entries().filter { it.key.startsWith("pkg|") }) { val t = targetOf(e.key) ?: continue; val o = Mut.m.restore(t, true); ls.add("${(t as PkgT).pkg}: ${if (o.ok) "restored" else "FAILED (" + o.detail.substringAfter(": ").take(60) + ")"}") }
        Store.appVault = false; Store.log("restore", "Restore all", ls.joinToString("; ")); return ls
    }
    fun setVault(a: MainActivity, on: Boolean): String { Store.appVault = on; return if (on) disable(a, VAULT, "vault").let { "${it.st}: ${it.detail}" } else Mut.m.release(PkgT(VAULT), "vault").detail.substringAfter(": ") }

    private fun compileStep(p: String): StepRes { val r = Sh.exec("cmd package compile -m speed -f $p", true, 300000); return if (r.ok && r.out.contains("Success")) StepRes(SS.APPLIED, "Success") else if (r.ok) StepRes(SS.IGNORED, r.text().take(90)) else StepRes(SS.FAILED, "exit ${r.code}: ${r.text().take(80)}") }

    // ---- Section I: every step needs evidence that it helps this phone right now; otherwise it is skipped with the reason.
    class Plan(val step: Step, val run: Boolean, val why: String)
    private val AOT_BAD = setOf("verify", "run-from-apk", "extract", "quicken", "assume-verified", "error")
    fun plan(a: MainActivity): List<Plan> {
        val l = ArrayList<Plan>()
        fun st(id: String, ph: Int, title: String, long: Boolean = false, f: (MainActivity) -> StepRes) = Step(id, ph, title, long, f)
        // 1. animation scales: only keys that are not 1.0 (no 0.5x anywhere)
        for (k in listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")) {
            val c = SettingT("global", k).read(Sh); val need = !c.ok || !(c.v.toFloatOrNull()?.let { abs(it - 1f) < 0.001f } ?: false)
            l.add(Plan(st("a_$k", 1, "$k = 1.0") { put("global", k, "1.0") }, need, if (need) "" else "already 1.0"))
        }
        // 2. refresh rate: peak 120 only when the panel offers it and it is not already allowed. No forced minimum, no 60 Hz.
        val hz = try { a.display?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 0f } catch (e: Throwable) { 0f }
        val pk = SettingT("system", "peak_refresh_rate").read(Sh); val needPk = hz >= 119f && (!pk.ok || (pk.v.toFloatOrNull() ?: 0f) < 119f)
        l.add(Plan(st("peakhz", 1, "peak_refresh_rate = 120") { put("system", "peak_refresh_rate", "120") }, needPk, if (hz < 119f) "panel does not offer 120 Hz" else "peak already ${pk.v}"))
        // 3. curated telemetry/ad packages that are installed and enabled
        for (p in DEBLOAT) { val en = enabled(a, p); l.add(Plan(st("d_$p", 2, "Disable $p") { x -> disable(x, p) }, en == true && p !in BLOCK, if (en == null) "not installed" else "already disabled")) }
        l.add(Plan(st("vault", 2, "Disable $VAULT (optional)") { x -> disable(x, VAULT, "vault") }, Store.appVault && enabled(a, VAULT) == true, if (!Store.appVault) "optional toggle is off" else "already disabled or not installed"))
        // 4. ART: the system's own dexopt job, only when there is evidence the compiled code is outdated
        val per = Engine.dex().second; val bad = per.values.count { it in AOT_BAD }; val sug = suggest(a)
        val needJob = sug != null || bad >= 5
        l.add(Plan(st("bgdex", 3, "System dexopt job (after OS/app updates)", true) { x -> dexJob() }, needJob, "no evidence: OS and apps unchanged since the last run, $bad apps not AOT-compiled"))
        for ((id, pk2) in listOf("chome" to "com.miui.home", "cui" to "com.android.systemui")) { val s0 = per[pk2]; val need = s0 != null && s0 in AOT_BAD + "speed-profile"
            l.add(Plan(st(id, 3, "compile speed $pk2", true) { compileStep(pk2) }, need, if (s0 == null) "dexopt status unknown" else "already $s0")) }
        // 5. caches: only when storage is actually low
        val (dt, df0) = df(); val freePct = if (dt > 0) (df0 * 100 / dt).toInt() else 100; val low = dt > 0 && freePct < 15
        l.add(Plan(st("trim", 3, "pm trim-caches") { _ -> val b = df().second; val r = Sh.exec("pm trim-caches 999G", true, 180000); val af = df().second; if (r.ok) StepRes(SS.APPLIED, "free ${Sys.fmt(b)} -> ${Sys.fmt(af)}") else StepRes(SS.FAILED, "exit ${r.code}: ${r.text().take(80)}") }, low, "$freePct% of /data is free: trimming caches would only slow apps down"))
        l.add(Plan(st("stor", 3, "Storage check /data") { _ -> val (t, f) = df(); val u = if (t > 0) 100 - (f * 100 / t).toInt() else -1; if (u > 80) StepRes(SS.IGNORED, "WARNING: /data is $u% full (over 80%)") else StepRes(SS.APPLIED, "/data $u% used") }, true, ""))
        // 6. RAM: only when memory is low AND specific offenders exist; nothing is killed blindly
        val (av, tot) = mem(); val ratio = if (tot > 0) av.toFloat() / tot else 1f; val lowMem = ratio < LOW_MEM
        l.add(Plan(st("clean", 4, "Stop RAM offenders (only if memory is low)", true) { x -> cleanStep(x) }, lowMem, "MemAvailable ${(ratio * 100).toInt()}% (>= ${(LOW_MEM * 100).toInt()}%): not needed"))
        return l
    }
    fun steps(a: MainActivity): List<Step> = plan(a).map { p -> if (p.run) p.step else Step(p.step.id, p.step.phase, p.step.title, false) { StepRes(SS.SKIPPED, p.why) } }

    /** Runs the system's dexopt job and cancels it if we give up waiting. */
    fun dexJob(): StepRes {
        val r = Sh.stream("cmd package bg-dexopt-job", 900_000) { Con.add("  " + it.take(100)) }
        Store.putS("compile_fp", Build.FINGERPRINT); Store.putS("compile_ts", System.currentTimeMillis().toString())
        if (r.code == -3) { Sh.exec("cmd package bg-dexopt-job --cancel", false, 20000); return StepRes(SS.IGNORED, "still running after 15 min; cancelled the job (the system continues it when idle)") }
        return if (r.ok) StepRes(SS.APPLIED, "exit 0") else StepRes(SS.FAILED, "exit ${r.code}: ${r.err.take(80)}")
    }
    private fun cleanStep(a: MainActivity): StepRes {
        val (av, _) = mem(); val notes = ArrayList<String>(); val off = DeepClean.offenders(a, notes)
        if (off.isEmpty()) return StepRes(SS.SKIPPED, "memory is low but no app is both large and measurably active in the background" + (notes.firstOrNull()?.let { ": $it" } ?: ""))
        var ok = 0; for (o in off) if (Sh.exec("am force-stop ${o.pkg}").ok) ok++
        Thread.sleep(1500); return StepRes(if (ok == off.size) SS.APPLIED else SS.FAILED, "stopped $ok of ${off.size} flagged apps; MemAvailable ${Sys.fmt(av, 1024)} -> ${Sys.fmt(mem().first, 1024)}; they restart when opened")
    }

    fun topApps(a: MainActivity): List<String> {
        Store.getS("cs_apps2")?.split(",")?.filter { it.isNotEmpty() }?.let { if (it.size == 3) return it }
        val pm = a.packageManager; val out = ArrayList<String>(); val g = DeepClean.guard(a); val bad = BLOCK + setOf("moe.shizuku.privileged.api", "com.android.settings", "com.android.vending", "com.google.android.gms")
        try { if (Sys.usageAccess(a)) { val u = a.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager; val now = System.currentTimeMillis()
            u.queryUsageStats(UsageStatsManager.INTERVAL_WEEKLY, now - 7 * 86400000L, now).sortedByDescending { it.totalTimeInForeground }.forEach { x -> val p = x.packageName; if (out.size < 3 && p != a.packageName && p !in out && p !in bad && !g(p) && !p.contains("launcher") && !p.startsWith("com.miui.home") && !p.startsWith("com.android.systemui") && pm.getLaunchIntentForPackage(p) != null) out.add(p) } } } catch (e: Throwable) {}
        for (p in listOf("com.android.chrome", "com.google.android.youtube", "com.android.camera", "com.miui.gallery", "com.google.android.apps.maps")) if (out.size < 3 && p !in out && !g(p) && pm.getLaunchIntentForPackage(p) != null) out.add(p)
        Store.putS("cs_apps2", out.joinToString(",")); return out
    }

    fun measure(a: MainActivity, say: (String) -> Unit): Perf {
        say("Memory, storage, thermal")
        val (av, t) = mem(); val dfree = df().second; val dtot = df().first
        val th = Sh.exec("dumpsys thermalservice", false, 20000).out
        val temps = Regex("mValue=([0-9.]+), mType=([0-3])").findAll(th).mapNotNull { it.groupValues[1].toFloatOrNull() }.toList()
        return Perf(-1f, -1, -1, -1, -1, 0, emptyMap(), av, t, dfree, dtot, Regex("Thermal Status:\\s*(\\d+)").find(th)?.groupValues?.get(1)?.toIntOrNull() ?: -1, temps.maxOrNull())
    }

    fun suggest(a: MainActivity): String? {
        val fp = Store.getS("compile_fp") ?: return null; val ts = Store.getS("compile_ts")?.toLongOrNull() ?: return null
        if (fp != Build.FINGERPRINT) return "The OS was updated since the last compile."
        @Suppress("DEPRECATION") val n = a.packageManager.getInstalledPackages(0).count { it.applicationInfo != null && it.applicationInfo!!.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM == 0 && it.lastUpdateTime > ts }
        return if (n >= 5) "$n apps were updated since the last compile." else null
    }
}
