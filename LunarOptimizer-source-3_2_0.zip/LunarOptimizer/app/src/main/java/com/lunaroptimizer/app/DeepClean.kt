package com.lunaroptimizer.app

import android.view.*
import android.widget.*
import java.util.Locale

class MemSnap(val avail: Long, val total: Long, val psi: Float?, val cached: Int, val procs: Int)
class Offender(val pkg: String, val label: String, val rssMb: Int, val why: String, var sel: Boolean = true)
class Junk(val path: String, val bytes: Long, val kind: String, var sel: Boolean)
class DcScan(val snap: MemSnap, val mem: MemDump?, val offenders: List<Offender>, val caches: List<Pair<String, Long>>, val junk: List<Junk>, val storFree: Long, val storTotal: Long, val notes: List<String>)

object DeepClean {
    fun snap(a: MainActivity): MemSnap {
        val m = Sys.memory(a)
        val o = Sh.exec("echo @M; cat /proc/pressure/memory 2>/dev/null; echo @P; ps -A | wc -l; echo @K; dumpsys activity processes | grep -cE 'Proc # *[0-9]+: cch'", false, 40000).out
        val sec = HashMap<String, StringBuilder>(); var k = ""
        for (l in o.lines()) { if (l.startsWith("@")) { k = l.substring(1).trim(); sec[k] = StringBuilder() } else sec[k]?.append(l)?.append('\n') }
        return MemSnap(m.avail, m.total, Regex("some avg10=([0-9.]+)").find(sec["M"]?.toString() ?: "")?.groupValues?.get(1)?.toFloatOrNull(), sec["K"]?.toString()?.trim()?.toIntOrNull() ?: -1, sec["P"]?.toString()?.trim()?.toIntOrNull() ?: -1)
    }
    /** Predicate for "never touch this package" (everything Automatic mode protects, plus messaging apps). */
    fun guard(a: MainActivity): (String) -> Boolean { val prot = Auto.protectedMap(a, ArrayList()); return { p -> prot.containsKey(p) || Planner.comms(p) } }
    private val STD = setOf("DCIM", "Pictures", "Movies", "Music", "Download", "Documents", "Alarms", "Notifications", "Ringtones", "Podcasts", "Audiobooks", "Recordings")
    private fun safePath(p: String) = p.startsWith("/sdcard/") && !p.contains("..") && !p.contains('\n') && !p.contains('\r') && !p.startsWith("/sdcard/Android")
    private fun q(p: String) = "'" + p.replace("'", "'\\''") + "'"

    /** Apps that are large AND measurably active in the background, never protected apps. Without battery evidence nothing is flagged. */
    fun offenders(a: MainActivity, notes: MutableList<String>): List<Offender> {
        val prot = Auto.protectedMap(a, notes); if (prot.containsKey("*")) return emptyList()
        val users = Debloat.load(a).filter { it.cat == Cat.USER && it.installed && it.enabled }.associateBy { it.id }
        val batt = Auto.battByPkg(notes) ?: return emptyList(); val rss = Auto.rss(); val c = AutoCfg()
        return users.values.mapNotNull { p ->
            if (prot.containsKey(p.id)) return@mapNotNull null
            val mb = rss[p.id] ?: 0; val b = batt[p.id] ?: return@mapNotNull null
            if (mb >= c.rssMin && (b.mah >= c.mahMin || (b.cpu ?: 0.0) >= 1.0 || (b.wake ?: 0.0) >= 0.5)) Offender(p.id, p.label, mb, "$mb MB in memory, %.1f mAh since last charge".format(b.mah)) else null
        }.sortedByDescending { it.rssMb }.take(15)
    }
    private fun junkScan(): List<Junk> {
        val out = ArrayList<Junk>()
        val du = Sh.exec("du -sk /sdcard/DCIM/.thumbnails /sdcard/Pictures/.thumbnails /sdcard/.thumbnails 2>/dev/null", false, 30000).out
        for (l in du.lines()) { val t = l.trim().split(Regex("\\s+"), 2); val kb = t.getOrNull(0)?.toLongOrNull() ?: continue; val pth = t.getOrNull(1) ?: continue; if (kb > 0 && safePath(pth)) out.add(Junk(pth, kb * 1024, "thumbnail cache", true)) }
        fun finds(expr: String, kind: String, sel: Boolean) { for (l in Sh.exec("find /sdcard -path /sdcard/Android -prune -o -type f $expr -exec stat -c '%s|%n' {} \\; 2>/dev/null | head -300", false, 60000).out.lines()) { val i = l.indexOf('|'); if (i < 0) continue; val sz = l.substring(0, i).toLongOrNull() ?: continue; val pth = l.substring(i + 1); if (safePath(pth)) out.add(Junk(pth, sz, kind, sel)) } }
        finds("\\( -name '*.log' -o -name '*.tmp' -o -name '*.temp' \\)", "log / temp file", true)
        finds("-name '*.apk'", "installer APK", false)
        for (pth in Sh.exec("find /sdcard -path /sdcard/Android -prune -o -mindepth 2 -type d -empty -print 2>/dev/null | head -200", false, 60000).out.lines()) {
            val t = pth.trim(); val parts = t.removePrefix("/sdcard/").split('/'); if (!safePath(t) || (parts.size == 2 && parts[0] in STD) || parts.any { it.startsWith(".") && it != ".thumbnails" }) continue; out.add(Junk(t, 0, "empty folder", true))
        }
        return out
    }
    fun scan(a: MainActivity, say: (String) -> Unit): DcScan {
        val notes = ArrayList<String>()
        say("Memory"); val s = snap(a); val md = Parse.meminfo(Sh.exec("dumpsys meminfo", false, 60000).out); if (md == null) notes.add("Detailed memory breakdown unavailable (unrecognised dumpsys meminfo output).")
        say("Background offenders (up to a minute)"); val off = offenders(a, notes)
        say("App caches"); val ds = Sh.exec("dumpsys diskstats", false, 60000).out; val caches = Parse.diskCaches(ds); if (caches.isEmpty()) notes.add("Per-app cache sizes unavailable (unrecognised dumpsys diskstats output).")
        say("Junk files"); val junk = junkScan(); notes.add("Stale dexopt artifacts cannot be listed from the shell: not scanned.")
        val (tot, free) = Pipeline.df()
        return DcScan(s, md, off, caches, junk, free, tot, notes)
    }
    fun deleteJunk(list: List<Junk>): List<String> {
        val ls = ArrayList<String>()
        for (j in list) {
            if (!safePath(j.path)) { ls.add("✗ ${j.path}: refused (outside shared storage)"); continue }
            val cmd = if (j.kind == "empty folder") "rmdir ${q(j.path)}" else if (j.kind == "thumbnail cache") "rm -rf ${q(j.path)}" else "rm -f -- ${q(j.path)}"
            val r = Sh.exec(cmd, false, 30000); val gone = Sh.exec("[ -e ${q(j.path)} ] && echo yes || echo no", false, 10000).out.trim() == "no"
            ls.add(if (r.ok && gone) "✓ deleted ${j.path} (${Sys.fmt(j.bytes)})" else "✗ ${j.path}: still present")
        }
        Store.log("deepclean", "Junk deleted", "${ls.count { it.startsWith("✓") }} of ${list.size}"); return ls
    }
}

class DeepCleanPage(a: MainActivity) : Page(a) {
    private lateinit var host: LinearLayout
    private var started = false; private var scan: DcScan? = null; private var busy = false

    override fun build(): View = with(act) { scaffold("Deep clean", "Evidence first. Nothing is killed blindly") { host = col {}; add(host) } }
    override fun onShow() { if (!started) { started = true; startScan() } }
    private fun msg(t: String, again: Boolean = true): Unit = with(act) { host.removeAllViews(); host.card(4, 16) { add(tv(t, 14f, cText)); if (again) add(btn("Scan again", true) { startScan() }, 12) } }
    private fun startScan() {
        if (!Sh.granted()) { with(act) { host.removeAllViews(); host.card(4, 16) { add(tv("Shizuku isn't authorized. Deep clean needs shell-level access.", 14f, cWarn)); add(btn("Open Settings", true) { switchTab(4) }, 12) } }; return }
        if (busy) return; busy = true
        val st = with(act) { host.removeAllViews(); tv("Starting…", 14f, cText) }; with(act) { host.card(4, 16) { add(tv("Scanning", 16f, cText, "sans-serif-medium")); add(st, 8) } }
        act.bg { try { val s = DeepClean.scan(act) { t -> act.ui { st.text = t } }; act.ui { busy = false; scan = s; show(null) } } catch (e: Throwable) { Store.err("deepclean scan: " + e.stackTraceToString().take(400)); act.ui { busy = false; msg("Scan failed: ${e.message}") } } }
    }
    private fun mb(kb: Long?) = if (kb == null) "n/a" else "${kb / 1024} MB"
    private fun show(result: List<String>?): Unit = with(act) {
        val s = scan!!; host.removeAllViews()
        host.card(4, 14, true) {
            add(kv("RAM available", "${Sys.fmt(s.snap.avail, 1024)} of ${Sys.fmt(s.snap.total, 1024)}")); add(kv("Memory pressure", "${Engine.f1(s.snap.psi)}%")); add(kv("Cached / total processes", "${s.snap.cached} / ${s.snap.procs}"))
            s.mem?.let { m -> add(kv("Swap (ZRAM) in use", if (m.zramUsedKb != null) "${mb(m.zramUsedKb)} physical for ${mb(m.zramSwapKb)}" else "n/a")); add(kv("System / native memory", "${mb((m.groups["System"] ?: 0L) + (m.groups["Persistent"] ?: 0L))} / ${mb(m.groups["Native"])}")); add(kv("Cached apps", mb(m.groups["Cached"]))) }
            add(tv("Cached apps are kept on purpose: they make launching faster. Lunar does not stop them.", 11f, cDim), 6)
        }
        if (result != null) host.card(10, 14) { add(tv("Result", 14f, cText, "sans-serif-medium")); for (l in result) add(tv(l, 11f, if (l.startsWith("✗")) cBad else if (l.startsWith("✓")) cGood else cDim), 3) }
        for (n in s.notes) host.add(tv(n, 11f, cWarn), 6)

        host.add(section("Background offenders"))
        if (s.offenders.isEmpty()) host.card(0, 14) { add(tv("No user app is both large and measurably active in the background. Nothing to stop.", 13f, cDim)) }
        else {
            val stop = btn("", true) {}; fun upd() { val sel = s.offenders.filter { it.sel }; stop.text = "Force-stop ${sel.size} apps · ${sel.sumOf { it.rssMb }} MB" }
            for (o in s.offenders) host.card(8, 12) { add(row { add(col { add(tv(o.label, 14f, cText, "sans-serif-medium")); add(tv(o.why, 11f, cDim), 2) }, w = 0, weight = 1f); add(glassSwitch(o.sel).apply { setOnCheckedChangeListener { _, b -> o.sel = b; upd() } }, w = WRAP, start = 12) }) }
            upd(); host.add(stop, 10)
            stop.setOnClickListener { val sel = s.offenders.filter { it.sel }; if (sel.isEmpty()) return@setOnClickListener
                dialog("Force-stop ${sel.size} apps?", "They stop completely (services and alarms too) and restart when opened. Freed RAM refills as apps restart. Relaunch cost is not measured.", "Stop", "Cancel") {
                    act.bg { val b = Pipeline.mem().first; val ls = sel.map { o -> if (Sh.exec("am force-stop ${o.pkg}", true, 20000).ok) "✓ stopped ${o.label}" else "✗ ${o.label}: force-stop failed" }; Thread.sleep(1500); val a2 = Pipeline.mem().first
                        Store.addL("boosts", 1); Store.log("deepclean", "Force-stop offenders", "${ls.count { it.startsWith("✓") }} apps, MemAvailable ${Sys.fmt(b, 1024)} -> ${Sys.fmt(a2, 1024)}")
                        act.ui { scan = DcScan(DeepClean.snap(act).let { MemSnap(a2, it.total, it.psi, it.cached, it.procs) }, s.mem, s.offenders.filter { it !in sel }, s.caches, s.junk, s.storFree, s.storTotal, s.notes); show(ls + "Measured MemAvailable ${Sys.fmt(b, 1024)} -> ${Sys.fmt(a2, 1024)}") } } }
            }
        }

        host.add(section("Storage"))
        val freePct = if (s.storTotal > 0) (s.storFree * 100 / s.storTotal).toInt() else -1; val low = s.storTotal > 0 && freePct < 15
        host.card(0, 14) {
            add(kv("/data free", "${Sys.fmt(s.storFree)} of ${Sys.fmt(s.storTotal)} ($freePct%)", if (low) cWarn else cText))
            if (s.caches.isNotEmpty()) { add(kv("App caches (total)", Sys.fmt(s.caches.sumOf { it.second }))); for ((p, b) in s.caches.take(5)) add(tv("$p  ·  ${Sys.fmt(b)}", 11f, cDim), 3) }
            if (low) add(btn("Trim app caches", true) { dialog("Trim caches?", "Frees cache until /data has about 20% free. Apps rebuild caches, so they can feel slower once.", "Trim", "Cancel") { act.bg { val need = (s.storTotal / 5 - s.storFree).coerceAtLeast(1L); val b = Pipeline.df().second; val r = Sh.exec("pm trim-caches $need", true, 180000); val f = Pipeline.df().second
                act.ui { show(listOf(if (r.ok) "✓ cache trim: free ${Sys.fmt(b)} -> ${Sys.fmt(f)}" else "✗ cache trim failed (exit ${r.code})")) } } } }, 10)
            else add(tv("Storage is fine, so Lunar does not offer to trim caches: it would only slow apps down.", 11f, cDim), 6)
        }

        host.add(section("Junk files (preview)"))
        if (s.junk.isEmpty()) host.card(0, 14) { add(tv("No junk files found in shared storage.", 13f, cDim)) }
        else {
            val del = btn("", true) {}; fun upd() { val sel = s.junk.filter { it.sel }; del.text = "Delete ${sel.size} items · ${Sys.fmt(sel.sumOf { it.bytes })}" }
            for (k in s.junk.groupBy { it.kind }) host.card(8, 12) {
                add(tv("${k.key}  ·  ${k.value.size} items · ${Sys.fmt(k.value.sumOf { it.bytes })}", 13f, cText, "sans-serif-medium"))
                for (j in k.value.take(6)) add(tv(j.path.removePrefix("/sdcard/") + if (j.bytes > 0) "  (${Sys.fmt(j.bytes)})" else "", 10f, cDim), 2)
                if (k.value.size > 6) add(tv("… and ${k.value.size - 6} more", 10f, cDim), 2)
                add(toggle("Include", if (k.key == "installer APK") "Off by default: you may still want the installer" else "Selected by default", k.value.first().sel) { b -> k.value.forEach { it.sel = b }; upd() }, 6)
            }
            upd(); host.add(del, 10)
            del.setOnClickListener { val sel = s.junk.filter { it.sel }; if (sel.isEmpty()) return@setOnClickListener
                dialog("Delete ${sel.size} items?", "${Sys.fmt(sel.sumOf { it.bytes })} will be deleted permanently from shared storage (not Android/data). This cannot be undone.", "Delete", "Cancel") { act.bg { val ls = DeepClean.deleteJunk(sel); act.ui { scan = DcScan(s.snap, s.mem, s.offenders, s.caches, s.junk.filter { j -> ls.none { it.startsWith("✓") && it.contains(j.path) } }, Pipeline.df().second, s.storTotal, s.notes); show(ls.take(12) + (if (ls.size > 12) listOf("… ${ls.size - 12} more") else emptyList())) } } }
            }
        }
        host.add(btn("Scan again", false) { startScan() }, 14)
    }
}
