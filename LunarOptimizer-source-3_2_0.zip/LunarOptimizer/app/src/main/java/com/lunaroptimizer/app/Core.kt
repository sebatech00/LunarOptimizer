package com.lunaroptimizer.app

import android.app.Activity
import android.app.ActivityManager
import android.app.usage.StorageStatsManager
import android.content.*
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.*
import android.os.storage.StorageManager
import android.provider.Settings
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

object Store {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("lunar_prefs", Context.MODE_PRIVATE) }
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) { sp.edit().putBoolean("haptics", v).apply() }
    var anims: Boolean
        get() = sp.getBoolean("anims", true)
        set(v) { sp.edit().putBoolean("anims", v).apply() }
    var dryRun: Boolean
        get() = sp.getBoolean("dryrun", true)
        set(v) { sp.edit().putBoolean("dryrun", v).apply() }
    var aggressive: Boolean
        get() = sp.getBoolean("aggressive", true)
        set(v) { sp.edit().putBoolean("aggressive", v).apply() }
    var appVault: Boolean
        get() = sp.getBoolean("appvault", false)
        set(v) { sp.edit().putBoolean("appvault", v).apply() }
    var packAuto: Boolean
        get() = sp.getBoolean("packauto", false)
        set(v) { sp.edit().putBoolean("packauto", v).apply() }
    var animOrig: String?
        get() = sp.getString("anim_orig", null)
        set(v) { sp.edit().putString("anim_orig", v).apply() }

    private fun arr(k: String): JSONArray = try { JSONArray(sp.getString(k, "[]")) } catch (e: Exception) { JSONArray() }
    private fun put(k: String, a: JSONArray, cap: Int) {
        val out = JSONArray(); val st = maxOf(0, a.length() - cap); for (i in st until a.length()) out.put(a.get(i))
        sp.edit().putString(k, out.toString()).apply()
    }
    @Synchronized fun log(kind: String, title: String, detail: String) {
        val a = arr("changes"); a.put(JSONObject().put("t", System.currentTimeMillis()).put("k", kind).put("n", title).put("d", detail)); put("changes", a, 200)
    }
    fun changes(): List<JSONObject> { val a = arr("changes"); return (a.length() - 1 downTo 0).map { a.getJSONObject(it) } }
    fun clearChanges() { sp.edit().remove("changes").apply() }
    @Synchronized fun err(msg: String) { val a = arr("errors"); a.put(JSONObject().put("t", System.currentTimeMillis()).put("m", msg)); put("errors", a, 80) }
    fun errors(): List<JSONObject> { val a = arr("errors"); return (a.length() - 1 downTo 0).map { a.getJSONObject(it) } }
    fun clearErrors() { sp.edit().remove("errors").apply() }
    @Synchronized fun addPending(pkg: String, op: String, label: String) { val a = arr("pending"); a.put(JSONObject().put("p", pkg).put("o", op).put("l", label)); put("pending", a, 20) }
    @Synchronized fun takePending(): List<JSONObject> { val a = arr("pending"); sp.edit().remove("pending").apply(); return (0 until a.length()).map { a.getJSONObject(it) } }
    // battery samples (only recorded while app is visible)
    @Synchronized fun sample(pct: Int, temp: Float, charging: Boolean) {
        val a = arr("samples"); val now = System.currentTimeMillis()
        if (a.length() > 0) { val l = a.getJSONArray(a.length() - 1); if (l.getInt(1) == pct && l.getBoolean(3) == charging && now - l.getLong(0) < 300_000) return }
        a.put(JSONArray().put(now).put(pct).put(if (temp.isNaN()) -99.0 else temp.toDouble()).put(charging)); put("samples", a, 400)
    }
    fun samples(): List<JSONArray> { val a = arr("samples"); return (0 until a.length()).map { a.getJSONArray(it) } }
    fun clearSamples() { sp.edit().remove("samples").apply() }
    fun getL(k: String): Long = sp.getLong("n_$k", 0L)
    fun addL(k: String, v: Long) { sp.edit().putLong("n_$k", sp.getLong("n_$k", 0L) + v).apply() }
    fun getS(k: String): String? = sp.getString("s_$k", null)
    fun putS(k: String, v: String) { sp.edit().putString("s_$k", v).apply() }
    fun orig(k: String): String? = sp.getString(k, null)
    fun setOrig(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun clearOrig(k: String) { sp.edit().remove(k).apply() }
    fun rawGet(k: String): String? = sp.getString(k, null)
    fun rawPut(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun rawRemove(k: String) { sp.edit().remove(k).apply() }
    fun rawKeys(prefix: String): List<String> = sp.all.keys.filter { it.startsWith(prefix) }
    fun resetAll() { sp.edit().clear().apply() }
}

object Sys {
    class Batt(val pct: Int, val status: Int, val plugged: Int, val tempC: Float, val mv: Int, val health: Int, val tech: String,
               val currentUa: Long?, val saver: Boolean, val thermal: Int?, val soh: Int?, val cycles: Int?) {
        val charging get() = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL && plugged != 0
    }
    class Mem(val total: Long, val avail: Long, val threshold: Long, val low: Boolean)

    @Volatile var props: Map<String, String> = emptyMap()
    fun getprop(k: String): String = try {
        val p = ProcessBuilder("getprop", k).redirectErrorStream(true).start()
        val s = p.inputStream.bufferedReader().readLine()?.trim() ?: ""; p.destroy(); s
    } catch (e: Exception) { "" }
    fun preload() {
        Thread {
            val m = HashMap<String, String>()
            for (k in listOf("ro.mi.os.version.name", "ro.mi.os.version.incremental", "ro.miui.ui.version.name", "ro.build.version.incremental", "ro.product.marketname")) m[k] = getprop(k)
            props = m
        }.start()
    }
    fun hyperOs(): String {
        val n = props["ro.mi.os.version.name"] ?: ""; val i = props["ro.mi.os.version.incremental"] ?: ""
        if (n.isNotEmpty() || i.isNotEmpty()) return (n + " " + i).trim()
        if (props.isEmpty()) return "Reading…"
        val m = props["ro.miui.ui.version.name"] ?: ""
        return if (m.isNotEmpty()) "Xiaomi UI $m (HyperOS property not present)" else "Not reliably detectable"
    }
    fun swap(): Pair<Long, Long>? = try { var t = 0L; var f = 0L; File("/proc/meminfo").forEachLine { if (it.startsWith("SwapTotal:")) t = it.filter { c -> c.isDigit() }.toLong() * 1024; if (it.startsWith("SwapFree:")) f = it.filter { c -> c.isDigit() }.toLong() * 1024 }; Pair(t, f) } catch (e: Exception) { null }
    fun isXiaomi14() = Build.DEVICE.equals("houji", true)

    fun battery(c: Context): Batt {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        val cur = try { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } catch (e: Exception) { Long.MIN_VALUE }
        val soh = try { bm.getIntProperty(10) } catch (e: Exception) { Int.MIN_VALUE }
        val cyc = i?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1
        return Batt(if (level >= 0 && scale > 0) level * 100 / scale else -1,
            i?.getIntExtra(BatteryManager.EXTRA_STATUS, 1) ?: 1, i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0,
            if (t == Int.MIN_VALUE) Float.NaN else t / 10f, i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0,
            i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 1) ?: 1, i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "",
            if (cur == Long.MIN_VALUE || cur == 0L) null else cur, pm.isPowerSaveMode,
            try { pm.currentThermalStatus } catch (e: Exception) { null },
            if (soh in 1..100) soh else null, if (cyc > 0) cyc else null)
    }
    fun statusText(s: Int) = when (s) { 2 -> "Charging"; 3 -> "Discharging"; 4 -> "Not charging"; 5 -> "Full"; else -> "Unknown" }
    fun pluggedText(p: Int): String { val l = ArrayList<String>(); if (p and 1 != 0) l.add("AC"); if (p and 2 != 0) l.add("USB"); if (p and 4 != 0) l.add("Wireless"); if (p and 8 != 0) l.add("Dock"); return if (l.isEmpty()) "Not plugged in" else l.joinToString(" + ") }
    fun healthText(h: Int) = when (h) { 2 -> "Good"; 3 -> "Overheat"; 4 -> "Dead"; 5 -> "Over voltage"; 6 -> "Unspecified failure"; 7 -> "Cold"; else -> "Unknown" }
    fun thermalText(t: Int?) = when (t) { null -> "Not supported"; 0 -> "None"; 1 -> "Light"; 2 -> "Moderate"; 3 -> "Severe"; 4 -> "Critical"; 5 -> "Emergency"; 6 -> "Shutdown"; else -> "Unknown" }

    fun memory(c: Context): Mem { val m = ActivityManager.MemoryInfo(); (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m); return Mem(m.totalMem, m.availMem, m.threshold, m.lowMemory) }
    fun storage(c: Context): Pair<Long, Long> = try {
        val sm = c.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        Pair(sm.getTotalBytes(StorageManager.UUID_DEFAULT), sm.getFreeBytes(StorageManager.UUID_DEFAULT))
    } catch (e: Exception) { val s = android.os.StatFs(Environment.getDataDirectory().path); Pair(s.totalBytes, s.availableBytes) }

    fun fmt(b: Long, base: Int = 1000): String {
        val u = base.toDouble(); val gb = b / (u * u * u)
        return if (gb >= 1) String.format(Locale.US, "%.1f GB", gb) else if (b >= base * base) String.format(Locale.US, "%.0f MB", b / (u * u)) else String.format(Locale.US, "%d KB", b / base)
    }
    fun refreshInfo(a: Activity): String {
        val d = try { a.display } catch (e: Throwable) { null } ?: return "Unknown"
        val rates = d.supportedModes.map { Math.round(it.refreshRate) }.distinct().sorted()
        return "now ${Math.round(d.refreshRate)} Hz · modes ${rates.joinToString("/")} Hz"
    }
    fun gScale(c: Context, k: String): Float = try { Settings.Global.getFloat(c.contentResolver, k) } catch (e: Exception) { -1f }
    fun timeoutText(c: Context): String { val t = try { Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT) } catch (e: Exception) { -1 }; return if (t < 0) "Unreadable" else if (t >= 60000) "${t / 60000} min" else "${t / 1000} s" }
    fun timeoutMs(c: Context): Int = try { Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT) } catch (e: Exception) { -1 }
    fun darkMode(c: Context) = (c.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
    fun dirSize(f: File?): Long { if (f == null || !f.exists()) return 0; if (f.isFile) return f.length(); var s = 0L; f.listFiles()?.forEach { s += dirSize(it) }; return s }
    fun ownCache(c: Context): Long = dirSize(c.cacheDir) + dirSize(c.externalCacheDir)
    fun clearOwnCache(c: Context) { c.cacheDir.listFiles()?.forEach { it.deleteRecursively() }; c.externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() } }
    fun canWriteSecure(c: Context) = c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
    fun usageAccess(c: Context): Boolean {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        @Suppress("DEPRECATION") val m = ao.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return m == android.app.AppOpsManager.MODE_ALLOWED
    }
}

abstract class Page(val act: MainActivity) {
    var isRoot = false
    val view: View by lazy { build() }
    abstract fun build(): View
    open fun onShow() {}
    open fun onHide() {}
    open fun onResult(req: Int, res: Int, data: Intent?) {}
    open fun onDestroy() {}

    fun scaffold(title: String, sub: String? = null, scroll: Boolean = true, body: LinearLayout.() -> Unit): View {
        val c = act
        return c.col {
            add(c.row {
                setPadding(c.dp(16), c.dp(14), c.dp(16), c.dp(6))
                if (!isRoot) add(c.tv("‹", 32f, cIce).apply { setPadding(0, 0, c.dp(16), c.dp(4)); setOnClickListener { act.pop() } }, w = WRAP)
                add(c.col { add(c.tv(title, 24f, cText, "sans-serif-semibold")) }, w = 0, weight = 1f)
            })
            val inner = c.col(16) { body() }
            if (scroll) {
                val sv = ScrollView(c).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; isFillViewport = false }
                inner.setPadding(c.dp(16), c.dp(4), c.dp(16), c.dp(28)); sv.addView(inner)
                add(sv, h = 0, weight = 1f)
            } else add(inner, h = 0, weight = 1f)
        }
    }
}

class MainActivity : Activity() {
    lateinit var content: FrameLayout
    lateinit var nav: NavBar
    val handler = Handler(Looper.getMainLooper())
    private val stacks = Array(5) { ArrayList<Page>() }
    var tab = 0
    private val pool = java.util.concurrent.Executors.newCachedThreadPool()

    private fun errView(t: Throwable): View = ScrollView(this).apply {
        setBackgroundColor(android.graphics.Color.BLACK)
        addView(TextView(this@MainActivity).apply { text = "Lunar Optimizer error (copy and send this):\n\n" + t.stackTraceToString().take(5000); setTextColor(android.graphics.Color.WHITE); textSize = 11f; setTextIsSelectable(true); setPadding(40, 100, 40, 60) })
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try { start() } catch (t: Throwable) { try { Store.err("startup: " + t.stackTraceToString().take(800)) } catch (x: Throwable) {}; setContentView(errView(t)) }
    }
    private fun start() {
        Store.init(this); Sys.preload(); Mut.migrate()
        window.statusBarColor = cBg; window.navigationBarColor = 0xFF080A1C.toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cBg) }
        content = FrameLayout(this); content.addView(BokehView(this), FrameLayout.LayoutParams(MATCH, MATCH)); root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        nav = NavBar(this) { switchTab(it) }; root.addView(nav, LinearLayout.LayoutParams(MATCH, dp(62)))
        setContentView(root)
        stacks[0].add(rootPage(0)); nav.select(0); showCurrent()
        CrashLog.take(this)?.let { c -> android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Previous crash").setMessage(c.take(1500)).setPositiveButton("OK", null).setNegativeButton("Copy") { _, _ -> copyText("crash", c) }.show() }
    }
    private fun rootPage(i: Int): Page = (when (i) { 0 -> HomePage(this); 1 -> TweaksPage(this); 2 -> DebloatPage(this); 3 -> BatteryPage(this); else -> SettingsPage(this) }).also { it.isRoot = true }
    private fun current(): Page = stacks[tab].last()
    private fun showCurrent() {
        while (content.childCount > 1) content.removeViewAt(1)
        val p = current()
        try { content.addView(p.view, FrameLayout.LayoutParams(MATCH, MATCH)); p.onShow() } catch (t: Throwable) { Store.err("page ${p.javaClass.simpleName}: " + t.stackTraceToString().take(800)); while (content.childCount > 1) content.removeViewAt(1); content.addView(errView(t), FrameLayout.LayoutParams(MATCH, MATCH)) }
    }
    fun switchTab(i: Int) { current().onHide(); tab = i; if (stacks[i].isEmpty()) stacks[i].add(rootPage(i)); nav.select(i); showCurrent() }
    fun push(p: Page) { current().onHide(); stacks[tab].add(p); showCurrent() }
    fun pop() { if (stacks[tab].size > 1) { val p = current(); p.onHide(); p.onDestroy(); stacks[tab].removeAt(stacks[tab].size - 1); showCurrent() } }
    @Deprecated("legacy back") override fun onBackPressed() { if (stacks[tab].size > 1) pop() else if (tab != 0) switchTab(0) else super.onBackPressed() }
    override fun onResume() { super.onResume(); Debloat.verifyPending(this); if (stacks[tab].isNotEmpty()) current().onShow() }
    override fun onPause() { super.onPause(); if (stacks[tab].isNotEmpty()) current().onHide() }
    @Deprecated("legacy results") override fun onActivityResult(r: Int, res: Int, d: Intent?) { super.onActivityResult(r, res, d); current().onResult(r, res, d) }

    fun bg(block: () -> Unit) { pool.execute { try { block() } catch (e: Throwable) { Store.err("bg: ${e.javaClass.simpleName} ${e.message}") } } }
    fun ui(block: () -> Unit) { runOnUiThread { try { block() } catch (e: Throwable) { Store.err("ui: ${e.javaClass.simpleName} ${e.message}") } } }
    fun canOpen(i: Intent) = i.resolveActivity(packageManager) != null
    fun open(i: Intent): Boolean = try { if (!canOpen(i)) false else { startActivity(i); true } } catch (e: Exception) { Store.err("open ${i.action}: ${e.message}"); false }
    fun openSettings(action: String, label: String): Boolean {
        val ok = open(Intent(action))
        if (!ok) { toast("$label page isn't available on this firmware — opening general Settings"); open(Intent(Settings.ACTION_SETTINGS)) }
        return ok
    }
}
