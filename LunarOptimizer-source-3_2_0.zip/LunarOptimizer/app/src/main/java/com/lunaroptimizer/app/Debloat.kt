package com.lunaroptimizer.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

enum class Risk(val label: String, val color: Int) {
    LOW("Low risk", cGood), MEDIUM("Medium risk", cWarn), HIGH("High risk", cBad), PROTECTED("Protected", cBad), UNKNOWN("Unknown", cDim)
}
enum class Cat(val label: String) {
    USER("User apps"), THIRD("Preinstalled 3rd-party"), XIAOMI("Xiaomi"), GOOGLE("Google"), SYSTEM("System components"), CRIT("Critical / protected"), UNK("Unclassified")
}
class Pkg(val label: String, val id: String, val system: Boolean, val updated: Boolean, val enabled: Boolean, val cat: Cat, val risk: Risk, val purpose: String, val installed: Boolean = true)

object Debloat {
    // Curated by package identity (not by name patterns). Purposes are from general knowledge of these packages; they are NOT verified on-device.
    private val catalog: Map<String, Pair<Risk, String>> = mapOf(
        "com.facebook.appmanager" to (Risk.LOW to "Facebook App Manager – partner stub that supports installing/updating Facebook apps."),
        "com.facebook.services" to (Risk.LOW to "Facebook Services – background support for the Facebook app."),
        "com.facebook.system" to (Risk.LOW to "Facebook partner system stub."),
        "com.netflix.partner.activation" to (Risk.LOW to "Netflix partner activation stub."),
        "com.netflix.mediaclient" to (Risk.LOW to "Netflix app."),
        "com.miui.player" to (Risk.LOW to "Mi Music player."),
        "com.xiaomi.joyose" to (Risk.HIGH to "HyperOS game performance tuner (CPU/GPU profiles). Removing it is reported to hurt gaming."),
        "com.xiaomi.migameservice" to (Risk.HIGH to "Mi Game Service: in-game features and optimizations. Reported to hurt gaming when removed."),
        "com.xiaomi.gamecenter.sdk.service" to (Risk.HIGH to "Game Center SDK backend used by Xiaomi game features."),
        "com.enhance.gameservice" to (Risk.HIGH to "Game enhancement service used by Game Turbo."),
        "com.miui.systemAdSolution" to (Risk.MEDIUM to "Xiaomi system ad solution. Not needed for calls or data."),
        "com.miui.hybrid" to (Risk.LOW to "Quick apps framework."), "com.miui.hybrid.accessory" to (Risk.LOW to "Quick apps accessory service."),
        "com.miui.translationservice" to (Risk.LOW to "Xiaomi translation service."), "com.miui.yellowpage" to (Risk.LOW to "Yellow pages / caller lookup."),
        "com.miui.compass" to (Risk.LOW to "Compass app."), "com.android.fmradio" to (Risk.LOW to "FM radio."), "com.xiaomi.payment" to (Risk.LOW to "Mi Coin payment service."),
        "com.miui.miservice" to (Risk.LOW to "Xiaomi service and feedback app."), "com.xiaomi.mirror" to (Risk.MEDIUM to "Cross-device mirroring (Xiaomi interconnect)."),
        "com.miui.daemon" to (Risk.MEDIUM to "Xiaomi background daemon; some users report battery changes after removal. Caution."),
        "com.miui.videoplayer" to (Risk.LOW to "Mi Video player."),
        "com.mi.globalbrowser" to (Risk.LOW to "Mi Browser."),
        "com.miui.notes" to (Risk.LOW to "Xiaomi Notes."),
        "com.xiaomi.scanner" to (Risk.LOW to "Xiaomi Scanner (QR / document scan)."),
        "com.miui.bugreport" to (Risk.LOW to "Xiaomi feedback / bug-report tool."),
        "com.google.android.youtube" to (Risk.LOW to "YouTube app."),
        "com.google.android.videos" to (Risk.LOW to "Google TV (Play Movies)."),
        "com.google.android.apps.youtube.music" to (Risk.LOW to "YouTube Music."),
        "com.google.android.apps.podcasts" to (Risk.LOW to "Google Podcasts."),
        "com.google.android.apps.tachyon" to (Risk.LOW to "Google Meet."),
        "com.google.android.apps.docs" to (Risk.LOW to "Google Drive."),
        "com.google.android.apps.photos" to (Risk.LOW to "Google Photos."),
        "com.google.android.apps.maps" to (Risk.LOW to "Google Maps."),
        "com.google.android.gm" to (Risk.LOW to "Gmail."),
        "com.miui.calculator" to (Risk.LOW to "Xiaomi Calculator."),
        "com.xiaomi.glgm" to (Risk.MEDIUM to "Xiaomi Games hub; may be used by Game Turbo shortcuts."),
        "com.miui.msa.global" to (Risk.MEDIUM to "MSA – Xiaomi system ad service for Xiaomi apps. Not needed for calls/data, but other Xiaomi apps may expect it."),
        "com.miui.analytics" to (Risk.MEDIUM to "Xiaomi Analytics – telemetry service. Other Xiaomi apps can call it; disabling can occasionally affect their stability on some builds."),
        "com.xiaomi.mipicks" to (Risk.MEDIUM to "GetApps – Xiaomi app store; may be the update channel for some Xiaomi apps."),
        "com.miui.gallery" to (Risk.MEDIUM to "Xiaomi Gallery – default photo viewer, handles Xiaomi Cloud sync and some camera integrations."),
        "com.miui.weather2" to (Risk.MEDIUM to "Xiaomi Weather – feeds the home-screen weather widget."),
        "com.android.deskclock" to (Risk.MEDIUM to "Clock – alarms and timers. Disabling can break alarms."),
        "com.android.chrome" to (Risk.MEDIUM to "Chrome. On some builds it also acts as the WebView provider; disabling it can break apps that embed web content."),
        "com.google.android.apps.googleassistant" to (Risk.MEDIUM to "Google Assistant / voice features."),
        "com.xiaomi.discover" to (Risk.HIGH to "Xiaomi system app updater – part of the update path for Xiaomi system apps."),
        "com.google.android.googlequicksearchbox" to (Risk.HIGH to "Google app / Search / Assistant host; many Google features depend on it.")
    )
    private val protectedIds = setOf(
        "android", "com.android.systemui", "com.android.settings", "com.android.phone", "com.android.server.telecom", "com.android.packageinstaller",
        "com.google.android.packageinstaller", "com.android.permissioncontroller", "com.google.android.permissioncontroller", "com.android.bluetooth", "com.android.nfc",
        "com.android.shell", "com.android.keychain", "com.android.inputdevices", "com.android.location.fused", "com.google.android.gms", "com.google.android.gsf",
        "com.android.vending", "com.google.android.webview", "com.google.android.ext.services", "com.google.android.captiveportallogin", "com.android.carrierconfig",
        "com.android.stk", "com.android.mms.service", "com.android.se", "com.android.ons", "com.miui.securitycenter", "com.miui.securityadd", "com.miui.powerkeeper",
        "com.miui.home", "com.miui.system", "com.miui.core", "com.xiaomi.xmsf", "com.xiaomi.finddevice", "com.miui.face", "com.miui.guardprovider", "com.miui.rom",
        "com.android.updater", "com.xiaomi.misettings", "com.miui.miwallpaper", "com.google.android.networkstack", "com.google.android.cellbroadcastreceiver"
    )
    private val protectedPrefixes = listOf("com.android.providers.", "com.android.server.", "com.android.networkstack", "com.android.wifi", "com.android.cellbroadcast", "com.qualcomm.", "com.qti.", "org.codeaurora.", "vendor.", "com.android.internal.", "com.android.ext.", "com.android.cts.")
    private val protectedWords = listOf("thermal", "biometric", "fingerprint", "telephony", "keystore", "overlay", "bootstrap", "setupwizard")

    fun classify(id: String, system: Boolean, uid: String?): Triple<Cat, Risk, String> {
        if (id in protectedIds || protectedPrefixes.any { id.startsWith(it) } || protectedWords.any { id.contains(it) } ||
            (uid != null && uid.startsWith("android.uid.") && uid != "android.uid.shared"))
            return Triple(Cat.CRIT, Risk.PROTECTED, "Essential system component (or shares a privileged system UID). Lunar Optimizer never offers to modify it.")
        val cat = when {
            !system -> Cat.USER
            id.startsWith("com.xiaomi.") || id.startsWith("com.miui.") || id.startsWith("com.mi.") -> Cat.XIAOMI
            id.startsWith("com.google.") -> Cat.GOOGLE
            id.startsWith("com.android.") || id.startsWith("android.") -> Cat.SYSTEM
            else -> Cat.THIRD
        }
        catalog[id]?.let { return Triple(cat, it.first, it.second) }
        return if (!system) Triple(Cat.USER, Risk.LOW, "Installed by you or another app. You control it; removal is reversible by reinstalling.")
        else Triple(cat, Risk.UNKNOWN, "Not in the curated catalog – not enough information to classify safely. Shown for reference only.")
    }

    @Suppress("DEPRECATION")
    fun load(c: Context): List<Pkg> {
        val pm = c.packageManager
        return pm.getInstalledPackages(0x00002000).mapNotNull { pi ->
            val ai = pi.applicationInfo ?: return@mapNotNull null
            val sys = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0
            val upd = ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP != 0
            val (cat, risk, why) = classify(pi.packageName, sys, pi.sharedUserId)
            Pkg(ai.loadLabel(pm).toString(), pi.packageName, sys, upd, ai.enabled, cat, risk, why, ai.flags and 0x00800000 != 0)
        }.sortedBy { it.label.lowercase() }
    }

    @Suppress("DEPRECATION")
    fun isInstalled(c: Context, id: String) = try { c.packageManager.getPackageInfo(id, 0); true } catch (e: PackageManager.NameNotFoundException) { false }

    fun verifyPending(c: Context) {
        for (j in Store.takePending()) {
            val id = j.getString("p"); val gone = !isInstalled(c, id)
            Store.log("uninstall", j.getString("l") + " ($id)", if (gone) "Verified: package no longer installed for this user" else "Verified: still installed (flow cancelled, or only an update was removed)")
        }
    }
}

class DebloatPage(a: MainActivity) : Page(a) {
    private var all: List<Pkg> = emptyList(); private var q = ""; private var cat: Cat? = null
    private lateinit var list: ListView; private lateinit var count: TextView; private lateinit var chips: LinearLayout
    private var shown: List<Pkg> = emptyList()
    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val k = shown[i]
            return act.row {
                setPadding(act.dp(2), act.dp(10), act.dp(2), act.dp(10))
                add(act.col { add(act.tv(k.label, 14f, cText, "sans-serif-medium").apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }); add(act.tv(k.id, 11f, cDim).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, 1) }, w = 0, weight = 1f)
                add(act.col { add(act.tv(k.risk.label, 11f, k.risk.color, "sans-serif-medium").apply { gravity = Gravity.END }); add(act.tv(k.cat.label + (if (!k.installed) " · removed" else if (!k.enabled) " · disabled" else ""), 10f, cDim).apply { gravity = Gravity.END }, 1) }, w = WRAP, start = 8)
            }
        }
    }

    override fun build(): View = with(act) {
        scaffold("Debloat Mode", "Review packages one at a time · nothing runs automatically", scroll = false) {
            add(toggle("Dry-run mode", "When on, actions only preview what would happen", Store.dryRun) { Store.dryRun = it })
            add(btn("Batch disable (catalog Low/Medium)") { push(BatchDebloatPage(act)) }, 2)
            val s = EditText(context).apply {
                hint = "Search name or package id"; setHintTextColor(cDim); setTextColor(cText); textSize = 14f; setSingleLine(true)
                setPadding(dp(14), dp(10), dp(14), dp(10)); cardBg(14)
                addTextChangedListener(object : TextWatcher { override fun afterTextChanged(e: Editable?) { q = e.toString().trim().lowercase(); refilter() }; override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}; override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {} })
            }
            add(s, 4)
            val hs = HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false }
            chips = row {}; hs.addView(chips); add(hs, 8)
            count = tv("Loading packages…", 12f, cDim); add(count, 8)
            list = ListView(context).apply { divider = null; setSelector(android.R.color.transparent); adapter = this@DebloatPage.adapter; isVerticalScrollBarEnabled = false
                setOnItemClickListener { _, _, i, _ -> act.push(PackageDetailPage(act, shown[i])) } }
            add(list, 6, MATCH, 0, 1f)
            bg { val l = Debloat.load(act); ui { all = l; drawChips(); refilter() } }
        }
    }
    override fun onShow() { if (all.isNotEmpty()) act.bg { val l = Debloat.load(act); act.ui { all = l; drawChips(); refilter() } } }
    private fun drawChips() {
        chips.removeAllViews()
        chips.add(act.chip("All (${all.size})", cat == null) { cat = null; drawChips(); refilter() }, w = WRAP)
        for (c in Cat.values()) chips.add(act.chip("${c.label} (${all.count { it.cat == c }})", cat == c) { cat = c; drawChips(); refilter() }, w = WRAP, start = 8)
    }
    private fun refilter() {
        shown = all.filter { (cat == null || it.cat == cat) && (q.isEmpty() || it.label.lowercase().contains(q) || it.id.lowercase().contains(q)) }
        count.text = "${shown.size} packages · tap one to review. Protected/unknown packages are view-only."
        adapter.notifyDataSetChanged()
    }
}

class PackageDetailPage(a: MainActivity, private val p: Pkg) : Page(a) {
    @Suppress("DEPRECATION")
    override fun build(): View = with(act) {
        val pm = packageManager
        val ver = try { pm.getPackageInfo(p.id, 0).versionName ?: "?" } catch (e: Exception) { "?" }
        scaffold(p.label, p.id) {
            card(4) {
                add(kv("Risk", p.risk.label, p.risk.color)); add(kv("Category", p.cat.label)); add(kv("Version", ver))
                add(kv("Origin", if (!p.system) "User-installed" else if (p.updated) "Preinstalled (updated)" else "Preinstalled"))
                add(kv("State", if (p.enabled) "Enabled" else "Disabled"))
                add(tv(p.purpose, 13f, cText), 8)
            }
            val canUninstall = (!p.system || p.updated) && p.risk != Risk.PROTECTED && p.risk != Risk.UNKNOWN && p.id != packageName
            card {
                add(tv("What this build can do (basic mode)", 14f, cText, "sans-serif-medium"))
                add(tv("• Open the app's system page (disable/force-stop only if the system offers it there)\n• Open its notification settings\n" +
                    (if (canUninstall) "• Start the system uninstall confirmation (you confirm in Android's own dialog)\n" else "• Uninstall: not offered for this package here\n"), 12f, cDim), 6)
                if (p.system && !p.updated) add(tv("Disabling or removing a preinstalled package for the current user needs Shizuku-level authorization. This build ships basic mode only, so it will not attempt it.", 12f, cWarn), 6)
                if (canUninstall) add(tv("Reversible: " + (if (!p.system) "yes – reinstall from its store/APK. App data is removed." else "partly – removes the update and returns to the factory version; the factory version stays."), 12f, cDim), 6)
                add(tv("Result of any action is verified when you return to this app and written to Change history.", 12f, cDim), 6)
            }
            if (Sh.granted()) card {
                add(tv("Shizuku actions (shell level)", 14f, cText, "sans-serif-medium"))
                if (p.risk == Risk.PROTECTED) add(tv("Blocked: essential system component. Modifying it can bootloop a locked-bootloader phone.", 12f, cBad), 6)
                else {
                    val hi = p.risk == Risk.HIGH || p.risk == Risk.UNKNOWN
                    if (p.installed && p.enabled) add(btn("Disable for user 0") { shz("Disable", "pm disable-user --user 0 ${p.id}", hi) }, 8)
                    if (p.installed && !p.enabled) add(btn("Enable") { shz("Enable", "pm enable --user 0 ${p.id}", false) }, 8)
                    if (p.installed) add(btn("Remove for user 0 (keep data)") { shz("Remove", "pm uninstall -k --user 0 ${p.id}", hi) }, 8)
                    if (!p.installed) add(btn("Restore (install-existing)", true) { shz("Restore", "cmd package install-existing --user 0 ${p.id}", false) }, 8)
                    if (hi) add(tv("Higher risk: if anything misbehaves, return here and Enable/Restore.", 11f, cWarn), 6)
                }
            }
            add(btn("Open App info", true) { open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${p.id}"))) }, 12)
            add(btn("Notification settings") {
                if (!open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, p.id))) toast("Unavailable")
            }, 8)
            if (canUninstall) add(btn(if (Store.dryRun) "Preview uninstall (dry-run)" else "Uninstall…") { askUninstall() }, 8)
            add(tv("Restore instructions: " + (if (!p.system) "reinstall from Google Play / GetApps / the original APK." else "factory-version apps are restored automatically; if an update was removed, reinstall the update from the store."), 11f, cDim), 14)
        }
    }
    private fun shz(op: String, cmd: String, hi: Boolean) {
        val plan = "Package: ${p.id}\nCommand: $cmd\nRisk: ${p.risk.label}\nReversible: yes (Enable / Restore from this screen)."
        val go = {
            act.bg {
                val r = Sh.exec(cmd)
                val ok = when (op) { "Disable" -> try { act.packageManager.getApplicationEnabledSetting(p.id) >= 2 } catch (e: Exception) { false }; "Enable" -> try { act.packageManager.getApplicationEnabledSetting(p.id) < 2 } catch (e: Exception) { false }; "Remove" -> !Debloat.isInstalled(act, p.id); else -> Debloat.isInstalled(act, p.id) }
                if (op == "Disable" && !ok && r.text().contains("Security", true)) { act.ui { act.dialog("Blocked by HyperOS", "HyperOS refuses 'disable' for this package. Remove it for user 0 instead? It stays restorable.\n\npm uninstall -k --user 0 ${p.id}", "Remove", "Cancel") { shz("Remove", "pm uninstall -k --user 0 ${p.id}", hi) } }; return@bg }
                if (ok) Store.addL("pkgops", 1)
                Store.log(op.lowercase(), "${p.label} (${p.id})", (if (ok) "Verified: " else "NOT verified: ") + r.text().take(100))
                act.ui { act.dialog("$op ${if (ok) "verified" else "not verified"}", r.text().ifEmpty { "exit ${r.code}" }) { val np = Debloat.load(act).firstOrNull { it.id == p.id } ?: p; act.pop(); act.push(PackageDetailPage(act, np)) } }
            }
        }
        if (Store.dryRun) { Store.log("dry-run", "${p.label} (${p.id})", "Previewed: $cmd"); act.dialog("Dry-run: nothing executed", plan); return }
        act.dialog("Confirm $op", plan + if (hi) "\n\nHigher-risk package: make sure you know what it does." else "", "Run", "Cancel") { go() }
    }
    private fun askUninstall() {
        val side = "Side effects: data for this app is removed; features that rely on it stop working. Reversible: ${if (!p.system) "reinstall" else "update reinstallable; factory version stays"}."
        val plan = "Package: ${p.id}\nOperation: system uninstall confirmation (ACTION_DELETE)\nAuthorization: your confirmation in Android's dialog – no special permission\n$side"
        if (Store.dryRun) { Store.log("dry-run", "${p.label} (${p.id})", "Previewed uninstall – nothing executed"); act.dialog("Dry-run – nothing will be executed", plan); return }
        act.dialog("Confirm: ${p.label}", plan, "Continue", "Cancel") {
            Store.addPending(p.id, "uninstall", p.label)
            if (!act.open(Intent(Intent.ACTION_DELETE, Uri.parse("package:${p.id}")))) { Store.takePending(); act.toast("Uninstall flow unavailable") }
        }
    }
}

class HistoryPage(a: MainActivity) : Page(a) {
    override fun build(): View = with(act) {
        val f = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        scaffold("Change history", "Local only · stored on this device") {
            val ch = Store.changes()
            if (ch.isEmpty()) add(tv("Nothing recorded yet.", 13f, cDim), 8)
            for (j in ch) card(8, 14) {
                add(row { add(tv(j.getString("n"), 13f, cText, "sans-serif-medium"), w = 0, weight = 1f); add(tv(f.format(Date(j.getLong("t"))), 11f, cDim), w = WRAP, start = 8) })
                add(tv(j.getString("k").uppercase() + " · " + j.getString("d"), 12f, cDim), 4)
            }
            if (ch.isNotEmpty()) add(btn("Clear history") { Store.clearChanges(); pop(); push(HistoryPage(this@with)) }, 14)
        }
    }
}

class BatchDebloatPage(a: MainActivity) : Page(a) {
    private val sel = HashSet<String>(); private var items: List<Pkg> = emptyList(); private lateinit var host: LinearLayout
    override fun build(): View = with(act) {
        scaffold("Batch disable", "Catalog packages rated Low/Medium · you tick each one") {
            if (!Sh.granted()) add(tv("Needs Shizuku authorization (Settings tab).", 13f, cWarn), 8)
            host = col {}; add(host, 4)
            add(btn("Disable selected", true) { run() }, 14)
            bg { val l = Debloat.load(act).filter { it.system && it.installed && it.enabled && (it.risk == Risk.LOW || it.risk == Risk.MEDIUM) }; ui { items = l; fill() } }
        }
    }
    private fun fill() = with(act) {
        host.removeAllViews(); if (items.isEmpty()) host.add(tv("No matching packages are present on this device.", 13f, cDim))
        for (p in items) host.card(8, 12) { add(toggle("${p.label} · ${p.risk.label}", p.purpose, false) { if (it) sel.add(p.id) else sel.remove(p.id) }) }
    }
    private fun run() {
        if (!Sh.granted()) { act.toast("Connect Shizuku first"); return }
        if (sel.isEmpty()) { act.toast("Nothing selected"); return }
        val ids = sel.toList()
        val plan = ids.joinToString("\n") { "pm disable-user --user 0 $it" } + "\n\nIf HyperOS blocks disable: pm uninstall -k --user 0 <package> (restorable).\nReversible from each package's screen."
        if (Store.dryRun) { Store.log("dry-run", "Batch disable", ids.joinToString()); act.dialog("Dry-run: nothing executed", plan); return }
        act.dialog("Confirm batch disable (${ids.size})", plan, "Run", "Cancel") {
            act.bg {
                val res = ids.map { id ->
                    val r = Sh.exec("pm disable-user --user 0 $id"); var ok = try { act.packageManager.getApplicationEnabledSetting(id) >= 2 } catch (e: Exception) { false }; var how = "disabled"
                    if (!ok && r.text().contains("Security", true)) { Sh.exec("pm uninstall -k --user 0 $id"); ok = !Debloat.isInstalled(act, id); how = "removed for user 0 (disable blocked)" }
                    if (ok) Store.addL("pkgops", 1); Store.log("disable", id, if (ok) "Verified $how" else "NOT verified"); "$id: ${if (ok) "$how, verified" else "FAILED"}"
                }
                act.ui { sel.clear(); act.dialog("Batch result", res.joinToString("\n")) { act.pop() } }
            }
        }
    }
}
