package com.lunaroptimizer.app

import java.util.concurrent.CopyOnWriteArrayList

/** Journal storage on top of the app's SharedPreferences (the journal itself is pure Kotlin, see Safety.kt). */
object StoreKV : KV {
    override fun get(k: String) = Store.rawGet(k)
    override fun put(k: String, v: String) = Store.rawPut(k, v)
    override fun remove(k: String) = Store.rawRemove(k)
    override fun keys(prefix: String) = Store.rawKeys(prefix)
}

object Mut {
    val m: Mutator by lazy { Mutator(Sh, StoreKV) }
    @Volatile private var migrated = false
    @Volatile private var booted = false

    /** Once: imports restore records written by earlier versions (o|..., ob|..., and packages Lunar itself disabled). */
    fun migrate() {
        if (migrated) return; migrated = true
        if (Store.getS("j_migrated") == "1") return
        var n = 0
        for (k in Store.rawKeys("o|") + Store.rawKeys("ob|")) { Store.rawGet(k)?.let { if (m.importLegacy(k, it)) n++ }; Store.rawRemove(k) }
        (Store.getS("dis_pkgs") ?: "").split(",").filter { it in Pipeline.DEBLOAT || it == Pipeline.VAULT }.forEach { if (m.importLegacy("lpkg|$it", "enabled")) n++ }
        Store.putS("dis_pkgs", ""); Store.putS("j_migrated", "1")
        if (n > 0) Store.log("safety", "Journal", "Imported $n restore records from an earlier version")
    }
    /** After a restart: settle interrupted operations, and tell the user about records that could not be restored. */
    fun boot(a: MainActivity) {
        if (booted || !Sh.granted()) return; booted = true
        a.bg {
            val l = m.recover(); if (l.isNotEmpty()) Store.log("safety", "Recovery after restart", l.joinToString("; "))
            val f = m.failed()
            if (f.isNotEmpty()) Prompts.set(Prompts.P("restorefail", "${f.size} change(s) could not be restored", f.take(3).joinToString("\n") { (targetOf(it.key)?.label ?: it.key) + ": " + it.note }, "Retry", { a.bg { val r = m.retryFailed(); Store.log("safety", "Retry restore", r.joinToString("; ")); a.ui { a.dialog("Retry restore", r.joinToString("\n").ifEmpty { "Nothing to retry" }) } } }))
        }
    }
}

/** Things Lunar will not do silently: shown as cards on Home. */
object Prompts {
    class P(val id: String, val title: String, val body: String, val action: String?, val run: (() -> Unit)?)
    private val list = CopyOnWriteArrayList<P>()
    fun set(p: P) { list.removeAll { it.id == p.id }; list.add(p) }
    fun clear(id: String) { list.removeAll { it.id == id } }
    fun all(): List<P> = list.toList()
}
