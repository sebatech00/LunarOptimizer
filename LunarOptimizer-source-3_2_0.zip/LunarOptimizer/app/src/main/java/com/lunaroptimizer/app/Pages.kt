package com.lunaroptimizer.app

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

fun unlockPerms(a: MainActivity, then: () -> Unit = {}) {
    if (!Sh.granted()) { a.toast("Connect Shizuku first"); return }
    a.bg {
        Sh.exec("pm grant ${a.packageName} android.permission.WRITE_SECURE_SETTINGS"); Sh.exec("cmd appops set ${a.packageName} GET_USAGE_STATS allow")
        val ws = Sys.canWriteSecure(a); val us = Sys.usageAccess(a)
        Store.log("permissions", "Advanced permissions", "WRITE_SECURE_SETTINGS=$ws, usage access=$us")
        a.ui { a.dialog("Advanced permissions", "WRITE_SECURE_SETTINGS: ${if (ws) "granted" else "failed"}\nUsage access: ${if (us) "granted" else "failed"}"); then() }
    }
}

fun fillLink(a: MainActivity, c: LinearLayout) = with(a) {
    c.removeAllViews()
    val st = Sh.state(a)
    val (txt, color) = when (st) { 3 -> "Shizuku connected" to cGood; 2 -> "Shizuku needs permission" to cWarn; 1 -> "Shizuku not detected" to cWarn; else -> "Shizuku not installed" to cBad }
    c.add(row {
        add(tv("●", 14f, color), w = WRAP); add(tv(txt, 14f, cText, "sans-serif-medium"), w = 0, weight = 1f, start = 10)
        when (st) {
            3 -> if (!Sys.canWriteSecure(a)) add(btn("Unlock") { unlockPerms(a) }.compact(), w = WRAP) else add(tv(Sh.who(), 12f, cDim), w = WRAP)
            2 -> add(btn("Allow", true) { Sh.request() }.compact(), w = WRAP)
            1 -> add(btn("Open", true) { val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api"); if (i != null) startActivity(i) }.compact(), w = WRAP)
            else -> add(btn("Get", true) { open(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases"))) }.compact(), w = WRAP)
        }
    })
    if (st == 1) { c.add(tv("Swipe this app from recents and reopen.", 11f, cDim), 6); c.add(tv(Sh.diag(), 10f, cDim), 4) }
}

private fun tile(a: MainActivity, title: String, onClick: () -> Unit): LinearLayout = a.col {
    setPadding(dp(16), dp(18), dp(16), dp(18)); cardBg(20)
    add(a.tv(title, 14f, cText, "sans-serif-medium"))
    setOnClickListener { Haptics.tick(it); onClick() }
}

class HomePage(a: MainActivity) : Page(a) {
    private lateinit var heroSub: TextView; private lateinit var link: LinearLayout; private lateinit var cpuTv: TextView; private lateinit var cpuNote: TextView
    private lateinit var cpuChart: LineChartView; private lateinit var cores: CoresView; private lateinit var chips: LinearLayout; private lateinit var gpuTv: TextView
    private lateinit var rb: RingView; private lateinit var rm: RingView; private lateinit var rs: RingView; private lateinit var dyn: LinearLayout
    private val hist = ArrayList<Float>(); private var busy = false; private var linkKey = -1; private var sugg: String? = null
    private val tick = object : Runnable { override fun run() { try { refresh() } catch (e: Throwable) { Store.err("home tick: " + e.stackTraceToString().take(500)) }; act.handler.postDelayed(this, 1000) } }

    override fun build(): View = with(act) {
        val sv = ScrollView(act).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val c = col(16) {
            setPadding(dp(16), dp(28), dp(16), dp(24))
            add(col {
                gravity = Gravity.CENTER_HORIZONTAL
                val logo = ImageView(act).apply { setImageResource(resources.getIdentifier("lunar_logo", "drawable", packageName)); scaleType = ImageView.ScaleType.FIT_CENTER }
                add(logo, 0, dp(96), dp(96))
                add(tv("LUNAR OPTIMIZER", 26f, cText, "sans-serif-semibold").apply { letterSpacing = 0.14f; gravity = Gravity.CENTER }, 16)
                heroSub = tv("", 13f, cDim).apply { gravity = Gravity.CENTER }; add(heroSub, 6)
            })
            add(btn("OPTIMIZE NOW", true) { push(OptimizePage(act)) }.apply { textSize = 19f; letterSpacing = 0.12f; setPadding(dp(16), dp(24), dp(16), dp(24)) }, 24)
            add(btn("DEEP CLEAN RAM") { push(DeepCleanPage(act)) }.apply { textSize = 14f; letterSpacing = 0.1f; setPadding(dp(16), dp(15), dp(16), dp(15)) }, 10)
            card(16, 16) { link = this }
            card(12, 16) {
                add(row { add(tv("CPU", 13f, cSilver, "sans-serif-medium"), w = 0, weight = 1f); chips = row {}; add(chips, w = WRAP) })
                cpuTv = tv("—", 38f, cText, "sans-serif-light"); add(cpuTv, 2)
                cpuNote = tv("", 11f, cDim); add(cpuNote)
                cpuChart = LineChartView(act).apply { fixedMin = 0f; fixedMax = 100f; unit = "%" }; add(cpuChart, 6, MATCH, dp(80))
                cores = CoresView(act); add(cores, 12, MATCH, dp(60))
                gpuTv = tv("", 12f, cSilver); add(gpuTv, 8)
            }
            card(12, 12) {
                add(row {
                    rb = RingView(act); rm = RingView(act); rs = RingView(act)
                    for (r in listOf(rb, rm, rs)) add(r, 0, 0, dp(116), 1f)
                })
            }
            dyn = col {}; add(dyn)
            add(row { add(tile(act, "Tweaks") { switchTab(1) }, w = 0, weight = 1f); add(tile(act, "Debloat") { switchTab(2) }, w = 0, weight = 1f, start = 12) }, 12)
            add(row { add(tile(act, "Battery") { switchTab(3) }, w = 0, weight = 1f); add(tile(act, "Camera") { push(CameraPage(act)) }, w = 0, weight = 1f, start = 12) }, 12)
        }
        sv.addView(c); sv
    }
    override fun onShow() { linkKey = -1; act.handler.removeCallbacks(tick); act.handler.post(tick); Mut.boot(act); Bench.ensure(act); Pack.ensure(act); Pack.fixAnim(act); act.bg { val s = Pipeline.suggest(act); act.ui { sugg = s } } }
    override fun onHide() { act.handler.removeCallbacks(tick) }

    private fun refresh() = with(act) {
        val b = Sys.battery(act); val m = Sys.memory(act); val (tot, free) = Sys.storage(act)
        Store.sample(b.pct, b.tempC, b.charging)
        rb.set(b.pct / 100f, "${b.pct}%", Sys.statusText(b.status), if (b.pct <= 15 && !b.charging) cBad else if (b.charging) cGood else cIce)
        rm.set(m.avail.toFloat() / m.total, String.format(Locale.US, "%.1f", m.avail / 1073741824.0), "RAM free (GB)", cViolet)
        rs.set(free.toFloat() / tot, String.format(Locale.US, "%.0f", free / 1e9), "Storage free (GB)", cIce)
        val k = Sh.state(act); if (k != linkKey) { linkKey = k; fillLink(act, link) }
        heroSub.text = "${Build.MODEL} · Android ${Build.VERSION.RELEASE}"
        dyn.removeAllViews()
        if (Store.getS("pending_verify") == "1") dyn.card(12, 14, true) { add(row { add(tv("Verification pending", 14f, cText, "sans-serif-medium"), w = 0, weight = 1f); add(btn("Finish", true) { push(OptimizePage(act, 1)) }.compact(), w = WRAP) }) }
        for (pr in Prompts.all()) dyn.card(12, 14, true) { add(tv(pr.title, 14f, cText, "sans-serif-medium")); add(tv(pr.body, 11f, cDim), 2); add(row { if (pr.run != null) add(btn(pr.action ?: "Fix", true) { Prompts.clear(pr.id); pr.run.invoke() }.compact(), w = WRAP); add(btn("Dismiss") { Prompts.clear(pr.id) }.compact(), w = WRAP, start = if (pr.run != null) 8 else 0) }, 8) }
        sugg?.let { s -> dyn.card(12, 14) { add(tv("Compile suggested", 14f, cText, "sans-serif-medium")); add(tv(s, 11f, cDim), 2); add(btn("Run compile") { push(OptimizePage(act, 2)) }.compact(), 8, WRAP) } }
        dyn.card(12, 14) {
            add(kv("Display", Sys.refreshInfo(act))); add(kv("Thermal", Sys.thermalText(b.thermal)))
            Sys.swap()?.let { if (it.first > 0) add(kv("Swap used", "${Sys.fmt(it.first - it.second, 1024)} of ${Sys.fmt(it.first, 1024)}")) }
        }
        if (k == 3) { cpuNote.text = ""; if (!busy) { busy = true; bg { var s: Tele.Snap? = null; try { s = Tele.read() } catch (e: Throwable) { Store.err("tele: ${e.message}") }; ui { busy = false; s?.let { applyTele(it, b) } } } } }
        else { cpuTv.text = "—"; cpuNote.text = "Connect Shizuku for live data"; gpuTv.text = ""; chips.removeAllViews() }
    }
    private fun applyTele(s: Tele.Snap, b: Sys.Batt) = with(act) {
        s.cpu?.let { cpuTv.text = String.format(Locale.US, "%.0f%%", it); hist.add(it); if (hist.size > 60) hist.removeAt(0); cpuChart.data = ArrayList(hist); cpuChart.invalidate() }
        cores.f = s.freqs; cores.m = s.maxs; cores.invalidate()
        chips.removeAllViews()
        for ((l, v) in listOf("CPU" to s.temps["CPU"], "GPU" to s.temps["GPU"], "Skin" to s.temps["Skin"], "Batt" to (if (b.tempC.isNaN()) null else b.tempC))) if (v != null) chips.add(chip("$l ${String.format(Locale.US, "%.0f", v)}°", false) {}.apply { textSize = 11f; setPadding(dp(10), dp(5), dp(10), dp(5)) }, w = WRAP, start = 6)
        gpuTv.text = if (s.gpuMhz != null) "GPU ${s.gpuMhz} MHz" + (s.gpuBusy?.let { " · $it%" } ?: "") else ""
    }
}

class ConsolePage(a: MainActivity) : Page(a) {
    private lateinit var t: TextView; private lateinit var sv: ScrollView
    override fun build(): View = with(act) {
        scaffold("Activity console", "Every command run through Shizuku", scroll = false) {
            sv = ScrollView(act); t = tv(Con.all().joinToString("\n"), 11f, cSilver).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }; sv.addView(t); add(sv, 0, MATCH, 0, 1f)
            add(row { add(btn("Copy") { copyText("log", Con.all().joinToString("\n")) }, w = 0, weight = 1f); add(btn("Clear") { Con.clear(); t.text = "" }, w = 0, weight = 1f, start = 8) }, 8)
        }
    }
    override fun onShow() { Con.sink = { l -> act.ui { t.append(l + "\n"); sv.post { sv.fullScroll(View.FOCUS_DOWN) } } } }
    override fun onHide() { Con.sink = null }
    override fun onDestroy() { Con.sink = null }
}

class BatteryPage(a: MainActivity) : Page(a) {
    private lateinit var ring: RingView; private lateinit var dyn: LinearLayout; private lateinit var hist: LinearLayout; private lateinit var sys: LinearLayout
    private lateinit var c1: LineChartView; private lateinit var c2: LineChartView
    private var busy = false
    private val tick = object : Runnable { override fun run() { try { refresh() } catch (e: Throwable) { Store.err("battery tick: " + e.stackTraceToString().take(500)) }; act.handler.postDelayed(this, 2000) } }
    override fun build(): View = with(act) {
        scaffold("Battery") {
            card(4, 10, true) { ring = RingView(act); add(ring, 0, MATCH, dp(190)) }
            sys = col {}; add(sys)
            dyn = col {}; add(dyn)
            add(section("History (recorded while the app is open)"))
            card(0, 14) {
                add(tv("Charge level %", 12f, cDim)); c1 = LineChartView(act).apply { fixedMin = 0f; fixedMax = 100f; unit = "%" }; add(c1, 4, MATCH, dp(100))
                add(tv("Battery temperature °C", 12f, cDim), 12); c2 = LineChartView(act).apply { color = cViolet; unit = "°" }; add(c2, 4, MATCH, dp(100))
                hist = col {}; add(hist, 10)
                add(btn("Clear history") { Store.clearSamples(); refresh() }, 10)
            }
            add(section("Settings shortcuts"))
            card(0, 14) {
                add(btn("Battery saver settings") { act.openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS, "Battery saver") })
                add(btn("Per-app battery management") { act.openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, "Battery optimization") }, 8)
                add(btn("Battery usage") { act.openSettings("android.intent.action.POWER_USAGE_SUMMARY", "Battery usage") }, 8)
            }
        }
    }
    override fun onShow() { act.handler.removeCallbacks(tick); act.handler.post(tick) }
    override fun onHide() { act.handler.removeCallbacks(tick) }

    private fun readSys() {
        if (!Sh.granted() || busy) return
        busy = true
        act.bg {
            var r: Sh.R? = null
            try { r = Sh.exec("for f in current_now voltage_now charge_full charge_full_design cycle_count time_to_full_now charge_counter; do v=\$(cat /sys/class/power_supply/battery/\$f 2>/dev/null); [ -n \"\$v\" ] && echo \"\$f=\$v\"; done; dumpsys battery | grep -E 'Max charging|Charge counter'", false) } finally {
                act.ui { busy = false; r?.let { showSys(it.out) } }
            }
        }
    }
    private fun showSys(o: String) = with(act) {
        val m = HashMap<String, String>(); val raw = ArrayList<String>()
        o.lines().forEach { l -> if (l.contains("=")) m[l.substringBefore('=')] = l.substringAfter('=').trim() else if (l.isNotBlank()) raw.add(l.trim()) }
        sys.removeAllViews()
        sys.card(12, 14) {
            add(tv("Kernel readings (sysfs)", 14f, cText, "sans-serif-medium"))
            val cur = m["current_now"]?.toLongOrNull(); val v = m["voltage_now"]?.toLongOrNull()
            if (cur != null && v != null && v > 0) add(kv("Power right now", String.format(Locale.US, "%.1f W", abs(cur) * v / 1e12) + " (" + (if (cur > 0) "in" else "out") + ", instantaneous)"))
            val full = m["charge_full"]?.toLongOrNull(); val des = m["charge_full_design"]?.toLongOrNull()
            if (full != null && des != null && des > 0) add(kv("Capacity vs design", String.format(Locale.US, "%.1f%%", 100.0 * full / des) + "  (${full / 1000} / ${des / 1000} mAh)"))
            m["cycle_count"]?.let { add(kv("Cycle count", it)) }
            m["time_to_full_now"]?.let { add(kv("Time to full (kernel)", "$it s")) }
            for (l in raw) add(tv(l, 11f, cDim), 4)
            if (m.isEmpty() && raw.isEmpty()) add(tv("This kernel exposes none of the usual battery nodes to the shell.", 12f, cDim), 6)
        }
    }
    private fun refresh() = with(act) {
        val b = Sys.battery(act); Store.sample(b.pct, b.tempC, b.charging)
        ring.set(b.pct / 100f, "${b.pct}%", Sys.statusText(b.status), if (b.pct <= 15 && !b.charging) cBad else if (b.charging) cGood else cIce)
        readSys()
        dyn.removeAllViews()
        dyn.card(12, 14) {
            add(kv("State", Sys.statusText(b.status))); add(kv("Power source", Sys.pluggedText(b.plugged)))
            add(kv("Temperature", if (b.tempC.isNaN()) "n/a" else "${b.tempC} °C")); add(kv("Voltage", "${b.mv} mV"))
            add(kv("Battery saver", if (b.saver) "On" else "Off")); add(kv("Thermal status", Sys.thermalText(b.thermal)))
            add(kv("Reported health", Sys.healthText(b.health) + (b.soh?.let { " · $it%" } ?: ""))); add(kv("Cycle count (Android)", b.cycles?.toString() ?: "Not exposed"))
        }
        val s = Store.samples().takeLast(80)
        c1.data = s.map { it.getInt(1).toFloat() }; c1.invalidate(); c2.data = s.map { it.getDouble(2).toFloat() }.filter { it > -90f }; c2.invalidate()
        hist.removeAllViews(); val f = SimpleDateFormat("MMM d HH:mm", Locale.getDefault())
        val sess = ArrayList<List<org.json.JSONArray>>(); var cur = ArrayList<org.json.JSONArray>()
        for (x in Store.samples()) { if (x.getBoolean(3)) cur.add(x) else { if (cur.size > 1) sess.add(cur); cur = ArrayList() } }; if (cur.size > 1) sess.add(cur)
        hist.addView(tv(if (sess.isEmpty()) "No complete charging session observed yet." else "Observed charging sessions", 12f, cDim))
        for (x in sess.takeLast(4).reversed()) hist.addView(kv(f.format(Date(x.first().getLong(0))), "${x.first().getInt(1)}% → ${x.last().getInt(1)}% · ${(x.last().getLong(0) - x.first().getLong(0)) / 60000} min"))
    }
}

class SettingsPage(a: MainActivity) : Page(a) {
    private lateinit var link: LinearLayout
    override fun build(): View = with(act) {
        scaffold("Settings") {
            add(section("Shizuku"))
            card(0, 14, true) { link = this }
            card(10, 14) {
                add(kv("Shizuku app installed", if (Sh.installed(act)) "Yes" else "No")); add(kv("Server running", if (Sh.running()) "Yes" else "No")); add(kv("Authorized", if (Sh.granted()) "Yes (${Sh.who()})" else "No"))
                add(kv("WRITE_SECURE_SETTINGS", if (Sys.canWriteSecure(act)) "Granted" else "Not granted")); add(kv("Usage access", if (Sys.usageAccess(act)) "Granted" else "Not granted"))
                add(btn("Unlock advanced permissions") { unlockPerms(act) { switchTab(4) } }, 8)
                add(btn("What it does") { push(InfoPage(act)) }, 8)
                add(btn("Open activity console") { push(ConsolePage(act)) }, 8)
                add(tv("Diag: ${Sh.diag()}", 10f, cDim), 8)
            }
            fillLink(act, link)
            add(section("App"))
            card(0) {
                add(toggle("Haptic feedback", "Subtle tick on taps", Store.haptics) { Store.haptics = it })
                add(toggle("Animations", "Background drift and gauge transitions", Store.anims) { Store.anims = it })
                add(toggle("Include higher-impact items", "Optimize Now also restricts heavy background apps, uses ad-blocking DNS and Faster Doze. All reversible with Roll back", Store.aggressive) { Store.aggressive = it })
            }
            add(section("Data"))
            card(0) {
                add(btn("Change history") { push(HistoryPage(act)) })
                add(btn("Restore disabled apps") { bg { val l = Pipeline.restoreAll(act); ui { dialog("Restore all", l.joinToString("\n").ifEmpty { "Nothing was disabled" }) } } }, 8)
                add(btn("Manual checklist") { push(ChecklistPage(act)) }, 8)
                add(btn("View error log") { val e = Store.errors(); dialog("Error log", if (e.isEmpty()) "No errors recorded." else e.take(15).joinToString("\n\n") { SimpleDateFormat("MMM d HH:mm", Locale.getDefault()).format(Date(it.getLong("t"))) + "\n" + it.getString("m") }) }, 8)
                add(btn("Clear error log") { Store.clearErrors(); toast("Cleared") }, 8)
                add(btn("Reset app preferences") { dialog("Reset preferences?", "Clears settings, history, battery samples and the recorded original values used to revert tweaks. Active tweaks stay applied but can no longer be reverted automatically.", "Reset", "Cancel") { Store.resetAll(); toast("Reset") } }, 8)
            }
            add(section("Privacy"))
            card(0) { add(tv("No analytics, ads, accounts or uploads. Preferences and logs stay in private app storage.", 12f, cDim)) }
            add(section("About"))
            card(0) { add(kv("Version", "3.0.2 (build 13)")); add(kv("Package", "com.lunaroptimizer.app")); add(kv("Detected", "${Build.MODEL} (${Build.DEVICE}) · ${Sys.hyperOs()}")) }
        }
    }
    override fun onShow() { if (::link.isInitialized) fillLink(act, link) }
}
