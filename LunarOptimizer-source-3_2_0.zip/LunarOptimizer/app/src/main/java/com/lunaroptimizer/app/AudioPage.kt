package com.lunaroptimizer.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.*
import android.widget.*

/** Section K: read-only audio-path report. It changes nothing. Anything that cannot be read says so instead of guessing. */
class AudioPage(a: MainActivity) : Page(a) {
    private lateinit var host: LinearLayout
    private var started = false; private var raw = ""
    override fun build(): View = with(act) { scaffold("Audio", "Read-only report from the system") { host = col {}; add(host) } }
    override fun onShow() { if (!started) { started = true; load() } }
    private fun load() {
        if (!Sh.granted()) { with(act) { host.removeAllViews(); host.card(4, 16) { add(tv("Shizuku isn't authorized. The audio dump needs shell access.", 14f, cWarn)); add(btn("Open Settings", true) { switchTab(4) }, 12) } }; return }
        with(act) { host.removeAllViews(); host.card(4, 16) { add(tv("Reading audio state…", 14f, cText)) } }
        act.bg {
            val af = Sh.exec("dumpsys media.audio_flinger", false, 40000); val bt = Sh.exec("dumpsys bluetooth_manager", false, 40000)
            raw = "== audio_flinger (first 3500 chars)\n" + af.out.take(3500) + "\n\n== bluetooth_manager (first 3500 chars)\n" + bt.out.take(3500)
            val th = Parse.audioFlinger(af.out); val codec = Parse.btCodec(bt.out)
            act.ui { show(th, af.ok, codec, bt.ok) }
        }
    }
    private fun hz(r: Int?) = if (r == null) "n/a" else "%.1f kHz".format(r / 1000f)
    private fun show(th: List<AudioThread>, afOk: Boolean, codec: BtCodec?, btOk: Boolean) = with(act) {
        host.removeAllViews()
        val active = th.filter { it.standby == false }
        host.card(4, 14, true) {
            add(tv("Output path", 16f, cText, "sans-serif-semibold"))
            if (th.isEmpty()) add(tv(if (afOk) "Unavailable: the audio dump was not in a recognised format." else "Unavailable: the audio dump could not be read.", 13f, cWarn), 6)
            else if (active.isEmpty()) { add(tv("No active playback right now. Start playing, then refresh.", 13f, cDim), 6); for (t in th.filter { it.devices.isNotEmpty() }.take(4)) add(kv("${t.type} (idle)", t.devices.joinToString(", ")), 4) }
            else for (t in active) { add(kv("Route", t.devices.joinToString(", ").ifEmpty { "n/a" }), 6); add(kv("Thread", t.type)); add(kv("Mixer rate", hz(t.rateHz))); add(kv("Mixer format", t.format ?: "n/a"))
                add(kv("Effects in chain", if (t.effectCount == 0) "none reported" else "${t.effectCount} (names not parsed)", if (t.effectCount > 0) cWarn else cText)) }
            if (active.any { it.type == "MIXER" }) add(tv("Playing through the system mixer: audio is resampled to the mixer rate above unless it already matches. Apps using USB exclusive mode bypass the mixer and are not visible in this report.", 11f, cDim), 8)
        }
        host.card(10, 14) {
            add(tv("Bluetooth codec", 14f, cText, "sans-serif-medium"))
            if (codec != null) { add(kv("Codec", codec.codec)); add(kv("Sample rate", hz(codec.rateHz))); add(kv("Bits per sample", codec.bits?.toString() ?: "n/a")) }
            else add(tv(if (btOk) "Unavailable: no connected A2DP device, or the dump was not recognised." else "Unavailable: the Bluetooth dump could not be read.", 12f, cDim), 4)
        }
        host.card(10, 14) {
            add(tv("Checklist (not measured by Lunar)", 14f, cText, "sans-serif-medium"))
            for (l in listOf("Turn off Dolby, Mi Sound and other system effects for clean output.", "Use a wired USB DAC for the shortest path; check the route above says USB.", "Set the DAC dongle volume with the system volume, not an app EQ stacked on top.", "Keep the player's own EQ and resampler off unless you want them.", "For Bluetooth, pick the codec in Developer options and confirm it above."))
                add(tv("• $l", 11f, cDim), 4)
        }
        host.add(btn("Refresh", true) { load() }, 14)
        host.add(btn("Copy raw dumps (for debugging)") { (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("lunar-audio", raw)); act.toast("Copied ${raw.length} characters") }, 10)
    }
}
