package com.lunaroptimizer.app

import android.app.usage.UsageStatsManager
import android.content.Context
import android.view.*
import android.widget.*

// ===== Section G: automatic mode. Pure classification first (JVM-testable), then evidence collection, apply/undo, and the page.

enum class Act { DISABLE, RESTRICT, REPORT }
class Ev(val pkg: String, val label: String, val system: Boolean, val enabled: Boolean, val launcher: Boolean, val daysSinceUse: Int?, val bucket: Int?,
         val rssMb: Int, val mah: Double?, val cpu: Double?, val wake: Double?, val curated: Boolean, val bloat: Boolean, val prot: String?)
class Rec(val ev: Ev, val tier: Int, val act: Act, val why: String, var sel: Boolean)
class AutoCfg(val unusedDays: Int = 14, val bloatDays: Int = 30, val mahMin: Double = 3.0, val rssMin: Int = 150)

object AutoLogic {
    /** Tier 0: curated telemetry/ad packages. Tier 1: apps unused for N days AND measurably busy in the background (restricted, not disabled).
     *  Tier 2: curated low-risk bloat unused for N days (disabled). Tier 3: report only. Protected apps never appear. No evidence means no action. */
    fun classify(evs: List<Ev>, c: AutoCfg = AutoCfg()): List<Rec> {
        val out = ArrayList<Rec>()
        for (e in evs) {
            if (e.prot != null || !e.enabled) continue
            val busy = (e.mah ?: 0.0) >= c.mahMin || (e.cpu ?: 0.0) >= 1.0 || (e.wake ?: 0.0) >= 0.5 || e.rssMb >= c.rssMin
            val used = e.daysSinceUse
            val meas = listOfNotNull(e.mah?.let { "%.1f mAh since last charge".format(it) }, if (e.rssMb > 0) "${e.rssMb} MB in memory" else null).joinToString(", ")
            when {
                e.curated -> out.add(Rec(e, 0, Act.DISABLE, "telemetry/ads package on Lunar's curated list", true))
                e.bloat && e.launcher && used != null && used >= c.bloatDays -> out.add(Rec(e, 2, Act.DISABLE, "preinstalled, low risk, not opened for ${if (used >= 999) "the whole usage window" else "$used days"}", true))
                !e.system && e.launcher && used != null && used >= c.unusedDays && e.bucket != 45 && busy -> out.add(Rec(e, 1, Act.RESTRICT, "not opened for ${if (used >= 999) "the whole usage window" else "$used days"}; $meas", true))
                (e.mah ?: 0.0) >= c.mahMin * 3 && e.bucket != 45 -> out.add(Rec(e, 3, Act.REPORT, "high background use ($meas) but ${if (e.system) "system component" else "used recently or no usage data"}: not touched", false))
            }
        }
        return out.sortedWith(compareBy({ it.tier }, { -(it.ev.mah ?: 0.0) }, { it.ev.label.lowercase() }))
    }
}

class AutoScan(val recs: List<Rec>, val protectedCount: Int, val total: Int, val notes: List<String>)

object Auto {
    fun keep(): Set<String> = (Store.getS("auto_keep") ?: "").split(",").filter { it.isNotEmpty() }.toSet()
    fun addKeep(p: String) { Store.putS("auto_keep", (keep() + p).joinToString(",")) }
    fun clearKeep() { Store.putS("auto_keep", "") }
    var noReview: Boolean get() = Store.getS("auto_noreview") == "1"; set(v) { Store.putS("auto_noreview", if (v) "1" else "") }

    fun sections(out: String): Map<String, String> {
        val m = HashMap<String, StringBuilder>(); var k = ""
        for (l in out.lines()) { if (l.startsWith("@@")) { k = l.substring(2).trim(); m[k] = StringBuilder() } else m[k]?.append(l)?.append('\n') }
        return m.mapValues { it.value.toString() }
    }
    /** Everything that must never be restricted or disabled, with the reason shown to the user. */
    fun protectedMap(a: Context, notes: MutableList<String>): Map<String, String> {
        val m = HashMap<String, String>(); fun add(p: String, why: String) { if (p.isNotEmpty() && !m.containsKey(p)) m[p] = why }
        add(a.packageName, "this app"); add("moe.shizuku.privileged.api", "Shizuku"); Pipeline.BLOCK.forEach { add(it, "system service") }
        listOf("android", "com.android.systemui", "com.android.settings", "com.android.phone", "com.google.android.gms", "com.google.android.gsf", "com.android.vending", "com.android.providers.settings").forEach { add(it, "core system") }
        val roles = listOf("HOME", "DIALER", "SMS", "ASSISTANT", "BROWSER", "EMERGENCY", "CALL_REDIRECTION", "CALL_SCREENING")
        val cmd = "echo @@acc; settings get secure enabled_accessibility_services; echo @@ime; settings get secure default_input_method; echo @@lis; settings get secure enabled_notification_listeners; echo @@vpn; settings get secure always_on_vpn_app; echo @@afl; settings get secure autofill_service; " +
            roles.joinToString("; ") { "echo @@role$it; cmd role get-role-holders android.app.role.$it" } + "; echo @@idle; cmd deviceidle whitelist; echo @@fg; dumpsys activity services; echo @@media; dumpsys media_session; echo @@dpm; dumpsys device_policy; echo @@alarm; dumpsys alarm | grep -i -E 'alarmclock|AlarmClockInfo'"
        val r = Sh.exec(cmd, false, 120000); if (!r.ok && r.out.isEmpty()) { notes.add("Protection scan failed (exit ${r.code}); nothing will be recommended."); m["*"] = "protection scan failed"; return m }
        val s = sections(r.out)
        Parse.componentPkgs(s["acc"] ?: "").forEach { add(it, "accessibility service") }; Parse.componentPkgs(s["lis"] ?: "").forEach { add(it, "notification listener") }
        Parse.componentPkgs(s["ime"] ?: "").forEach { add(it, "keyboard") }; Parse.componentPkgs(s["afl"] ?: "").forEach { add(it, "autofill") }
        (s["vpn"] ?: "").trim().takeIf { it.isNotEmpty() && it != "null" }?.let { add(it, "always-on VPN") }
        for (ro in roles) (s["role$ro"] ?: "").lines().map { it.trim() }.filter { it.contains('.') }.forEach { add(it, "default app ($ro)") }
        Parse.idleUser(s["idle"] ?: "").forEach { add(it, "you exempted it from battery optimization") }
        Parse.fgServices(s["fg"] ?: "").forEach { add(it, "running foreground service (media/navigation/VPN/location)") }
        Parse.pkgTokens(s["media"] ?: "").forEach { add(it, "active media session") }
        Parse.adminPkgs(s["dpm"] ?: "").forEach { add(it, "device admin") }
        Parse.pkgTokens(s["alarm"] ?: "").forEach { add(it, "alarm clock") }
        keep().forEach { add(it, "on your keep list") }
        if ((s["fg"] ?: "").isEmpty()) notes.add("Foreground-service check returned nothing: apps with running services may not be protected, so tier 1 is withheld.")
        return m
    }
    fun rss(): Map<String, Int> {
        val r = HashMap<String, Long>()
        Sh.exec("ps -A -o RSS,NAME", false, 30000).out.lines().drop(1).forEach { l -> val t = l.trim().split(Regex("\\s+"), 2); if (t.size == 2) { val kb = t[0].toLongOrNull(); val n = t[1].substringBefore(':'); if (kb != null) r[n] = (r[n] ?: 0L) + kb } }
        return r.mapValues { (it.value / 1024).toInt() }
    }
    fun battByPkg(notes: MutableList<String>): Map<String, BattUid>? {
        val o = Sh.exec("dumpsys batterystats", false, 90000); val u = Parse.battUids(o.out)
        if (u.isEmpty()) { notes.add("Battery statistics unavailable (${if (o.code == -3) "timed out" else "unrecognised output"}): background-activity evidence is missing, tier 1 is withheld."); return null }
        val uids = Parse.uidMap(Sh.exec("pm list packages -U", false, 30000).out); val byKey = u.values.associateBy { it.id }
        return uids.mapNotNull { (p, uid) -> byKey[Parse.uidKey(uid)]?.let { p to it } }.toMap()
    }
    fun lastUsedDays(a: Context, notes: MutableList<String>): Map<String, Int>? {
        if (!Sys.usageAccess(a)) { notes.add("Usage access is off: Lunar cannot tell which apps you do not use, so tiers 1 and 2 are withheld."); return null }
        return try {
            val u = a.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager; val now = System.currentTimeMillis()
            u.queryAndAggregateUsageStats(now - 120L * 86400000L, now).mapValues { if (it.value.lastTimeUsed <= 0) 999 else ((now - it.value.lastTimeUsed) / 86400000L).toInt() }
        } catch (e: Throwable) { notes.add("Usage statistics failed: ${e.message}"); null }
    }

    fun scan(a: MainActivity, say: (String) -> Unit): AutoScan {
        val notes = ArrayList<String>()
        say("Listing apps"); val pkgs = Debloat.load(a).filter { it.installed }
        say("Checking what must stay untouched"); val prot = protectedMap(a, notes)
        say("Reading usage"); val days = lastUsedDays(a, notes)
        say("Reading memory"); val rss = rss()
        say("Reading battery statistics (up to a minute)"); val batt = battByPkg(notes)
        val fgOk = !notes.any { it.startsWith("Foreground-service") }
        val curated = (Pipeline.DEBLOAT + Engine.XB).toSet() - Pipeline.BLOCK
        val evs = pkgs.map { p ->
            val b = batt?.get(p.id)
            val protWhy = prot["*"] ?: prot[p.id] ?: if (p.cat == Cat.CRIT || p.risk == Risk.PROTECTED) "critical component" else if (p.risk == Risk.HIGH && p.id !in curated) "high-risk component" else null
            val launcher = a.packageManager.getLaunchIntentForPackage(p.id) != null
            val bloat = p.system && p.risk == Risk.LOW && (p.cat == Cat.THIRD || p.cat == Cat.XIAOMI) && p.id !in Pipeline.BLOCK
            Ev(p.id, p.label, p.system, p.enabled, launcher, days?.get(p.id) ?: if (days != null) 999 else null, null, rss[p.id] ?: 0, b?.mah, b?.cpu, b?.wake, p.id in curated, bloat, protWhy)
        }
        // tier 1 needs usage + battery + foreground-service evidence; without them it is withheld rather than guessed
        val t1ok = days != null && batt != null && fgOk
        say("Deciding")
        var recs = AutoLogic.classify(evs).filter { it.tier != 1 || t1ok }
        say("Reading standby buckets")
        val withB = recs.map { r -> if (r.tier == 1) { val b = Sh.exec("am get-standby-bucket ${r.ev.pkg}", false, 15000).out.trim().toIntOrNull(); if (b == 45) null else r } else r }.filterNotNull()
        recs = withB
        return AutoScan(recs, evs.count { it.prot != null }, evs.size, notes)
    }

    fun apply(recs: List<Rec>, say: (String) -> Unit): List<String> {
        val ls = ArrayList<String>(); val sel = recs.filter { it.sel && it.act != Act.REPORT }
        for ((i, r) in sel.withIndex()) {
            say("${i + 1}/${sel.size}  ${r.ev.label}")
            when (r.act) {
                Act.DISABLE -> { val o = Mut.m.change(PkgT(r.ev.pkg), "disabled", "auto")
                    if (o.ok) ls.add("✓ ${r.ev.label}: ${if (o.changed) "disabled, read back: disabled" else "already disabled"}")
                    else { val t = Engine.quietOne(r.ev.pkg, "auto"); ls.add(if (t.ok) "✓ ${r.ev.label}: disable refused (${o.detail.substringAfter(": ").take(50)}), restricted in the background instead" else "✗ ${r.ev.label}: ${o.detail.substringAfter(": ").take(70)}") } }
                Act.RESTRICT -> { val t = Engine.quietOne(r.ev.pkg, "auto"); ls.add(if (t.ok) "✓ ${r.ev.label}: background restricted (verified)" else "✗ ${r.ev.label}: ${t.outs.lastOrNull()?.detail?.substringAfter(": ")?.take(70) ?: "failed"}") }
                else -> {}
            }
        }
        Store.log("auto", "Automatic mode", ls.joinToString("; ")); Store.addL("tweaks", ls.count { it.startsWith("✓") }.toLong())
        return ls
    }
    fun applied(): List<JEntry> = Mut.m.entries().filter { "auto" in it.owners }
    fun undo(): List<String> {
        val ls = ArrayList<String>()
        for (e in applied()) { val t = targetOf(e.key) ?: continue; val o = Mut.m.release(t, "auto"); ls.add((if (o.ok) "✓ " else "✗ ") + o.detail) }
        Store.log("auto", "Automatic mode undone", ls.joinToString("; ")); return ls
    }
}

class AutoPage(a: MainActivity) : Page(a) {
    private lateinit var host: LinearLayout
    private var scan: AutoScan? = null; private var busy = false
    override fun build(): View = with(act) { scaffold("Automatic mode", "Measured, reviewable, undoable") { host = col {}; add(host) } }
    override fun onShow() { if (!busy) idle() }
    private fun idle(): Unit = with(act) {
        host.removeAllViews()
        host.card(4, 16, true) {
            add(tv("Lunar scans this phone and recommends changes from evidence: what you open, what runs in the background and what it costs. Nothing is applied until you review it.", 13f, cText))
            add(tv("Every change is read back to confirm it, and one tap undoes everything Automatic mode did.", 11f, cDim), 6)
        }
        if (!Sys.usageAccess(act)) host.card(10, 14) { add(tv("Usage access is off", 14f, cWarn, "sans-serif-medium")); add(tv("Without it Lunar cannot tell which apps you do not use, so it will only offer the curated telemetry list.", 11f, cDim), 2); add(btn("Grant usage access", false) { act.openSettings(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS, "Usage access") }.compact(), 8, WRAP) }
        host.add(btn("Scan this phone", true) { startScan(Auto.noReview) }, 14)
        host.card(12, 14) {
            add(toggle("Apply without review", "Off by default. When on, the scan applies its recommendations straight away", Auto.noReview) { Auto.noReview = it; idle() })
            if (Auto.keep().isNotEmpty()) add(btn("Clear keep list (${Auto.keep().size} apps)") { Auto.clearKeep(); idle() }.compact(), 8, WRAP)
        }
        val ap = Auto.applied()
        if (ap.isNotEmpty()) host.add(btn("Undo everything Automatic mode did (${ap.size} changes)") { act.bg { val l = Auto.undo(); act.ui { dialog("Undo", l.joinToString("\n").ifEmpty { "Nothing to undo" }); idle() } } }, 12)
    }
    private fun startScan(apply: Boolean) {
        if (!Sh.granted()) { with(act) { host.removeAllViews(); host.card(4, 16) { add(tv("Shizuku isn't authorized.", 14f, cWarn)); add(btn("Open Settings", true) { switchTab(4) }, 12) } }; return }
        busy = true; val st = with(act) { host.removeAllViews(); tv("Starting…", 14f, cText) }; with(act) { host.card(4, 16) { add(tv("Scanning", 16f, cText, "sans-serif-medium")); add(st, 8) } }
        act.bg {
            try {
                val s = Auto.scan(act) { t -> act.ui { st.text = t } }; scan = s
                if (apply) { val ls = Auto.apply(s.recs) { t -> act.ui { st.text = t } }; act.ui { busy = false; showResult(ls) } } else act.ui { busy = false; review() }
            } catch (e: Throwable) { Store.err("auto: " + e.stackTraceToString().take(400)); act.ui { busy = false; host.removeAllViews(); with(act) { host.card(4, 16) { add(tv("Scan failed: ${e.message}", 14f, cBad)); add(btn("Back", true) { idle() }, 12) } } } }
        }
    }
    private fun review(): Unit = with(act) {
        val s = scan!!; host.removeAllViews()
        host.card(4, 14, true) {
            add(kv("Apps scanned", "${s.total}")); add(kv("Protected, never touched", "${s.protectedCount}"))
            add(kv("Recommendations", "${s.recs.count { it.act != Act.REPORT }}"))
            for (n in s.notes) add(tv(n, 11f, cWarn), 6)
        }
        val apply = btn("", true) {}
        fun upd() { val n = s.recs.count { it.sel && it.act != Act.REPORT }; apply.text = if (n == 0) "Nothing to apply" else "Apply recommended ($n)" }
        val names = mapOf(0 to "Telemetry and ads (disable)", 1 to "Unused and busy in the background (restrict)", 2 to "Unused preinstalled apps (disable)", 3 to "Report only")
        for (t in 0..3) {
            val l = s.recs.filter { it.tier == t }; if (l.isEmpty()) continue
            host.add(section(names[t]!!))
            for (r in l) host.card(6, 12) {
                add(row {
                    add(col { add(tv(r.ev.label, 14f, cText, "sans-serif-medium")); add(tv(r.ev.pkg, 10f, cDim), 1); add(tv(r.why, 11f, cDim), 2) }, w = 0, weight = 1f)
                    if (r.act != Act.REPORT) add(glassSwitch(r.sel).apply { setOnCheckedChangeListener { _, b -> r.sel = b; upd() } }, w = WRAP, start = 12)
                })
                if (r.act != Act.REPORT) add(btn("Never touch this app") { Auto.addKeep(r.ev.pkg); r.sel = false; scan = AutoScan(s.recs.filter { it !== r }, s.protectedCount + 1, s.total, s.notes); review() }.compact(), 6, WRAP)
            }
        }
        if (s.recs.none { it.act != Act.REPORT }) host.card(10, 14) { add(tv("Nothing to change. Either the phone is already clean or the evidence needed to recommend more is missing (see notes above).", 13f, cDim)) }
        upd(); host.add(apply, 14)
        apply.setOnClickListener {
            val n = s.recs.count { it.sel && it.act != Act.REPORT }; if (n == 0) return@setOnClickListener
            dialog("Apply $n changes?", "Each change is verified by read-back. You can undo all of them from this page.", "Apply", "Cancel") {
                busy = true; host.removeAllViews(); val st = tv("Starting…", 14f, cText); host.card(4, 16) { add(tv("Applying", 16f, cText, "sans-serif-medium")); add(st, 8) }
                act.bg { val ls = Auto.apply(s.recs) { t -> act.ui { st.text = t } }; act.ui { busy = false; showResult(ls) } }
            }
        }
    }
    private fun showResult(ls: List<String>): Unit = with(act) {
        host.removeAllViews()
        host.card(4, 16, true) { add(tv("${ls.count { it.startsWith("✓") }} of ${ls.size} applied and verified", 18f, cText, "sans-serif-semibold")); for (l in ls) add(tv(l, 11f, if (l.startsWith("✓")) cGood else cBad), 4) }
        host.add(btn("Undo all", false) { act.bg { val l = Auto.undo(); act.ui { dialog("Undo", l.joinToString("\n").ifEmpty { "Nothing to undo" }); idle() } } }, 12)
        host.add(btn("Done", true) { idle() }, 10)
    }
}
