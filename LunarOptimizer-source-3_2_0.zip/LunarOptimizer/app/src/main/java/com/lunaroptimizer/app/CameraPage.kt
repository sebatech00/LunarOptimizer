package com.lunaroptimizer.app

import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.util.Locale

class CamInfo(val id: String, val face: String, val mp: String, val level: String, val raw: Boolean, val manual: Boolean, val ois: Boolean, val logical: Boolean, val phys: List<String>, val focal: String)

object Cam {
    fun read(a: MainActivity): List<CamInfo> = try {
        val cm = a.getSystemService(android.content.Context.CAMERA_SERVICE) as CameraManager
        cm.cameraIdList.mapNotNull { id ->
            try {
                val ch = cm.getCameraCharacteristics(id); val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
                val sz = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
                CamInfo(id, when (ch.get(CameraCharacteristics.LENS_FACING)) { CameraCharacteristics.LENS_FACING_BACK -> "back"; CameraCharacteristics.LENS_FACING_FRONT -> "front"; else -> "external" },
                    if (sz != null) String.format(Locale.US, "%.0f MP", sz.width * sz.height / 1e6) else "?",
                    when (ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) { 0 -> "LIMITED"; 1 -> "FULL"; 2 -> "LEGACY"; 3 -> "LEVEL_3"; 4 -> "EXTERNAL"; else -> "?" },
                    3 in caps, 1 in caps, ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.any { it == 1 } == true, 11 in caps, ch.physicalCameraIds.toList(),
                    ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()?.let { String.format(Locale.US, "%.1f mm", it) } ?: "?")
            } catch (e: Throwable) { null }
        }
    } catch (e: Throwable) { emptyList() }
}

class CameraPage(a: MainActivity) : Page(a) {
    private lateinit var checks: LinearLayout
    override fun build(): View = with(act) {
        scaffold("Camera") {
            card(4, 16, true) {
                add(tv("What can change", 16f, cText, "sans-serif-semibold"))
                add(tv("Photo quality and color come from the phone's ISP and Xiaomi's camera app. No ADB or Shizuku setting changes them without root. What helps is the right in-app settings and a camera that isn't starved of resources.", 12f, cSilver), 6)
                add(btn("Open Camera", true) { if (!open(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) toast("No camera app found") }.compact(), 12)
            }
            add(section("Best in-app settings"))
            card(0, 14) {
                val g = listOf(
                    Triple("Leica Authentic is the natural look, Vibrant is punchier. DXOMARK found results very similar; it is taste. Pro and 50MP modes shoot Vibrant only.", "Review", cIce),
                    Triple("Keep HDR on Auto. Xiaomi's HDR is compatible with Google's Ultra HDR, so photos pop in the HyperOS Gallery.", "Review", cIce),
                    Triple("Default is 12.5 MP pixel-binned, best for low light. Use 50MP mode only in good light for extra detail.", "Review", cIce),
                    Triple("For editing, shoot RAW (DNG) in Pro mode. Reviewers do this for the cleanest results.", "Review", cIce),
                    Triple("Some guides suggest -0.3 EV to protect highlights.", "Community", cWarn),
                    Triple("Camera > More > Edit makes HyperOS remember the last mode and lens.", "Guide", cIce),
                    Triple("Avoid shooting while GetApps installs or updates apps; Xiaomi says the camera can lag then.", "Xiaomi FAQ", cGood))
                for ((i, t) in g.withIndex()) { if (i > 0) add(View(act).apply { setBackgroundColor(0x1AFFFFFF) }, 10, MATCH, 1); add(tv(t.first, 12f, cText), if (i == 0) 0 else 10); add(tv(t.second, 10f, t.third), 3) }
            }
            add(section("Your camera hardware"))
            val cams = Cam.read(act)
            if (cams.isEmpty()) card(0, 14) { add(tv("Camera info isn't readable.", 12f, cDim)) }
            for (c in cams) card(8, 14) {
                add(tv("Camera ${c.id} · ${c.face} · ${c.mp}", 14f, cText, "sans-serif-medium"))
                add(tv("${c.level} · ${c.focal}" + (if (c.ois) " · OIS" else "") + (if (c.raw) " · RAW" else "") + (if (c.manual) " · manual sensor" else "") + (if (c.logical) " · logical, lenses ${c.phys.joinToString(",")}" else ""), 11f, cDim), 3)
            }
            card(8, 14) {
                val back = cams.firstOrNull { it.face == "back" }
                add(tv("Third-party camera apps", 14f, cText, "sans-serif-medium"))
                add(tv((if (back != null && back.level in listOf("FULL", "LEVEL_3")) "Camera2 is fully supported (${back.level})" + (if (back.raw) " with RAW" else "") + "." else "Camera2 support is limited.") + " Apps like Open Camera or GCam ports can use it, but the stock app keeps proprietary HDR and night processing they can't fully reach, and GCam ports are often flaky on Xiaomi. Which lenses appear depends on what the camera HAL exposes.", 11f, cDim), 4)
            }
            add(section("Readiness"))
            card(0, 14) { checks = this; add(tv("Checking…", 12f, cDim)) }
            card(12, 14) {
                add(tv("Not possible without root", 14f, cWarn, "sans-serif-medium"))
                add(tv("Changing ISP or HAL tuning, color science, tone mapping, sharpening or noise reduction, or forcing hidden camera system properties.", 12f, cDim), 6)
            }
        }
    }
    override fun onShow() { check() }
    private fun check() {
        act.bg {
            val (tot, free) = Sys.storage(act); val b = Sys.battery(act); val g = Sh.granted()
            val bucket = if (g) Engine.bucketOf("com.android.camera") else null
            val per = if (g) Engine.dex().second else emptyMap()
            val mp = if (g && Debloat.isInstalled(act, "com.xiaomi.mipicks")) Engine.bucketOf("com.xiaomi.mipicks") else null
            act.ui { fill(free.toFloat() / tot, b, bucket, per, mp, g) }
        }
    }
    private fun fill(freeFrac: Float, b: Sys.Batt, bucket: Int?, per: Map<String, String>, mp: Int?, g: Boolean) = with(act) {
        checks.removeAllViews()
        fun line(ok: Boolean?, t: String, fix: String? = null, f: (() -> Unit)? = null) { checks.add(row { setPadding(0, dp(7), 0, dp(7)); add(tv(when (ok) { true -> "✓"; false -> "✗"; null -> "•" }, 14f, when (ok) { true -> cGood; false -> cWarn; null -> cDim }), w = dp(22)); add(tv(t, 12f, cText), w = 0, weight = 1f); if (fix != null && f != null) add(btn(fix) { f() }.compact(), w = WRAP, start = 8) }) }
        line(freeFrac >= 0.15f, "Storage ${String.format(Locale.US, "%.0f", freeFrac * 100)}% free" + if (freeFrac < 0.15f) " (low space slows saves)" else "")
        line((b.thermal ?: 0) <= 1, "Thermal status ${Sys.thermalText(b.thermal)}" + if ((b.thermal ?: 0) > 1) " (cool down first)" else "")
        line(!b.saver, if (b.saver) "Battery Saver is on and can limit the camera" else "Battery Saver off")
        if (!g) { line(null, "Shizuku needed for background and compile checks"); return@with }
        line(bucket == null || bucket < 40, "Camera app standby bucket: ${Engine.bucketName(bucket)}", "Fix") { act.bg { Sh.exec("am set-standby-bucket com.android.camera working_set"); act.ui { toast("Camera bucket: ${Engine.bucketName(Engine.bucketOf("com.android.camera"))}"); check() } } }
        for (p in listOf("com.android.camera", "com.miui.gallery")) { val st = per[p]; if (st != null) line(st in Engine.DONE, "${p.substringAfterLast('.')} compiled: $st", if (st in Engine.DONE) null else "Compile") { act.bg { val r = Sh.exec("cmd package compile -m speed -f $p", false, 180000); act.ui { toast("${p.substringAfterLast('.')}: ${if (r.out.contains("Success")) "compiled" else "failed"}"); check() } } } }
        if (mp != null) line(mp >= 45, "GetApps background: ${if (mp >= 45) "paused" else Engine.bucketName(mp)}", if (mp >= 45) null else "Pause") { act.bg { Engine.quiet(listOf("com.xiaomi.mipicks"), null); act.ui { check() } } }
    }
}
