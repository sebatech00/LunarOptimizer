package com.lunaroptimizer.app

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.*
import android.widget.*
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

val cBg = 0xFF06051A.toInt()
val cIndigo = 0xFF5B4BFF.toInt()
val cCard2 = 0xF20C0A26.toInt()
val cText = 0xFFE8EEF9.toInt()
val cDim = 0xFF8D9AB8.toInt()
val cSilver = 0xFFC9D3E6.toInt()
val cIce = 0xFF7FD6FF.toInt()
val cViolet = 0xFF8B7CFF.toInt()
val cGood = 0xFF6EE7B7.toInt()
val cWarn = 0xFFFFC66E.toInt()
val cBad = 0xFFFF7A8A.toInt()
val cStroke = 0x2EC9D3E6

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun View.dp(v: Int): Int = context.dp(v)
fun View.dpf(v: Float): Float = context.dpf(v)

object Haptics { fun tick(v: View) { if (Store.haptics) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) } }

fun Context.tv(s: CharSequence, sp: Float = 14f, color: Int = cText, weight: String = "sans-serif", style: Int = Typeface.NORMAL): TextView =
    TextView(this).apply { text = s; textSize = sp; setTextColor(color); typeface = Fonts.of(weight); setLineSpacing(0f, 1.1f) }

fun Context.col(pad: Int = 0, block: LinearLayout.() -> Unit = {}): LinearLayout =
    LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; if (pad > 0) setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); block() }

fun Context.row(block: LinearLayout.() -> Unit = {}): LinearLayout =
    LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; block() }

fun <T : View> LinearLayout.add(v: T, top: Int = 0, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f, start: Int = 0): T {
    addView(v, LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top); marginStart = dp(start) })
    return v
}

fun View.cardBg(radius: Int = 22, hi: Boolean = false) {
    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (hi) 0x469D8CFF else 0x2E7F73FF, if (hi) 0x182BB3FF else 0x0EFFFFFF)).apply {
        cornerRadius = dpf(radius.toFloat()); setStroke(dp(1), if (hi) 0x66C9D3FF else 0x36AEB6FF)
    }
}

fun LinearLayout.card(top: Int = 12, pad: Int = 16, hi: Boolean = false, block: LinearLayout.() -> Unit): LinearLayout {
    val c = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); cardBg(18, hi); block() }
    add(c, top)
    return c
}

fun Context.btn(label: String, primary: Boolean = false, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label; textSize = 13f; gravity = Gravity.CENTER; typeface = Fonts.of("sans-serif-medium")
    setTextColor(if (primary) Color.WHITE else cText)
    setPadding(dp(16), dp(11), dp(16), dp(11))
    val bg = if (primary) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cIndigo, cViolet, 0xFF6FC8FF.toInt())) else GradientDrawable().apply { setColor(0x1CFFFFFF); setStroke(dp(1), 0x30FFFFFF) }
    bg.cornerRadius = dpf(14f)
    background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null)
    setOnClickListener { Haptics.tick(it); onClick() }
}

fun Context.kv(k: String, v: String, vc: Int = cText): LinearLayout = row {
    setPadding(0, dp(6), 0, dp(6))
    add(tv(k, 13f, cDim), w = 0, weight = 1f)
    add(tv(v, 13f, vc, "sans-serif-medium").apply { gravity = Gravity.END }, w = 0, weight = 1.4f, start = 8)
}

fun Context.section(t: String): TextView = tv(t, 13f, cSilver, "sans-serif-medium").apply { setPadding(dp(4), dp(22), 0, dp(6)) }
fun TextView.compact(): TextView = apply { textSize = 12f; setPadding(dp(14), dp(9), dp(14), dp(9)) }
fun Context.glassSwitch(checked: Boolean = false): Switch = Switch(this).apply {
    isChecked = checked; val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    thumbTintList = ColorStateList(st, intArrayOf(cIce, cDim)); trackTintList = ColorStateList(st, intArrayOf(0x557FD6FF, 0x33FFFFFF))
}
object Fonts {
    private var ctx: Context? = null; private val cache = HashMap<String, Typeface>()
    fun init(c: Context) { ctx = c.applicationContext }
    fun of(w: String): Typeface = cache.getOrPut(w) {
        val f = when { w.contains("semibold") -> "SemiBold"; w.contains("medium") -> "Medium"; w.contains("light") || w.contains("thin") -> "Light"; else -> "Regular" }
        try { Typeface.createFromAsset(ctx!!.assets, "fonts/Inter-$f.otf") } catch (e: Throwable) { Typeface.create(w, Typeface.NORMAL) }
    }
}

fun Context.chip(label: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label; textSize = 12f; setTextColor(if (selected) 0xFF04101C.toInt() else cText); typeface = Fonts.of("sans-serif-medium")
    setPadding(dp(14), dp(8), dp(14), dp(8))
    background = GradientDrawable().apply { cornerRadius = dpf(20f); if (selected) setColor(cIce) else { setColor(0x14FFFFFF); setStroke(dp(1), 0x28FFFFFF) } }
    setOnClickListener { Haptics.tick(it); onClick() }
}

fun Context.toggle(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout = row {
    setPadding(0, dp(8), 0, dp(8))
    add(col { add(tv(title, 15f, cText, "sans-serif-medium")); if (sub.isNotEmpty()) add(tv(sub, 12f, cDim), 2) }, w = 0, weight = 1f)
    val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    add(Switch(this@toggle).apply {
        isChecked = checked
        thumbTintList = ColorStateList(st, intArrayOf(cIce, cDim))
        trackTintList = ColorStateList(st, intArrayOf(0x557FD6FF, 0x33FFFFFF))
        setOnCheckedChangeListener { v, b -> Haptics.tick(v); onChange(b) }
    }, w = WRAP, start = 12)
}

fun LinearLayout.navCard(title: String, sub: String, tag: String? = null, onClick: () -> Unit): LinearLayout {
    val c = card(10, 14) {
        val r = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        t.add(context.tv(title, 16f, cText, "sans-serif-medium")); t.add(context.tv(sub, 12f, cDim), 2)
        r.add(t, w = 0, weight = 1f)
        if (tag != null) r.add(context.tv(tag, 11f, cIce), w = WRAP, start = 8)
        r.add(context.tv("›", 24f, cDim), w = WRAP, start = 8)
        add(r)
    }
    c.setOnClickListener { Haptics.tick(it); onClick() }
    return c
}

fun Context.toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

fun Context.dialog(title: String, msg: String, ok: String = "OK", cancel: String? = null, onOk: (() -> Unit)? = null) {
    val b = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(title).setMessage(msg)
    b.setPositiveButton(ok) { _, _ -> onOk?.invoke() }
    if (cancel != null) b.setNegativeButton(cancel, null)
    b.show()
}

fun Context.copyText(label: String, s: String) {
    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, s))
    toast("Copied")
}

fun Context.seek(max: Int, progress: Int, onChange: (Int, Boolean) -> Unit, onStart: () -> Unit = {}, onStop: () -> Unit = {}): SeekBar = SeekBar(this).apply {
    this.max = max; this.progress = progress
    progressTintList = ColorStateList.valueOf(cIce); thumbTintList = ColorStateList.valueOf(cIce)
    progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { onChange(p, u) }
        override fun onStartTrackingTouch(s: SeekBar) { onStart() }
        override fun onStopTrackingTouch(s: SeekBar) { onStop() }
    })
}

// ---------- custom views ----------
class MoonView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stars = FloatArray(100 * 3)
    init { val r = java.util.Random(11); for (i in 0 until 100) { stars[i * 3] = r.nextFloat(); stars[i * 3 + 1] = r.nextFloat(); stars[i * 3 + 2] = 0.4f + r.nextFloat() * 1.1f } }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val d = resources.displayMetrics.density
        p.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(0xFF0D1636.toInt(), cBg), null, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        for (i in 0 until 100) { p.color = Color.argb(60 + (i * 53) % 150, 220, 230, 255); c.drawCircle(stars[i * 3] * w, stars[i * 3 + 1] * h, stars[i * 3 + 2] * d, p) }
        val cx = w * 0.80f; val cy = h * 0.46f; val r = h * 0.28f
        p.shader = RadialGradient(cx, cy, r * 2.8f, intArrayOf(0x557FD6FF, 0x229D8CFF, 0x00000000), floatArrayOf(0.2f, 0.55f, 1f), Shader.TileMode.CLAMP); c.drawCircle(cx, cy, r * 2.8f, p)
        p.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.35f, r * 1.5f, intArrayOf(0xFFF6F8FF.toInt(), 0xFFB9C5DE.toInt(), 0xFF76849F.toInt()), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP); c.drawCircle(cx, cy, r, p)
        p.shader = null; p.color = 0x2A2B3A5A
        c.drawCircle(cx - r * 0.38f, cy + r * 0.25f, r * 0.24f, p); c.drawCircle(cx + r * 0.30f, cy - r * 0.30f, r * 0.17f, p); c.drawCircle(cx + r * 0.25f, cy + r * 0.40f, r * 0.12f, p); c.drawCircle(cx - r * 0.10f, cy - r * 0.50f, r * 0.09f, p)
        p.shader = LinearGradient(0f, h * 0.6f, 0f, h, intArrayOf(0x00050A0F, cBg), null, Shader.TileMode.CLAMP); c.drawRect(0f, h * 0.6f, w, h, p); p.shader = null
    }
}

class RingView(ctx: Context) : View(ctx) {
    private var shown = 0f
    private var big = ""; private var small = ""; private var color = cIce
    private var anim: ValueAnimator? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x1FFFFFFF; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val t1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cText; textAlign = Paint.Align.CENTER; typeface = Fonts.of("sans-serif-light") }
    private val t2 = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = cDim; textAlign = Paint.Align.CENTER; typeface = Fonts.of("sans-serif") }
    fun set(v: Float, big: String, small: String, color: Int) {
        this.big = big; this.small = small; this.color = color
        val tgt = v.coerceIn(0f, 1f); anim?.cancel()
        if (Store.anims && abs(tgt - shown) > 0.005f) {
            anim = ValueAnimator.ofFloat(shown, tgt).apply { duration = 450; addUpdateListener { shown = it.animatedValue as Float; invalidate() }; start() }
        } else { shown = tgt; invalidate() }
    }
    override fun onDraw(c: Canvas) {
        val lh = dpf(20f); val s = min(width.toFloat(), height - lh); val sw = s * 0.075f; val m = sw
        val cx = width / 2f; val cy = s / 2f
        val rect = RectF(cx - s / 2 + m, cy - s / 2 + m, cx + s / 2 - m, cy + s / 2 - m)
        track.strokeWidth = sw; c.drawArc(rect, 135f, 270f, false, track)
        arc.strokeWidth = sw * 2f; arc.color = (color and 0x00FFFFFF) or 0x1E000000; c.drawArc(rect, 135f, 270f * shown, false, arc)
        arc.strokeWidth = sw; arc.color = color; c.drawArc(rect, 135f, 270f * shown, false, arc)
        t1.textSize = s * 0.25f; c.drawText(big, cx, cy + t1.textSize * 0.36f, t1)
        t2.textSize = dpf(11f); c.drawText(TextUtils.ellipsize(small, t2, width - dpf(6f), TextUtils.TruncateAt.END).toString(), cx, height - dpf(4f), t2)
    }
}

class BarView(ctx: Context) : View(ctx) {
    var v = 0f; set(x) { field = x.coerceIn(0f, 1f); invalidate() }
    var color = cIce
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = height / 2f; p.shader = null; p.color = 0x22FFFFFF; c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, p)
        if (v > 0f) { p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, color, cViolet, Shader.TileMode.CLAMP); c.drawRoundRect(0f, 0f, max(height.toFloat(), width * v), height.toFloat(), r, r, p) }
    }
}

class LineChartView(ctx: Context) : View(ctx) {
    var data: List<Float> = emptyList(); var color = cIce; var unit = ""; var fixedMin: Float? = null; var fixedMax: Float? = null
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cDim }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); txt.textSize = dpf(10f)
        if (data.size < 2) { c.drawText("Collecting samples while the app is open…", dpf(4f), h / 2, txt); return }
        val lo = fixedMin ?: data.min(); val hi = fixedMax ?: data.max(); val rng = max(hi - lo, 1f)
        val padX = dpf(34f); val padY = dpf(8f)
        val path = Path(); val n = data.size
        for (i in 0 until n) { val x = padX + (w - padX) * i / (n - 1); val y = h - padY - (data[i] - lo) / rng * (h - 2 * padY); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
        val area = Path(path); area.lineTo(w, h - padY); area.lineTo(padX, h - padY); area.close()
        fill.shader = LinearGradient(0f, 0f, 0f, h, (color and 0x00FFFFFF) or 0x55000000, 0x00000000, Shader.TileMode.CLAMP); c.drawPath(area, fill)
        line.color = color; c.drawPath(path, line)
        c.drawText("${hi.toInt()}$unit", 0f, padY + txt.textSize, txt); c.drawText("${lo.toInt()}$unit", 0f, h - padY, txt)
    }
}

class ZoomImageView(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) { val o = field; field = v; if (v != null && (o == null || o.width != v.width || o.height != v.height)) fit(); invalidate() }
    private val m = Matrix(); private val vals = FloatArray(9); private var minScale = 1f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoomBy(d.scaleFactor, d.focusX, d.focusY); return true }
    })
    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean { m.postTranslate(-dx, -dy); clampM(); invalidate(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean { if (scale() > minScale * 1.05f) fit() else zoomBy(3f, e.x, e.y); invalidate(); return true }
    })
    private fun scale(): Float { m.getValues(vals); return vals[Matrix.MSCALE_X] }
    fun fit() {
        val b = bmp ?: return; if (width == 0 || height == 0) return
        val s = min(width / b.width.toFloat(), height / b.height.toFloat()); minScale = s
        m.reset(); m.postScale(s, s); m.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
    }
    private fun zoomBy(f: Float, fx: Float, fy: Float) {
        val s = scale(); val ns = (s * f).coerceIn(minScale, minScale * 12f); m.postScale(ns / s, ns / s, fx, fy); clampM(); invalidate()
    }
    private fun clampM() {
        val b = bmp ?: return; val r = RectF(0f, 0f, b.width.toFloat(), b.height.toFloat()); m.mapRect(r)
        var dx = 0f; var dy = 0f
        dx = if (r.width() <= width) (width - r.width()) / 2f - r.left else if (r.left > 0) -r.left else if (r.right < width) width - r.right else 0f
        dy = if (r.height() <= height) (height - r.height()) / 2f - r.top else if (r.top > 0) -r.top else if (r.bottom < height) height - r.bottom else 0f
        m.postTranslate(dx, dy)
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { fit() }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bmp == null) return false
        parent?.requestDisallowInterceptTouchEvent(true)
        sg.onTouchEvent(e); if (!sg.isInProgress) gd.onTouchEvent(e)
        return true
    }
    override fun onDraw(c: Canvas) { c.drawColor(0xFF03050A.toInt()); bmp?.let { c.drawBitmap(it, m, paint) } }
}

class IconView(ctx: Context, private val kind: Int) : View(ctx) {
    var active = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = 1.8f }
    override fun onDraw(c: Canvas) {
        c.save(); c.scale(width / 24f, height / 24f); p.color = if (active) cIce else cDim; p.style = Paint.Style.STROKE
        when (kind) {
            0 -> { val a = Path(); a.moveTo(4f, 10.5f); a.lineTo(12f, 4f); a.lineTo(20f, 10.5f); a.lineTo(20f, 20f); a.lineTo(14.5f, 20f); a.lineTo(14.5f, 14f); a.lineTo(9.5f, 14f); a.lineTo(9.5f, 20f); a.lineTo(4f, 20f); a.close(); c.drawPath(a, p) }
            1 -> { val a = Path(); a.moveTo(13f, 3f); a.lineTo(5f, 13.5f); a.lineTo(11f, 13.5f); a.lineTo(10f, 21f); a.lineTo(19f, 10f); a.lineTo(13f, 10f); a.close(); c.drawPath(a, p) }
            2 -> { c.drawRoundRect(3f, 7f, 19f, 17f, 2.5f, 2.5f, p); c.drawLine(21f, 10.5f, 21f, 13.5f, p); p.style = Paint.Style.FILL; c.drawRoundRect(5.5f, 9.5f, 14f, 14.5f, 1f, 1f, p) }
            3 -> { c.drawRoundRect(4f, 5f, 20f, 20f, 2.5f, 2.5f, p); c.drawLine(4f, 10f, 20f, 10f, p); c.drawLine(10f, 5f, 10f, 10f, p); c.drawLine(14f, 5f, 14f, 10f, p) }
            else -> { c.drawLine(4f, 6f, 20f, 6f, p); c.drawLine(4f, 12f, 20f, 12f, p); c.drawLine(4f, 18f, 20f, 18f, p); p.style = Paint.Style.FILL; c.drawCircle(8f, 6f, 2.2f, p); c.drawCircle(16f, 12f, 2.2f, p); c.drawCircle(10f, 18f, 2.2f, p) }
        }
        c.restore()
    }
}

class NavBar(ctx: Context, private val onSel: (Int) -> Unit) : LinearLayout(ctx) {
    private val icons = ArrayList<IconView>(); private val labels = ArrayList<TextView>()
    init {
        orientation = HORIZONTAL; setBackgroundColor(0xD9080A1C.toInt())
        val names = arrayOf("Home", "Tweaks", "Debloat", "Battery", "Settings")
        for (i in 0 until 5) {
            val cell = LinearLayout(ctx).apply { orientation = VERTICAL; gravity = Gravity.CENTER; setOnClickListener { Haptics.tick(it); onSel(i) } }
            val ic = IconView(ctx, intArrayOf(0, 1, 3, 2, 4)[i]); val lb = ctx.tv(names[i], 10f, cDim, "sans-serif-medium")
            cell.addView(ic, LayoutParams(dp(24), dp(24))); cell.addView(lb, LayoutParams(WRAP, WRAP).apply { topMargin = dp(3) })
            addView(cell, LayoutParams(0, MATCH, 1f)); icons.add(ic); labels.add(lb)
        }
    }
    fun select(i: Int) { for (k in 0 until 5) { icons[k].active = (k == i); icons[k].invalidate(); labels[k].setTextColor(if (k == i) cIce else cDim) } }
}

class BokehView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var bg: Bitmap? = null
    private val t0 = System.nanoTime()
    private val cols = intArrayOf(0x405B4BFF, 0x38B06BFF, 0x302BB3FF)
    private val dots = FloatArray(14 * 4).also { val r = java.util.Random(9); for (i in 0 until 14) { it[i * 4] = r.nextFloat(); it[i * 4 + 1] = r.nextFloat(); it[i * 4 + 2] = 2f + r.nextFloat() * 5f; it[i * 4 + 3] = 0.008f + r.nextFloat() * 0.015f } }
    init { try { val id = resources.getIdentifier("bg_lunar", "drawable", ctx.packageName); if (id != 0) bg = BitmapFactory.decodeResource(resources, id) } catch (e: Throwable) {} }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val b = bg
        if (b != null) { val k = max(w / b.width, h / b.height); c.save(); c.translate((w - b.width * k) / 2f, (h - b.height * k) / 2f); c.scale(k, k); c.drawBitmap(b, 0f, 0f, p); c.restore() } else c.drawColor(cBg)
        val t = if (Store.anims) (System.nanoTime() - t0) / 1e9f else 0f
        for (i in 0..2) {
            val cx = w * (0.2f + 0.3f * i + 0.07f * sin(t * 0.18f + i)); val cy = h * (0.22f + 0.28f * i + 0.05f * cos(t * 0.14f + i * 2f)); val r = w * 0.62f
            p.shader = RadialGradient(cx, cy, r, intArrayOf(cols[i], 0x00000000), null, Shader.TileMode.CLAMP); c.drawCircle(cx, cy, r, p)
        }
        p.shader = null
        val d = resources.displayMetrics.density
        for (i in 0 until 14) { val yy = ((dots[i * 4 + 1] - t * dots[i * 4 + 3]) % 1f + 1f) % 1f; p.color = Color.argb(40 + (i * 7) % 40, 160, 170, 255); c.drawCircle(dots[i * 4] * w, yy * h, dots[i * 4 + 2] * d, p) }
        if (Store.anims && isShown) postInvalidateDelayed(80)
    }
}

class CoresView(ctx: Context) : View(ctx) {
    var f = IntArray(8); var m = IntArray(8)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cDim; textAlign = Paint.Align.CENTER }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val slot = w / 8f; tp.textSize = dpf(9f); val bh = h - dpf(16f)
        for (i in 0 until 8) {
            val x = i * slot + slot * 0.2f; val bw = slot * 0.6f; val frac = if (m[i] > 0) (f[i].toFloat() / m[i]).coerceIn(0f, 1f) else 0f
            p.shader = null; p.color = 0x22FFFFFF; c.drawRoundRect(x, 0f, x + bw, bh, bw / 3, bw / 3, p)
            p.shader = LinearGradient(0f, bh, 0f, 0f, cIndigo, cIce, Shader.TileMode.CLAMP); c.drawRoundRect(x, bh - bh * frac, x + bw, bh, bw / 3, bw / 3, p); p.shader = null
            c.drawText(if (f[i] > 0) String.format(java.util.Locale.US, "%.1f", f[i] / 1000f) else "off", x + bw / 2, h - dpf(2f), tp)
        }
    }
}
