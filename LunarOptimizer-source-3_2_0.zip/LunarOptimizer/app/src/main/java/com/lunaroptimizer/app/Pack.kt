package com.lunaroptimizer.app

/** Section J. Lunar Pack contains only what has a documented mechanism, a verified apply and a rollback on the journal.
 *  hzpeak (HyperOS may ignore it) and longpress (no measured benefit) are experimental: off by default and not part of the pack. */
object Pack {
    val ids = listOf("scans", "adaptive", "autorestrict", "dnsad")
    val experimental = listOf("hzpeak", "longpress")
    private const val CACHED = "cached"
    @Volatile var checked = false
    @Volatile var animChecked = false

    fun userOff(id: String) = Store.getS("uoff_$id") == "1"
    fun setUserOff(id: String, off: Boolean) { if (id in ids || id == CACHED) Store.putS("uoff_$id", if (off) "1" else "") }

    /** A 0.5x animation scale (left by an older version) is undone only when it is Lunar's own change. A value you chose yourself is never changed without asking. */
    fun fixAnim(a: MainActivity) {
        if (animChecked || !Sh.granted()) return
        animChecked = true
        a.bg {
            var n = 0; val mine = ArrayList<SettingT>(); val yours = ArrayList<SettingT>()
            for (k in listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")) {
                val t = SettingT("global", k); val cur = t.read(Sh); if (!cur.ok) continue
                val f = cur.v.toFloatOrNull() ?: continue; if (Math.abs(f - 0.5f) >= 0.01f) continue
                val e = Mut.m.entry(t.key)
                if (e != null && (e.applied.isEmpty() || t.same(e.applied, cur.v))) mine.add(t) else yours.add(t)
            }
            for (t in mine) { val o = Mut.m.restore(t, false); if (o.ok) n++ }
            if (n > 0) a.ui { a.toast("Animation scales restored to your original values") }
            if (yours.isNotEmpty()) Prompts.set(Prompts.P("anim", "Animations are at 0.5×", "${yours.joinToString { it.k.substringBefore("_") }}: set outside Lunar. Half-speed animations make the UI feel less fluid. Change to 1.0×?", "Set to 1.0×", {
                a.bg { val ls = yours.map { Mut.m.change(it, "1.0", "fixanim").detail }; a.ui { a.dialog("Animation scales", ls.joinToString("\n")) } } }))
        }
    }

    fun xb(a: MainActivity): List<String> { val all = Debloat.load(a); return (Engine.XB + "com.xiaomi.mipicks").filter { id -> all.any { it.id == id && it.installed && it.enabled } } }

    /** Cached-process limit only when it would RAISE the limit the system is actually using. */
    fun cachedEvidence(): Pair<Boolean, String> {
        val cur = Parse.curMaxCached(Sh.exec("dumpsys activity settings", false, 30000).out) ?: return false to "current limit unreadable"
        return (cur < 48) to "system limit is $cur"
    }

    fun apply(a: MainActivity): List<String> {
        val ls = ArrayList<String>(); val st = TE.states()
        for (id in ids) {
            setUserOff(id, false); val t = TE.byId(id); if (st[id] == true) { ls.add("${t.name}: already on"); continue }
            val (ok, _) = TE.apply(t)
            if (ok && id == "dnsad") { Thread.sleep(1500); if (Net.blocked() < 0) { TE.revert(t); ls.add("${t.name}: DNS server unreachable, reverted"); continue } }
            ls.add("${t.name}: ${if (ok) "on, verified by read-back" else "rejected by the system, nothing changed"}")
        }
        val (need, why) = cachedEvidence(); setUserOff(CACHED, false)
        if (need) { val (ok, _) = TE.apply(TE.byId(CACHED)); ls.add("Keep 48 apps cached ($why): ${if (ok) "on, verified" else "rejected"}") } else ls.add("Keep 48 apps cached: skipped ($why)")
        val pk = xb(a); val n = Engine.quiet(pk, null, "pack"); ls.add("Xiaomi ad, telemetry and updater services restricted: $n of ${pk.size}")
        val notes = ArrayList<String>(); val s = Auto.scan(a) { }; notes.addAll(s.notes)
        val t1 = s.recs.filter { it.tier == 1 }; var m = 0; for (r in t1) if (Engine.quietOne(r.ev.pkg, "pack").ok) m++
        ls.add(if (s.notes.any { it.startsWith("Usage access") || it.startsWith("Battery statistics") }) "Per-phone background restrictions: skipped (${s.notes.first { it.startsWith("Usage access") || it.startsWith("Battery statistics") }.take(90)})" else "Per-phone background restrictions (unused and busy apps): $m of ${t1.size}")
        val sug = Pipeline.suggest(a); val bad = Engine.dex().second.values.count { it in setOf("verify", "run-from-apk", "extract", "quicken", "assume-verified", "error") }
        if (sug != null || bad >= 5) { Sh.bgJob("cmd package bg-dexopt-job"); Store.putS("compile_fp", android.os.Build.FINGERPRINT); Store.putS("compile_ts", System.currentTimeMillis().toString()); ls.add("System dexopt job started (${sug ?: "$bad apps not AOT-compiled"})") }
        else ls.add("System dexopt job: skipped (OS and apps unchanged since the last run)")
        Store.packAuto = true; Store.putS("pack_fp", android.os.Build.FINGERPRINT); Prompts.clear("packdrift"); Store.log("pack", "Lunar Pack", ls.joinToString("; ")); return ls
    }

    fun remove(a: MainActivity): List<String> {
        val ls = ArrayList<String>(); val st = TE.states()
        for (id in ids + CACHED) { val t = TE.byId(id); if (st[id] == true) { ls.add("${t.name}: ${if (TE.revert(t).first) "restored" else "not set by Lunar or restore failed: see journal"}"); setUserOff(id, false) } }
        for (e in Mut.m.entries().filter { "pack" in it.owners }) { val t = targetOf(e.key) ?: continue; val o = Mut.m.release(t, "pack"); ls.add(o.detail) }
        Store.packAuto = false; Store.log("pack", "Lunar Pack removed", ls.joinToString("; ")); return ls
    }

    /** After a reboot or an OS reset some values drift. Re-applies only what you did not turn off, validates DNS first, never silently:
     *  a toast says what was done and anything that needs your decision becomes a card on Home. */
    fun ensure(a: MainActivity) {
        if (!Store.packAuto || !Sh.granted() || checked) return
        checked = true
        if (Store.getS("pack_fp") != null && Store.getS("pack_fp") != android.os.Build.FINGERPRINT) Prompts.set(Prompts.P("packos", "System updated since Lunar Pack was applied", "Re-apply the Pack so the dexopt job and the checks run again for this version.", "Re-apply", { a.bg { val l = Pack.apply(a); a.ui { a.dialog("Lunar Pack", l.joinToString("\n")) } } }))
        a.bg {
            val st = TE.states(); val done = ArrayList<String>(); val problems = ArrayList<String>()
            for (id in ids) {
                if (st[id] == true || userOff(id)) continue; val t = TE.byId(id)
                if (TE.apply(t).first) {
                    if (id == "dnsad") { Thread.sleep(1500); if (Net.blocked() < 0) { TE.revert(t); problems.add("${t.name}: DNS server unreachable, not re-applied") ; continue } }
                    done.add(t.name)
                } else problems.add("${t.name}: rejected by the system")
            }
            val (need, _) = cachedEvidence(); if (need && !userOff(CACHED) && TE.states()[CACHED] != true && TE.apply(TE.byId(CACHED)).first) done.add("Keep 48 apps cached")
            for (p in xb(a)) if (!Sh.exec("cmd appops get $p RUN_ANY_IN_BACKGROUND", false).out.contains("deny") && Engine.quietOne(p, "pack").ok) done.add(p.substringAfterLast('.'))
            if (done.isNotEmpty()) { Store.log("pack", "Lunar Pack re-applied", done.joinToString(", ")); a.ui { a.toast("Lunar Pack re-applied: ${done.joinToString(", ").take(100)}") } }
            if (problems.isNotEmpty()) Prompts.set(Prompts.P("packdrift", "Lunar Pack needs a decision", problems.joinToString("\n"), "Open Tweaks", { a.ui { a.switchTab(1) } }))
        }
    }
}
