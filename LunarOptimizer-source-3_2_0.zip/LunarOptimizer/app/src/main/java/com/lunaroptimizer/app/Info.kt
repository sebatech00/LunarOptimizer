package com.lunaroptimizer.app

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.provider.Settings
import android.view.*
import android.widget.*

class Info(val title: String, val tag: String, val what: String, val cmds: String, val effect: String, val risk: String)

class InfoPage(a: MainActivity) : Page(a) {
    private fun items(): List<Info> {
        val l = ArrayList<Info>()
        l.add(Info("Optimize Now", "Measured", "Diagnoses first (RAM pressure, CPU, thermals, storage, dexopt, background apps), builds a plan from what it measured, runs only what applies, then re-measures.",
            "dumpsys / settings / /proc/pressure / sysfs reads\nonly the selected optimizations from the plan",
            "Skips anything the measurements don't justify and reports what changed, what didn't and what failed. Roll back is offered afterwards.", "Each change shows its own risk before you run it."))
        l.add(Info("Lunar Pack", "Reversible", "One tap applies the curated set: Allow 120 Hz, fast long-press, stop scans, Adaptive Battery, auto-restrict, ad/tracker DNS, and quiets Xiaomi ad, telemetry and updater services.", "see the individual tweaks below", "Everything verified by read-back; Keep applied re-applies after reboots (some device_config values reset).", "DNS blocking can be bypassed by apps with their own resolver. Remove undoes everything."))
        l.add(Info("Quiet Xiaomi services", "Reversible", "Stops Xiaomi ad, analytics and feedback services from running in the background without removing them.", "cmd appops set <package> RUN_ANY_IN_BACKGROUND deny\nam set-standby-bucket <package> restricted", "Fewer background wakeups from telemetry and ad services. Verified by read-back.", "Their features stop running in the background. Roll back resets them."))
        l.add(Info("Deep dexopt", "Reversible", "Compiles every installed app in the background.", "cmd package compile -m speed-profile -a", "Can shorten cold starts. Dexopt status shows how many apps are compiled. Reset compile reverts.", "Runs for minutes and uses some battery while it works."))
        l.add(Info("App compilation", "Reversible", "Recompiles each user app ahead of time using its recorded usage profile.",
            "cmd package compile -m speed-profile -f <package>",
            "Can shorten cold start for apps that have a usage profile. Takes minutes; progress is in the console. No percentage is claimed: time your own launches.", "Uses a little extra storage. ART can recompile again at any time."))
        for (t in TE.all) l.add(Info(t.name, if (t.note.contains("unverified", true)) "Unverified" else "Reversible", t.desc,
            ((t.pre?.let { listOf(it) } ?: emptyList()) + t.ents.map { it.put(it.on) }).joinToString("\n"), t.effect, t.risk + (if (t.note.isNotEmpty()) " Note: ${t.note}." else "") + " Your original value is recorded and Revert restores it."))
        l.add(Info("App power control", "Reversible", "Per-app standby bucket and background-run permission.",
            "am set-standby-bucket <package> <bucket>\ncmd appops set <package> RUN_ANY_IN_BACKGROUND deny|allow",
            "Restricted apps can't wake or run in the background. Read-back is shown after every change.", "Notifications from restricted apps can be delayed."))
        l.add(Info("Debloat", "Reversible", "Disable or remove packages for user 0 only. The factory image is untouched.",
            "pm disable-user --user 0 <package>\npm uninstall -k --user 0 <package>\ncmd package install-existing --user 0 <package>",
            "Stops the package from running. Restore from its screen. Protected components are blocked; higher-risk ones need a second confirmation.", "Disabling the wrong system package can break features."))
        l.add(Info("Live telemetry", "Read-only", "CPU, per-core clocks, GPU and temperatures, refreshed every second while Home is open.",
            "/proc/stat\n/sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq\n/sys/class/thermal/thermal_zone*/temp\n/sys/class/kgsl/kgsl-3d0/*",
            "Shows what the hardware reports. Nodes the kernel doesn't expose are hidden, not guessed.", "None. Read-only."))
        l.add(Info("Battery readings", "Read-only", "Power, capacity vs design and cycle count from the kernel's battery node.",
            "/sys/class/power_supply/battery/{current_now,voltage_now,charge_full,charge_full_design,cycle_count}\ndumpsys battery",
            "Instantaneous watts and design-capacity ratio when the kernel provides them.", "None. Read-only."))
        l.add(Info("Advanced permissions", "Needs Shizuku", "Lets the app change settings and read app sizes without Shizuku afterwards.",
            "pm grant com.lunaroptimizer.app android.permission.WRITE_SECURE_SETTINGS\ncmd appops set com.lunaroptimizer.app GET_USAGE_STATS allow", "Unlocks direct settings writes.", "Revocable in system settings."))
        return l
    }
    override fun build(): View = with(act) {
        scaffold("What it does", "Commands, effects and measured results") {
            card(4, 16) {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xF0064A3B.toInt(), 0xF0062A22.toInt())).apply { cornerRadius = dpf(18f); setStroke(dp(1), 0x6634D399) }
                add(tv("MEASURED ON YOUR PHONE", 11f, cGood, "sans-serif-medium").apply { letterSpacing = 0.12f })
                val n = Store.getL("boosts")
                add(tv(if (n == 0L) "Nothing measured yet" else "$n optimization${if (n == 1L) "" else "s"} run", 26f, cText, "sans-serif-light"), 4)
                if (n > 0) add(kv("Cache trimmed, lifetime", Sys.fmt(Store.getL("trimmed"))))
                Store.getS("last_boost")?.split("|")?.takeIf { it.size >= 6 }?.let { p ->
                    val st = p[0].toLong()
                    add(kv("Last run: free storage", (if (st >= 0) "+" else "") + Sys.fmt(st)))
                    add(kv("Last run: RAM available", "${Sys.fmt(p[1].toLong(), 1024)} → ${Sys.fmt(p[2].toLong(), 1024)}"))
                    add(kv("Last run: processes", "${p[3]} → ${p[4]}")); add(kv("Last run: duration", "${p[5]} ms"))
                }
                add(kv("Tweaks applied and verified", Store.getL("tweaks").toString())); add(kv("Apps compiled", Store.getL("compiled").toString())); add(kv("Package operations verified", Store.getL("pkgops").toString()))
                add(tv("Percent claims such as \"+45% launch speed\" can't be measured by an app alone, so none appear here. This page shows exactly what runs; only before/after numbers read from your phone are reported.", 11f, cDim), 8)
            }
            add(section("Known issues: HyperOS 3 and Xiaomi 14"))
            card(0, 14) {
                add(tv("From reports and Xiaomi bug trackers for HyperOS 3 on the 14 series. Nothing found that is specific to build ${Sys.hyperOs()}.", 11f, cDim))
                val probs = listOf(
                    Triple("Stricter background killing: messaging and fitness apps stop syncing.", "Tweaks > App power > Keep alive, plus Autostart.", "Community"),
                    Triple("Battery drain and heat for ~48 h after an update (reindex and recompile).", "Wait it out, restart once, avoid repeated cache clearing.", "Community"),
                    Triple("Launcher or shade stutter after the update.", "Clear launcher cache (not data) and compile it: Optimize Now does the compile.", "Community"),
                    Triple("Memory extension adds lag and battery use.", "Try it off in Settings > Additional settings (manual).", "Community"),
                    Triple("Gaming and emulation regressions on some devices.", "Keep Joyose and game services; GPU drivers can't be changed without root.", "Community"),
                    Triple("Uneven sustained-load throttling on the Xiaomi 14.", "Thermal limits stay untouched; reduce load, remove the case when gaming.", "Review"),
                    Triple("Camera freeze/crash reported in some builds.", "Keep firmware updated; no supported system tweak.", "Xiaomi bug reports"),
                    Triple("Ads and telemetry in Xiaomi system apps.", "Lunar Pack quiets MSA, analytics and updater services and blocks tracker domains by DNS. Xiaomi's own switches: Settings > Privacy > Ad services, User Experience Program.", "Community"),
                    Triple("Camera lags while GetApps updates apps in the background.", "Lunar Pack pauses GetApps background activity; wait for installs to finish.", "Xiaomi FAQ"),
                    Triple("Camera mode resets every launch.", "Camera > More > Edit to remember the last mode (manual).", "NextPit guide"),
                    Triple("pm disable-user blocked on some system apps.", "Debloat removes for user 0 instead, restorable.", "Community"))
                for ((p, f, c) in probs) { add(tv(p, 12f, cText), 10); add(tv("Fix: $f · $c", 11f, cDim), 2) }
                add(row {
                    add(btn("Privacy settings") { act.openSettings(Settings.ACTION_PRIVACY_SETTINGS, "Privacy") }.compact(), w = 0, weight = 1f)
                    add(btn("Open Autostart") { if (!act.open(Intent().setClassName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))) toast("Not available on this build") }.compact(), w = 0, weight = 1f, start = 8)
                    add(btn("Clear launcher cache") { if (!Sh.granted()) toast("Connect Shizuku first") else bg { val x = Sh.exec("pm clear --cache-only com.miui.home"); ui { toast("Launcher cache: " + x.text().ifEmpty { "exit ${x.code}" }) } } }.compact(), w = 0, weight = 1f, start = 8)
                }, 12)
            }
            for (i in items()) card(10, 16) {
                add(row {
                    add(tv(i.title, 16f, cText, "sans-serif-medium"), w = 0, weight = 1f)
                    val tc = when (i.tag) { "Measured" -> cGood; "Reversible" -> cIce; "Needs Shizuku", "Unverified" -> cWarn; else -> cDim }
                    add(tv(i.tag.uppercase(), 10f, tc, "sans-serif-medium").apply { letterSpacing = 0.08f; setPadding(dp(10), dp(4), dp(10), dp(4)); background = GradientDrawable().apply { cornerRadius = dpf(10f); setStroke(dp(1), tc) } }, w = WRAP)
                })
                add(tv(i.what, 12f, cSilver), 6)
                add(tv("RUNS", 10f, cDim).apply { letterSpacing = 0.12f }, 10)
                add(tv(i.cmds, 11f, cIce).apply { typeface = Typeface.MONOSPACE; setPadding(dp(10), dp(8), dp(10), dp(8)); background = GradientDrawable().apply { setColor(0x66000000); cornerRadius = dpf(10f) } }, 4)
                add(tv("EFFECT", 10f, cDim).apply { letterSpacing = 0.12f }, 10); add(tv(i.effect, 12f, cText), 2)
                add(tv("RISK", 10f, cDim).apply { letterSpacing = 0.12f }, 8); add(tv(i.risk, 12f, cText), 2)
            }
            card(10, 16) {
                add(tv("Not possible without root or an unlocked bootloader", 14f, cWarn, "sans-serif-medium"))
                add(tv("CPU/GPU governors and frequency limits, thermal limits, kernel scheduler, Vulkan or vendor-engine properties. Lunar Optimizer doesn't offer them and doesn't pretend to.", 12f, cDim), 6)
            }
        }
    }
    override fun onShow() { }
}
