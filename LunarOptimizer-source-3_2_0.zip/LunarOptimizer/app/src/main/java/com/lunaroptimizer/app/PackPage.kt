package com.lunaroptimizer.app

import android.view.*
import android.widget.*

/** Measured cold-start times (median of 3 force-stopped launches per app). Lets Lunar Pack be judged by numbers, not claims. */
object ColdStart {
    fun parse(s: String?): Map<String, Int> = (s ?: "").split(",").mapNotNull { x -> x.split("=").let { if (it.size == 2) it[1].toIntOrNull()?.let { v -> it[0] to v } else null } }.toMap()
    fun pick(a: MainActivity, n: Int): List<Pkg> {
        val notes = ArrayList<String>(); val prot = Auto.protectedMap(a, notes); if (prot.containsKey("*")) return emptyList()
        val days = Auto.lastUsedDays(a, notes)
        return Debloat.load(a).filter { it.cat == Cat.USER && it.installed && it.enabled && !prot.containsKey(it.id) && a.packageManager.getLaunchIntentForPackage(it.id) != null }.sortedBy { days?.get(it.id) ?: 999 }.take(n)
    }
    fun measure(a: MainActivity, say: (String) -> Unit): Map<String, Int> {
        val out = LinkedHashMap<String, Int>(); val me = Parse.resolveActivity(Sh.exec("cmd package resolve-activity --brief ${a.packageName}", false, 15000).out)
        for ((i, p) in pick(a, 4).withIndex()) {
            val comp = Parse.resolveActivity(Sh.exec("cmd package resolve-activity --brief ${p.id}", false, 15000).out) ?: continue; val ms = ArrayList<Int>()
            repeat(3) { r -> say("${i + 1}/4  ${p.label}  (${r + 1}/3)"); Sh.exec("am force-stop ${p.id}", false, 15000); Thread.sleep(1200)
                Parse.startTotalMs(Sh.exec("am start -W -n $comp", false, 30000).out)?.let { ms.add(it) }; Sh.exec("input keyevent KEYCODE_HOME", false, 8000); Thread.sleep(600) }
            if (ms.size >= 2) out[p.id] = ms.sorted()[ms.size / 2]
        }
        if (me != null) Sh.exec("am start -n $me", false, 15000)
        return out
    }
}

class PackPage(a: MainActivity) : Page(a) {
    private lateinit var host: LinearLayout
    private var busy = false
    override fun build(): View = with(act) { scaffold("Lunar Pack report", "What is applied, and what it measurably does") { host = col {}; add(host) } }
    override fun onShow() { load() }
    private fun load() {
        if (busy) return; busy = true
        with(act) { host.removeAllViews(); host.card(4, 16) { add(tv("Reading state…", 14f, cText)) } }
        act.bg { val st = if (Sh.granted()) TE.states() else emptyMap(); act.ui { busy = false; render(st, null) } }
    }
    private fun render(st: Map<String, Boolean>, result: String?): Unit = with(act) {
        host.removeAllViews()
        host.card(4, 14, true) {
            add(tv(if (Store.packAuto) "Lunar Pack is on" else "Lunar Pack is off", 18f, if (Store.packAuto) cGood else cText, "sans-serif-semibold"))
            add(tv("Only items with a documented mechanism, a verified apply and a rollback are in the Pack.", 11f, cDim), 4)
            if (Store.getS("pack_fp") != null && Store.getS("pack_fp") != android.os.Build.FINGERPRINT) add(tv("The system was updated since the Pack was applied. Re-apply it so the dexopt job and checks run again.", 11f, cWarn), 6)
        }
        host.add(section("Items"))
        for (id in Pack.ids + "cached") { val t = TE.byId(id); val on = st[id] == true; val e = t.ents.firstOrNull()?.let { Mut.m.entry(if (it.kind == "dc") "dc|${it.ns}|${it.key}" else "s|${it.kind}|${it.key}") }
            host.card(6, 12) { add(row { add(tv(t.name, 14f, cText, "sans-serif-medium"), w = 0, weight = 1f); add(tv(if (on) "on" else if (Pack.userOff(id)) "off (you)" else "off", 12f, if (on) cGood else cDim), w = WRAP) })
                if (e != null) add(tv("was ${e.original}, now ${e.applied}${if (e.state != JState.APPLIED) " (${e.state})" else ""}", 10f, cDim), 2) else if (on) add(tv("on, but not set by Lunar (nothing to restore)", 10f, cDim), 2) } }
        host.add(section("Experimental, not in the Pack")); host.card(0, 12) { for (id in Pack.experimental) add(kv(TE.byId(id).name, if (st[id] == true) "on" else "off"), 3); add(tv("No measured benefit, so they are manual toggles on the Tweaks page.", 10f, cDim), 4) }
        val quiet = Mut.m.entries().filter { "pack" in it.owners && it.key.startsWith("bk|") }.size
        host.add(section("Background restrictions")); host.card(0, 12) { add(kv("Apps restricted by the Pack", "$quiet")); add(tv("Each is journaled and restored by Remove Pack.", 10f, cDim), 2) }
        host.add(section("Measured impact"))
        val base = ColdStart.parse(Store.getS("cs_base")); val last = ColdStart.parse(Store.getS("cs_last")); val names = Debloat.load(act).associate { it.id to it.label }
        host.card(0, 14) {
            if (last.isEmpty()) add(tv("No measurement yet. This force-stops 4 of your recent apps and times their cold start 3 times each (about 40 seconds, the screen flips between apps).", 12f, cDim))
            else { for ((p, ms) in last) { val b = base[p]; add(kv(names[p] ?: p, if (b != null) "$b ms -> $ms ms (${if (ms <= b) "" else "+"}${ms - b})" else "$ms ms")) }
                add(tv("Cold starts vary by roughly 5 to 10% on their own. Treat smaller changes as noise.", 10f, cDim), 4) }
            if (result != null) add(tv(result, 11f, cWarn), 4)
            add(btn("Measure now", true) { if (!Sh.granted()) { toast("Shizuku isn't authorized"); return@btn }; if (busy) return@btn; busy = true
                val s = tv("Starting…", 14f, cText); host.removeAllViews(); host.card(4, 16) { add(tv("Measuring cold starts", 16f, cText, "sans-serif-medium")); add(s, 8) }
                act.bg { val m = try { ColdStart.measure(act) { t -> act.ui { s.text = t } } } catch (e: Throwable) { emptyMap() }
                    if (m.isNotEmpty()) Store.putS("cs_last", m.entries.joinToString(",") { "${it.key}=${it.value}" }); act.ui { busy = false; render(st, if (m.isEmpty()) "Measurement failed: no app launched cleanly." else null) } } }, 10)
            if (last.isNotEmpty()) add(btn("Save latest as baseline") { Store.putS("cs_base", Store.getS("cs_last") ?: ""); render(st, null) }.compact(), 8, WRAP)
        }
    }
}
