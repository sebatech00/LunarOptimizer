package com.lunaroptimizer.app

import android.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import java.util.Locale

class TweaksPage(a: MainActivity) : Page(a) {
    private var states: Map<String, Boolean> = emptyMap()
    private val sw = HashMap<String, Switch>(); private var painting = false
    private lateinit var active: TextView; private lateinit var link: LinearLayout
    private fun need(): Boolean { if (Sh.granted()) return true; if (Sh.running()) Sh.request() else act.toast("Connect Shizuku first"); return false }

    override fun build(): View = with(act) {
        scaffold("Tweaks") {
            card(4, 16) { link = this }; fillLink(act, link)
            navCard("Benchmark mode", "AnTuTu and Geekbench: quiet the background, 120 Hz window, score log. Survives reboot", "NEW") { push(BenchPage(act)) }
            navCard("Lunar Pack report", "What the Pack changed, and measured cold-start times", null) { push(PackPage(act)) }
            navCard("Automatic mode", "Scans this phone and recommends changes from measured evidence. Reviewable and undoable", "NEW") { push(AutoPage(act)) }
            card(12, 16, true) {
                add(tv("Lunar Pack", 17f, cText, "sans-serif-semibold"))
                add(tv("Ads and telemetry, battery, smoothness, camera lag", 12f, cDim), 2)
                add(row { add(btn("Apply pack", true) { applyPack() }.compact(), w = 0, weight = 1.4f); add(btn("Remove") { removePack() }.compact(), w = 0, weight = 1f, start = 8) }, 12)
                add(toggle("Keep applied", "Re-applies it after reboots", Store.packAuto) { Store.packAuto = it })
            }
            card(12, 14) {
                active = tv("Profile: —", 13f, cIce, "sans-serif-medium"); add(active)
                add(row { for ((i, n) in listOf("Performance", "Balanced", "Battery").withIndex()) add(btn(n, i == 0) { profile(n) }.compact(), w = 0, weight = 1f, start = if (i == 0) 0 else 8) }, 10)
            }
            for (g in listOf("Smoothness", "Memory", "Battery", "Network")) {
                add(section(g))
                card(0, 14) {
                    for ((k, t) in TE.all.filter { it.group == g }.withIndex()) {
                        if (k > 0) add(View(act).apply { setBackgroundColor(0x1AFFFFFF) }, 0, MATCH, 1)
                        add(row {
                            setPadding(0, dp(11), 0, dp(11))
                            add(col { add(tv(t.name, 14f, cText, "sans-serif-medium")); add(tv(t.desc + (if (t.note.isNotEmpty()) " · ${t.note}" else ""), 11f, cDim), 2) }, w = 0, weight = 1f)
                            val s = glassSwitch().apply { setOnCheckedChangeListener { _, b -> if (!painting) toggleTo(t, b) } }
                            sw[t.id] = s; add(s, w = WRAP, start = 12)
                        })
                    }
                }
            }
            add(section("Maintenance"))
            card(0, 14) {
                val acts = listOf<Pair<String, () -> Unit>>(
                    "Trim caches" to { act1("Trim caches") { val s0 = Sys.storage(act).second; Sh.exec("pm trim-caches 999g", true, 120000); val s1 = Sys.storage(act).second; "Free storage: ${Sys.fmt(s0)} → ${Sys.fmt(s1)} (${if (s1 >= s0) "+" else ""}${Sys.fmt(s1 - s0)})" } },
                    "Audio" to { push(AudioPage(act)) },
                    "Optimize preview" to { push(OptimizePage(act, 3)) },
                    "TRIM + upkeep" to { act1("Idle maintenance") { val r = Sh.bgJob("sm idle-maint run; cmd package bg-dexopt-job"); "Started in the background. ${r.text().take(60)}" } },
                    "Deep dexopt" to { act1("Deep dexopt") { val r = Sh.bgJob("cmd package compile -m speed-profile -a > /data/local/tmp/lunar_dexopt.log 2>&1"); "Compiling all apps in the background (minutes). Check with Dexopt status. ${r.text().take(60)}" } },
                    "Dexopt status" to { act1("Dexopt status") { val d = Boost.dexStats(); (if (d.isEmpty()) "No data" else d.entries.sortedByDescending { it.value }.joinToString("\n") { "${it.key}: ${it.value}" }) + "\n\n" + Sh.exec("tail -n 3 /data/local/tmp/lunar_dexopt.log 2>/dev/null", false).out.trim() } },
                    "Compile my apps" to { compileApps("speed-profile") },
                    "Compile apps (max)" to { compileApps("speed") },
                    "Clear launcher cache" to { act1("Launcher cache") { val x = Sh.exec("pm clear --cache-only com.miui.home"); "Cache only, data untouched: ${x.text().ifEmpty { "exit ${x.code}" }}" } },
                    "Reset compile" to { act1("Reset compile") { val r = Sh.bgJob("cmd package compile --reset -a"); "Reset started in the background. ${r.text().take(60)}" } },
                    "App power" to { push(AppPowerPage(act)) },
                    "Deep clean RAM" to { push(DeepCleanPage(act)) },
                    "Camera" to { push(CameraPage(act)) },
                    "Console" to { push(ConsolePage(act)) }
                )
                for (i in acts.indices step 2) add(row {
                    add(btn(acts[i].first) { acts[i].second() }.compact(), w = 0, weight = 1f)
                    if (i + 1 < acts.size) add(btn(acts[i + 1].first) { acts[i + 1].second() }.compact(), w = 0, weight = 1f, start = 8) else add(View(act), w = 0, weight = 1f, start = 8)
                }, if (i == 0) 0 else 8)
            }
        }
    }
    override fun onShow() { if (::link.isInitialized) fillLink(act, link); refreshStates() }

    private fun applyPack() {
        if (!need()) return
        act.dialog("Apply Lunar Pack", "Stop background scans · Adaptive Battery · auto-restrict rare apps · ad and tracker DNS (AdGuard) · keep 48 apps cached only if it raises the current limit · restrict Xiaomi ad, telemetry and updater services · restrict unused apps that are busy in the background · system dexopt job after updates. Every change is read back and can be removed", "Apply", "Cancel") {
            act.toast("Applying…")
            act.bg { val ls = Pack.apply(act); val s = TE.states(); act.ui { states = s; paint(); act.dialog("Lunar Pack", ls.joinToString("\n")) } }
        }
    }
    private fun removePack() {
        if (!need()) return
        act.bg { val ls = Pack.remove(act); val s = TE.states(); act.ui { states = s; paint(); act.dialog("Lunar Pack removed", ls.joinToString("\n").ifEmpty { "Nothing to remove" }) } }
    }
    private fun act1(title: String, f: () -> String) {
        if (!need()) return
        act.toast("$title…")
        act.bg { val r = try { f() } catch (e: Throwable) { "Failed: ${e.message}" }; Store.log("action", title, r.replace('\n', ' ')); act.ui { act.dialog(title, r) } }
    }
    private fun refreshStates() {
        if (!Sh.granted()) { paint(); return }
        act.bg { val s = TE.states(); act.ui { states = s; paint() } }
    }
    private fun paint() {
        painting = true
        for (t in TE.all) sw[t.id]?.apply { isChecked = states[t.id] == true; isEnabled = Sh.granted() }
        painting = false
        val s = states
        active.text = "Profile: " + when {
            !Sh.granted() -> "—"
            s["hz120"] == true && s["phantom"] == true && s["cached"] == true -> "Performance"
            s["saver"] == true && s["hz60"] == true -> "Battery"
            TE.all.none { s[it.id] == true } -> "Balanced"
            else -> "Custom"
        }
    }
    private fun toggleTo(t: Tw, on: Boolean) {
        if (!need()) { paint(); return }
        act.bg {
            val (ok, ls) = if (on) TE.apply(t) else TE.revert(t); Pack.setUserOff(t.id, !on); val s = TE.states()
            act.ui { states = s; paint(); act.toast(t.name + (if (on) " on" else " off") + (if (ok) " · verified" else " · not verified, see Console") + "\n" + ls.firstOrNull().orEmpty()) }
        }
    }
    private fun profile(n: String) {
        if (!need()) return
        val onIds = when (n) {
            "Performance" -> listOf("blur", "hz120", "phantom", "cached", "compact", "longpress")
            "Battery" -> listOf("saver", "saver20", "hz60", "scans", "blur", "adaptive", "autorestrict", "mdalways", "timeout30")
            else -> emptyList()
        }
        act.toast("Applying $n…")
        act.bg {
            val m = Mut.m; var bad = 0; var n2 = 0
            // phase 1: leave what is not part of this profile
            val cur0 = TE.states()
            for (t in TE.all) if (t.id !in onIds && cur0[t.id] == true) { if (!TE.revert(t).first) bad++; n2++; Pack.setUserOff(t.id, true) }
            // phase 2: re-read the live state, then apply what is still missing. Settings of all tweaks go in ONE transaction (overlapping keys such as peak/min refresh rate share an owner list).
            val cur = TE.states(); val todo = onIds.filter { cur[it] != true }.map { TE.byId(it) }
            val setOps = todo.flatMap { t -> t.ents.filter { it.kind != "dc" }.map { e -> Triple(SettingT(e.kind, e.key) as Target, e.on, t.id) } }
            val tx = if (setOps.isEmpty()) null else m.transaction(setOps)
            if (tx != null && !tx.ok) { bad += todo.size; Store.log("profile", n, "settings transaction rolled back (${tx.rolledBack} undone): " + tx.outs.last().detail) }
            else for (t in todo) { Pack.setUserOff(t.id, false); n2++; for (e in t.ents.filter { it.kind == "dc" }) if (!m.changeDc(DcT(e.ns, e.key), e.on, t.id).ok) bad++ }
            val s = TE.states(); Store.log("profile", n, "$n2 changes, $bad not verified")
            act.ui { states = s; paint(); act.toast("$n: $n2 changes" + if (bad > 0) ", $bad not verified, nothing half-applied for settings" else ", all verified") }
        }
    }
    private fun compileApps(mode: String) {
        if (!need()) return
        act.push(ConsolePage(act))
        act.bg {
            val apps = Debloat.load(act).filter { it.cat == Cat.USER && it.installed }; Con.add("Compiling ${apps.size} user apps ($mode)…"); var ok = 0
            for ((i, p) in apps.withIndex()) { val r = Sh.exec("cmd package compile -m $mode -f ${p.id}", false, 180000); val g = r.out.contains("Success"); if (g) ok++; Con.add("[${i + 1}/${apps.size}] ${p.label}: ${if (g) "compiled" else "failed"}") }
            Store.addL("compiled", ok.toLong()); Con.add("Done: $ok/${apps.size} compiled"); Store.log("action", "Compile user apps", "$ok/${apps.size} compiled with $mode")
        }
    }
}

class AppPowerPage(a: MainActivity) : Page(a) {
    private var all: List<Pkg> = emptyList(); private var shown: List<Pkg> = emptyList(); private var q = ""
    private lateinit var list: ListView
    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View = act.col { setPadding(act.dp(2), act.dp(10), act.dp(2), act.dp(10)); add(act.tv(shown[i].label, 14f, cText, "sans-serif-medium")); add(act.tv(shown[i].id, 11f, cDim), 1) }
    }
    override fun build(): View = with(act) {
        scaffold("App power control", "Standby bucket + background permission per app", scroll = false) {
            val s = EditText(context).apply {
                hint = "Search apps"; setHintTextColor(cDim); setTextColor(cText); textSize = 14f; setSingleLine(true); setPadding(dp(14), dp(10), dp(14), dp(10)); cardBg(14)
                addTextChangedListener(object : TextWatcher { override fun afterTextChanged(e: Editable?) { q = e.toString().trim().lowercase(); filter() }; override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}; override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {} })
            }
            add(s, 4)
            add(tv("Restricted bucket + background deny stops an app from running in the background (notifications may be delayed). Tap an app.", 11f, cDim), 8)
            list = ListView(context).apply { divider = null; setSelector(android.R.color.transparent); adapter = this@AppPowerPage.adapter; isVerticalScrollBarEnabled = false; setOnItemClickListener { _, _, i, _ -> pick(shown[i]) } }
            add(list, 6, MATCH, 0, 1f)
            bg { val l = Debloat.load(act).filter { it.cat == Cat.USER && it.installed }; ui { all = l; filter() } }
        }
    }
    private fun filter() { shown = all.filter { q.isEmpty() || it.label.lowercase().contains(q) || it.id.lowercase().contains(q) }; adapter.notifyDataSetChanged() }
    private fun pick(p: Pkg) {
        if (!Sh.granted()) { act.toast("Connect Shizuku first"); return }
        val items = arrayOf("Bucket: active", "Bucket: working set", "Bucket: frequent", "Bucket: rare", "Bucket: restricted", "Deny background run", "Allow background run", "Show current state", "Keep alive (Doze whitelist + active)", "Undo keep alive", "Open HyperOS Autostart")
        AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(p.label).setItems(items) { _, w ->
            act.bg {
                val msg: String? = when (w) {
                    in 0..4 -> { val b = listOf("active", "working_set", "frequent", "rare", "restricted")[w]; Sh.exec("am set-standby-bucket ${p.id} $b"); val n = Sh.exec("am get-standby-bucket ${p.id}", false).out.trim(); Store.log("app-power", p.label, "bucket -> $b (read-back $n)"); "Requested $b. Read-back: ${bucketName(n)}" }
                    5, 6 -> { val m = if (w == 5) "deny" else "allow"; Sh.exec("cmd appops set ${p.id} RUN_ANY_IN_BACKGROUND $m"); val n = Sh.exec("cmd appops get ${p.id} RUN_ANY_IN_BACKGROUND", false).out.trim(); Store.log("app-power", p.label, "RUN_ANY_IN_BACKGROUND -> $m (read-back $n)"); "Read-back: $n" }
                    7 -> "Bucket: ${bucketName(Sh.exec("am get-standby-bucket ${p.id}", false).out.trim())}\n" + Sh.exec("cmd appops get ${p.id} RUN_ANY_IN_BACKGROUND", false).out.trim() + "\nDoze whitelist: " + Sh.exec("cmd deviceidle whitelist", false).out.contains(p.id)
                    8 -> { Sh.exec("cmd deviceidle whitelist +${p.id}"); Sh.exec("am set-standby-bucket ${p.id} active"); Sh.exec("cmd appops set ${p.id} RUN_ANY_IN_BACKGROUND allow")
                        val wl = Sh.exec("cmd deviceidle whitelist", false).out.contains(p.id); val bk = bucketName(Sh.exec("am get-standby-bucket ${p.id}", false).out.trim()); val ap = Sh.exec("cmd appops get ${p.id} RUN_ANY_IN_BACKGROUND", false).out.trim()
                        Store.log("app-power", p.label, "keep alive: whitelist=$wl bucket=$bk $ap"); "Doze whitelist: $wl\nBucket: $bk\n$ap\n\nAlso allow Autostart in HyperOS if notifications still stop." }
                    9 -> { Sh.exec("cmd deviceidle whitelist -${p.id}"); Sh.exec("am set-standby-bucket ${p.id} working_set"); Sh.exec("cmd appops set ${p.id} RUN_ANY_IN_BACKGROUND default"); Store.log("app-power", p.label, "keep alive removed"); "Keep alive removed (whitelist: ${Sh.exec("cmd deviceidle whitelist", false).out.contains(p.id)})" }
                    else -> { act.ui { if (!act.open(android.content.Intent().setClassName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))) act.toast("Autostart page not available on this build") }; null }
                }
                if (msg != null) act.ui { act.dialog(p.label, msg) }
            }
        }.show()
    }
    private fun bucketName(n: String) = when (n.trim().toIntOrNull()) { 5 -> "exempted"; 10 -> "active"; 20 -> "working set"; 30 -> "frequent"; 40 -> "rare"; 45 -> "restricted"; 50 -> "never"; else -> n }
}
