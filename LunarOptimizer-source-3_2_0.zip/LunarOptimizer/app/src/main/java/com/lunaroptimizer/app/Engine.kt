package com.lunaroptimizer.app

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import java.util.Locale

class Cancelled : Exception()
class Metrics(val ramAvail: Long, val ramTotal: Long, val psiMem: Float?, val psiCpu: Float?, val psiIo: Float?, val cpuLoad: Float?, val temps: Map<String, Float>,
              val battC: Float, val thermal: Int?, val storFree: Long, val procs: Int, val cached: Int, val hz: Float, val compiled: Int, val dexTotal: Int, val writeMBs: Float?, val swapUsed: Long, val tele: Int)
class BgApp(val pkg: String, val label: String, val rssMb: Int, val bucket: Int)
class Diag(val rows: List<Pair<String, String>>, val settings: Map<String, String>, val cachedLimit: Int?, val phantomLimit: Int?, val freezer: String?, val compaction: String?,
           val capped: List<String>, val modes: List<Float>, val cameras: List<String>, val cacheBytes: Long, val bgApps: List<BgApp>, val uncompiled: List<String>, val camBucket: Int?, val base: Metrics, val doze: Map<String, String>, val sysDex: Map<String, String>, val xbg: List<String>)

enum class St { APPLIED, NOCHANGE, FAILED }
class OptRes(val st: St, val detail: String)
class Run(val a: MainActivity) { @Volatile var onStep: ((Int, Int) -> Unit)? = null; val appops = ArrayList<String>(); val tw = ArrayList<String>(); val buckets = ArrayList<Pair<String, String>>(); @Volatile var cancelled = false }
class Opt(val id: String, val area: String, val title: String, val why: String, val effect: String, val risk: String, val conf: String, val confirm: Boolean, var selected: Boolean,
          val run: (Run) -> OptRes, val gain: ((Metrics, Metrics) -> String?)? = null)
object Net {
    val HOSTS = listOf("tracking.intl.miui.com", "data.mistat.intl.xiaomi.com", "sdkconfig.ad.intl.xiaomi.com", "api.ad.intl.xiaomi.com", "adv.sec.miui.com", "globalapi.ad.xiaomi.com")
    /** Number of known Xiaomi tracker hosts that do not resolve; -1 when the network/DNS itself isn't working. */
    fun blocked(): Int {
        try { java.net.InetAddress.getByName("example.com") } catch (e: Exception) { return -1 }
        val res = IntArray(HOSTS.size)
        val ts = HOSTS.mapIndexed { i, h -> Thread { res[i] = try { val a = java.net.InetAddress.getByName(h); if (a.isAnyLocalAddress || a.isLoopbackAddress) 1 else 0 } catch (e: java.net.UnknownHostException) { 1 } catch (e: Exception) { 0 } }.also { it.start() } }
        ts.forEach { it.join(4000) }
        return res.sum()
    }
}
class Finding(val text: String, val conf: String, val src: String)

object Engine {
    fun f1(v: Float?) = if (v == null) "n/a" else String.format(Locale.US, "%.1f", v)
    fun bucketName(n: Int?) = when (n) { null -> "unknown"; 5 -> "exempted"; 10 -> "active"; 20 -> "working set"; 30 -> "frequent"; 40 -> "rare"; 45 -> "restricted"; 50 -> "never"; else -> "$n" }
    fun bucketOf(pkg: String): Int? = Sh.exec("am get-standby-bucket $pkg", false).out.trim().toIntOrNull()
    fun hz(a: MainActivity): Float = try { a.display?.refreshRate ?: 0f } catch (e: Throwable) { 0f }
    val DONE = setOf("speed-profile", "speed", "everything", "space-profile", "space")

    fun durMs(s: String?): Long? {
        if (s == null) return null; s.trim().toLongOrNull()?.let { return it }
        val m = Regex("^\\+?(?:(\\d+)d)?(?:(\\d+)h)?(?:(\\d+)m(?!s))?(?:(\\d+)s)?(?:(\\d+)ms)?$").find(s.trim()) ?: return null
        fun g(i: Int) = m.groupValues[i].toLongOrNull() ?: 0L
        return g(1) * 86400000 + g(2) * 3600000 + g(3) * 60000 + g(4) * 1000 + g(5)
    }
    val XB = listOf("com.miui.analytics", "com.miui.msa.global", "com.miui.systemAdSolution", "com.miui.bugreport", "com.miui.miservice", "com.miui.hybrid", "com.miui.hybrid.accessory")

    /** Restricts one package's background activity as ONE transaction through the journal (appops + standby bucket). All-or-nothing, verified by read-back. */
    fun quietOne(pkg: String, owner: String): Tx {
        val ops = ArrayList<Triple<Target, String, String>>()
        ops.add(Triple(OpT(pkg, "RUN_ANY_IN_BACKGROUND"), "deny", owner)); ops.add(Triple(OpT(pkg, "RUN_IN_BACKGROUND"), "deny", owner))
        if (pkg == "com.miui.msa.global") ops.add(Triple(OpT(pkg, "POST_NOTIFICATION"), "deny", owner))
        ops.add(Triple(BucketT(pkg), "45", owner))
        return Mut.m.transaction(ops)
    }
    /** Restricts background activity of packages (appops + standby bucket); returns how many were verified. Nothing is removed. */
    fun quiet(pkgs: List<String>, r: Run?, owner: String = "quiet"): Int {
        var ok = 0
        for ((qi, pkg) in pkgs.withIndex()) {
            if (r?.cancelled == true) break; r?.onStep?.invoke(qi + 1, pkgs.size)
            val t = quietOne(pkg, owner)
            if (t.ok) { ok++; r?.appops?.add(pkg); r?.buckets?.add(pkg to "") }
        }
        return ok
    }
    fun dex(): Pair<Map<String, Int>, Map<String, String>> {
        val o = Sh.exec("dumpsys package dexopt", false, 60000).out
        val stats = HashMap<String, Int>(); val per = LinkedHashMap<String, String>(); var cur: String? = null
        val pk = Regex("^\\[([A-Za-z0-9._]+)\\]$"); val st = Regex("\\[status=([a-z-]+)\\]")
        for (l in o.lines()) {
            val t = l.trim(); val m = pk.find(t); if (m != null) { cur = m.groupValues[1]; continue }
            val s = st.find(t); if (s != null) { val k = s.groupValues[1]; stats[k] = (stats[k] ?: 0) + 1; val c = cur; if (c != null && !per.containsKey(c)) per[c] = k }
        }
        return stats to per
    }

    fun measure(a: MainActivity, io: Boolean = true): Metrics {
        Tele.read(); Thread.sleep(1300); val snap = Tele.read()
        val o = Sh.exec("echo @M; cat /proc/pressure/memory 2>/dev/null; echo @C; cat /proc/pressure/cpu 2>/dev/null; echo @I; cat /proc/pressure/io 2>/dev/null; echo @P; ps -A | wc -l; echo @K; dumpsys activity processes | grep -cE 'Proc # *[0-9]+: cch'", false, 40000).out
        val sec = HashMap<String, StringBuilder>(); var k = ""
        for (l in o.lines()) { if (l.startsWith("@")) { k = l.substring(1).trim(); sec[k] = StringBuilder() } else sec[k]?.append(l)?.append('\n') }
        fun psi(key: String) = Regex("some avg10=([0-9.]+)").find(sec[key]?.toString() ?: "")?.groupValues?.get(1)?.toFloatOrNull()
        val cs = dex().first
        val mem = Sys.memory(a); val (_, free) = Sys.storage(a); val b = Sys.battery(a)
        var mbs: Float? = null
        if (io) { val t = System.nanoTime(); val r = Sh.exec("dd if=/dev/zero of=/data/local/tmp/lunar_io bs=1M count=64 conv=fsync 2>/dev/null; rm -f /data/local/tmp/lunar_io", false, 30000); val ms = (System.nanoTime() - t) / 1e6f; if (r.ok && ms > 0) mbs = 64000f / ms }
        val sw = Sys.swap()
        return Metrics(mem.avail, mem.total, psi("M"), psi("C"), psi("I"), snap?.cpu, snap?.temps ?: emptyMap(), b.tempC, b.thermal, free, sec["P"]?.toString()?.trim()?.toIntOrNull() ?: -1,
            sec["K"]?.toString()?.trim()?.toIntOrNull() ?: -1, hz(a), (cs["speed-profile"] ?: 0) + (cs["speed"] ?: 0) + (cs["everything"] ?: 0), cs.values.sum(), mbs, if (sw != null) sw.first - sw.second else 0L, Net.blocked())
    }

    private fun cameraReport(a: MainActivity): List<String> = try {
        val cm = a.getSystemService(android.content.Context.CAMERA_SERVICE) as CameraManager
        cm.cameraIdList.mapNotNull { id ->
            try {
                val ch = cm.getCameraCharacteristics(id)
                val face = when (ch.get(CameraCharacteristics.LENS_FACING)) { CameraCharacteristics.LENS_FACING_BACK -> "back"; CameraCharacteristics.LENS_FACING_FRONT -> "front"; else -> "ext" }
                val sz = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE); val mp = if (sz != null) String.format(Locale.US, "%.0f MP", sz.width * sz.height / 1e6) else "?"
                val ois = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.any { it == 1 } == true
                val fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
                val lvl = when (ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) { 0 -> "LIMITED"; 1 -> "FULL"; 2 -> "LEGACY"; 3 -> "LEVEL_3"; 4 -> "EXTERNAL"; else -> "?" }
                "Camera $id · $face · $mp · $lvl" + (if (ois) " · OIS" else "") + (if (fl != null) " · ${String.format(Locale.US, "%.1f", fl)} mm" else "")
            } catch (e: Throwable) { null }
        }
    } catch (e: Throwable) { emptyList() }

    fun diagnose(a: MainActivity, cancel: () -> Boolean, prog: (Int, String) -> Unit): Diag {
        val rows = ArrayList<Pair<String, String>>()
        fun step(p: Int, t: String) { if (cancel()) throw Cancelled(); prog(p, t) }
        step(2, "Device and firmware")
        val pr = Sh.exec("getprop ro.soc.manufacturer; getprop ro.soc.model; getprop ro.board.platform; getprop ro.build.fingerprint; getprop ro.build.version.security_patch; uname -r; getprop ro.boot.verifiedbootstate; getprop ro.boot.flash.locked", false).out.lines()
        fun pl(i: Int) = pr.getOrNull(i)?.trim().orEmpty().ifEmpty { "n/a" }
        rows.add("Device" to "${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})"); rows.add("SoC" to "${pl(0)} ${pl(1)} · ${pl(2)}")
        rows.add("Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"); rows.add("HyperOS" to Sys.hyperOs())
        rows.add("Fingerprint" to pl(3)); rows.add("Security patch" to pl(4)); rows.add("Kernel" to pl(5))
        rows.add("Bootloader" to if (pl(7) == "1" || pl(6) == "green") "Locked (verified boot ${pl(6)})" else "Verified boot ${pl(6)}")
        step(6, "CPU")
        val capped = ArrayList<String>()
        Sh.exec("for p in /sys/devices/system/cpu/cpufreq/policy*; do echo \"\$(basename \$p) \$(cat \$p/related_cpus) \$(cat \$p/cpuinfo_max_freq) \$(cat \$p/scaling_max_freq) \$(cat \$p/scaling_cur_freq) \$(cat \$p/scaling_governor)\"; done 2>/dev/null", false).out.lines().forEach { l ->
            val t = l.trim().split(Regex("\\s+")); if (t.size < 5) return@forEach
            var i = 1; val cpus = ArrayList<String>(); while (i < t.size && (t[i].toIntOrNull() ?: 999999) < 64) { cpus.add(t[i]); i++ }
            val mx = t.getOrNull(i)?.toLongOrNull(); val sm = t.getOrNull(i + 1)?.toLongOrNull(); val gov = t.getOrNull(i + 4) ?: "?"
            if (mx != null && sm != null) { if (sm < mx * 0.98) capped.add(t[0]); rows.add("CPU ${t[0]}" to "cpu${cpus.firstOrNull()}-${cpus.lastOrNull()} · max ${mx / 1000} MHz · limit ${sm / 1000} MHz · $gov") }
        }
        step(9, "GPU")
        val gl = Sh.exec("dumpsys SurfaceFlinger | grep -m1 GLES", false).out.trim(); if (gl.isNotEmpty()) rows.add("GPU" to gl.substringAfter("GLES:").trim().take(60))
        Sh.exec("cat /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null; cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null", false).out.lines().filter { it.isNotBlank() }.let { if (it.size >= 2) rows.add("GPU clock" to "${(it[1].trim().toLongOrNull() ?: 0) / 1_000_000} MHz of ${(it[0].trim().toLongOrNull() ?: 0) / 1_000_000} MHz max") }
        step(12, "Memory and storage")
        val mem = Sys.memory(a); val (tot, free) = Sys.storage(a)
        rows.add("RAM" to "${Sys.fmt(mem.avail, 1024)} available of ${Sys.fmt(mem.total, 1024)}"); Sys.swap()?.let { if (it.first > 0) rows.add("Swap" to "${Sys.fmt(it.first - it.second, 1024)} used of ${Sys.fmt(it.first, 1024)}") }
        rows.add("Storage" to "${Sys.fmt(free)} free of ${Sys.fmt(tot)}")
        step(14, "Battery")
        val bt = Sh.exec("for f in charge_full charge_full_design cycle_count; do v=\$(cat /sys/class/power_supply/battery/\$f 2>/dev/null); [ -n \"\$v\" ] && echo \"\$f=\$v\"; done", false).out.lines().filter { it.contains('=') }.associate { it.substringBefore('=') to it.substringAfter('=').trim() }
        val full = bt["charge_full"]?.toLongOrNull(); val des = bt["charge_full_design"]?.toLongOrNull()
        if (full != null && des != null && des > 0) rows.add("Battery capacity" to String.format(Locale.US, "%.1f%% of design (%d / %d mAh)", 100.0 * full / des, full / 1000, des / 1000)) else rows.add("Battery capacity" to "Not exposed")
        bt["cycle_count"]?.let { rows.add("Battery cycles" to it) }
        step(16, "Display")
        val modes = try { a.display?.supportedModes?.map { Math.round(it.refreshRate).toFloat() }?.distinct()?.sorted() ?: emptyList() } catch (e: Throwable) { emptyList() }
        rows.add("Display" to "now ${f1(hz(a))} Hz · modes ${modes.joinToString("/") { it.toInt().toString() }} Hz")
        step(18, "Settings and power management")
        val set = TE.snapshot()
        rows.add("Refresh settings" to "peak ${set["system.peak_refresh_rate"] ?: "unset"} · min ${set["system.min_refresh_rate"] ?: "unset"}")
        rows.add("Animation scales" to "${set["global.window_animation_scale"] ?: "1"} / ${set["global.transition_animation_scale"] ?: "1"} / ${set["global.animator_duration_scale"] ?: "1"}")
        rows.add("Battery Saver" to if (set["global.low_power"] == "1") "On" else "Off"); rows.add("Adaptive Battery" to (set["global.adaptive_battery_management_enabled"] ?: "default"))
        val act = HashMap<String, String>(); Sh.exec("dumpsys activity settings | grep -E 'max_cached_processes|max_phantom_processes|use_freezer|use_compaction'", false).out.lines().forEach { l -> Regex("(\\w+)=(\\S+)").find(l.trim())?.let { act[it.groupValues[1]] = it.groupValues[2] } }
        val cl = act["max_cached_processes"]?.toIntOrNull(); val pl2 = act["max_phantom_processes"]?.toIntOrNull()
        rows.add("Process limits" to "cached ${cl ?: "default"} · phantom ${pl2 ?: "default"} · freezer ${act["use_freezer"] ?: "n/a"} · compaction ${act["use_compaction"] ?: "n/a"}")
        rows.add("Shizuku" to "${Sh.who()} · secure settings ${if (Sys.canWriteSecure(a)) "granted" else "not granted"}")
        step(20, "Background activity")
        val allPk = Debloat.load(a); val users = allPk.filter { it.cat == Cat.USER && it.installed && it.enabled }.associateBy { it.id }
        val rss = HashMap<String, Long>()
        Sh.exec("ps -A -o RSS,NAME", false, 30000).out.lines().drop(1).forEach { l -> val t = l.trim().split(Regex("\\s+"), 2); if (t.size == 2) { val kb = t[0].toLongOrNull(); val n = t[1].substringBefore(':'); if (kb != null && users.containsKey(n)) rss[n] = (rss[n] ?: 0L) + kb } }
        val accs = Sh.exec("settings get secure enabled_accessibility_services", false).out
        val top = rss.entries.filter { it.value >= 150_000 && it.key != a.packageName && !Planner.comms(it.key) && !it.key.startsWith("com.miui.") && !it.key.startsWith("com.xiaomi.") && !it.key.startsWith("com.google.android.") && !accs.contains(it.key) }.sortedByDescending { it.value }.take(8)
        val bg = top.mapNotNull { e -> val bk = bucketOf(e.key); if (bk != null && bk >= 45) null else BgApp(e.key, users[e.key]?.label ?: e.key, (e.value / 1024).toInt(), bk ?: 0) }
        rows.add("Heavy background apps" to if (bg.isEmpty()) "none (>150 MB, user apps)" else bg.take(3).joinToString { "${it.label} ${it.rssMb} MB" })
        val cache = Regex("App Cache Size:\\s*(\\d+)").find(Sh.exec("dumpsys diskstats | grep -i 'App Cache Size'", false, 40000).out)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        rows.add("App caches" to Sys.fmt(cache))
        step(22, "Dexopt state")
        val (ds, per) = dex(); val unc = per.filter { it.key in users && it.value !in DONE }.keys.toList()
        rows.add("Compiled apps" to "${(ds["speed-profile"] ?: 0) + (ds["speed"] ?: 0) + (ds["everything"] ?: 0)} of ${ds.values.sum()} · ${unc.size} user apps not compiled")
        val sysDex = listOf("com.miui.home", "com.android.systemui", "com.android.camera", "com.miui.gallery").associateWith { per[it] ?: "n/a" }
        rows.add("Launcher / SystemUI dexopt" to "${sysDex["com.miui.home"]} / ${sysDex["com.android.systemui"]}")
        val doze = HashMap<String, String>(); Sh.exec("dumpsys deviceidle | grep -E 'inactive_to=|light_after_inactive_to='", false).out.lines().forEach { l -> Regex("(\\w+)=(\\S+)").find(l.trim())?.let { doze[it.groupValues[1]] = it.groupValues[2] } }
        rows.add("Doze timers" to (doze.entries.joinToString(" · ") { "${it.key} ${it.value}" }.ifEmpty { "n/a" }))
        val xbg = XB.filter { id -> allPk.any { it.id == id && it.installed && it.enabled } }
        rows.add("Xiaomi ad/telemetry services" to if (xbg.isEmpty()) "none active" else "${xbg.size} active")
        step(23, "Camera")
        val cams = cameraReport(a); cams.forEach { rows.add("Camera" to it.removePrefix("Camera ")) }
        val camB = bucketOf("com.android.camera")
        step(24, "Baseline measurements")
        val base = measure(a)
        rows.add("CPU load" to "${f1(base.cpuLoad)}%"); rows.add("Memory pressure (PSI)" to (if (base.psiMem == null) "not exposed by this kernel" else "${f1(base.psiMem)}%")); rows.add("Cached processes" to "${base.cached} · total ${base.procs}")
        rows.add("Temperatures" to base.temps.entries.filter { it.key != "Batt" }.joinToString(" · ") { "${it.key} ${String.format(Locale.US, "%.0f", it.value)}°" }.ifEmpty { "n/a" } + " · Batt ${String.format(Locale.US, "%.1f", base.battC)}°")
        rows.add("Thermal status" to Sys.thermalText(base.thermal)); rows.add("Storage write (approx.)" to (base.writeMBs?.let { "${String.format(Locale.US, "%.0f", it)} MB/s" } ?: "n/a"))
        return Diag(rows, set, cl, pl2, act["use_freezer"], act["use_compaction"], capped, modes, cams, cache, bg, unc, camB, base, doze, sysDex, xbg)
    }
}

object Kb {
    private val all = listOf(
        Triple(Finding("High-RAM phones should not sit under memory pressure; lmkd acts when PSI 'some' stalls reach about 70 ms per second (~7%).", "Confirmed", "source.android.com lmkd"), { _: Diag -> true }, 0),
        Triple(Finding("Phantom-process killer (Android 12+): 32 child processes across all apps. Switch: settings_enable_monitor_phantom_procs; effective value is in 'dumpsys activity settings'.", "Confirmed", "Android internals docs"), { _: Diag -> Build.VERSION.SDK_INT >= 31 }, 1),
        Triple(Finding("Refresh rate: HyperOS offers Auto, 60 and 120 Hz. The Xiaomi 14 panel is LTPO (1-120 Hz), so Auto saves power. peak/min_refresh_rate are AOSP keys that HyperOS may ignore.", "Community + AOSP", "HyperOS guides, AOSP"), { d: Diag -> d.modes.any { it >= 119f } }, 2),
        Triple(Finding("Performance mode and Game Turbo are Xiaomi UI features with no documented shell control. A GSMArena throttling test on the 14 Ultra found Performance mode did not raise sustained peak.", "Review", "GSMArena"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 3),
        Triple(Finding("Xiaomi 14 sustained-load behaviour is reported as uneven by reviewers. Thermal protection is not modifiable without root and Lunar Optimizer never touches it.", "Review", "GSMArena, NextPit"), { _: Diag -> true }, 4),
        Triple(Finding("HyperOS 3 may revoke background execution unless Autostart is enabled. Restricting messaging apps further can delay notifications.", "Community", "HyperOS 3 device-testing reports"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 5),
        Triple(Finding("Camera: Leica looks, HDR and resolution live in the Camera app. Without root there is no supported system tweak that changes ISP processing.", "Confirmed", "Android platform boundary"), { _: Diag -> true }, 6),
        Triple(Finding("HyperOS 3 manages background apps more strictly than HyperOS 2; messaging and fitness apps may need manual whitelisting (Autostart and battery 'No restrictions'). Tweaks > App power > Keep alive uses supported Android mechanisms.", "Community", "HyperOS 3 user reports"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 8),
        Triple(Finding("After a major update the system reindexes and recompiles apps in the background; battery drain and heat usually settle within 48 hours. Avoid repeated cache clearing meanwhile.", "Community", "HyperOS 3 user reports"), { _: Diag -> true }, 9),
        Triple(Finding("Launcher stutter after the update is commonly cured by clearing the launcher cache (not data) and compiling it.", "Community", "HyperOS 3 user reports"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 10),
        Triple(Finding("Memory extension (swap on storage) is reported to add lag and battery use. On 12 GB it is optional: try it off in Settings > Additional settings.", "Community", "r/HyperOS reports"), { d: Diag -> d.base.ramTotal > 8_000_000_000L }, 11),
        Triple(Finding("Removing Xiaomi game services (Joyose, Game Service, Game Center SDK) is reported to reduce gaming performance. They are rated high risk here.", "Community", "HyperOS debloat guides"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 12),
        Triple(Finding("On newer HyperOS builds 'pm disable-user' on system apps can fail with SecurityException; 'pm uninstall -k --user 0' still works and is restorable.", "Community", "HyperOS debloat tools"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 13),
        Triple(Finding("Xiaomi ads and telemetry run through MSA and analytics services. Official switches live in Settings > Privacy (Ad services, User Experience Program) and Authorization & revocation. Lunar Optimizer restricts their background activity and can block tracker domains via Private DNS; it can't flip Xiaomi's in-app switches.", "Community", "HyperOS ad-removal guides"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 14),
        Triple(Finding("Xiaomi's FAQ: the camera can lag while GetApps installs or updates apps in batches in the background, because the store gets system resources first.", "Confirmed", "Xiaomi support FAQ"), { _: Diag -> Build.MANUFACTURER.equals("xiaomi", true) }, 15),
        Triple(Finding("pm trim-caches removes caches only. TRIM and idle maintenance are supported system jobs; their benefit is not immediate.", "Confirmed", "AOSP shell commands"), { _: Diag -> true }, 7)
    )
    fun match(d: Diag): List<Finding> = all.filter { it.second(d) }.map { it.first }
}

object Planner {
    private val COMMS = listOf("com.whatsapp", "org.telegram", "org.thoughtcrime.securesms", "com.discord", "com.facebook.orca", "com.facebook.katana", "com.google.android.gm", "com.google.android.apps.messaging", "com.android.mms",
        "com.Slack", "com.microsoft.teams", "com.viber", "jp.naver.line", "com.skype", "ch.threema", "im.vector", "com.snapchat.android", "com.instagram.android", "com.google.android.apps.tachyon", "com.microsoft.office.outlook")
    fun comms(p: String) = COMMS.any { p == it || p.startsWith("$it.") }
    private fun tw(r: Run, id: String, extra: () -> String = { "" }): OptRes {
        val (ok, ls) = TE.apply(TE.byId(id)); if (ok) r.tw.add(id)
        val x = if (ok) extra() else ""
        return OptRes(if (ok) St.APPLIED else St.FAILED, ls.joinToString("; ") + (if (x.isNotEmpty()) "; $x" else ""))
    }
    fun build(a: MainActivity, d: Diag): Pair<List<Opt>, List<Pair<String, String>>> {
        val o = ArrayList<Opt>(); val sk = ArrayList<Pair<String, String>>(); val b = d.base; val s = d.settings
        fun skip(t: String, why: String) { sk.add(t to why) }
        // RAM
        val ratio = b.ramAvail.toFloat() / b.ramTotal
        if ((b.psiMem ?: 0f) >= 7f || ratio < 0.10f)
            o.add(Opt("killcached", "RAM", "Free cached background apps", "Memory pressure: PSI ${Engine.f1(b.psiMem)}%, ${Sys.fmt(b.ramAvail, 1024)} available", "Drops cached (not foreground) processes", "Cached apps relaunch cold", "Confirmed", false, true,
                { r -> OptRes(St.NOCHANGE, "blanket process killing was removed; use Deep clean, which only stops measured offenders") },
                { x, y -> if (y.ramAvail - x.ramAvail > 100_000_000L) "Available RAM +${Sys.fmt(y.ramAvail - x.ramAvail, 1024)}" else null }))
        else skip("Free cached background apps", "No memory pressure (PSI ${Engine.f1(b.psiMem)}%, ${Sys.fmt(b.ramAvail, 1024)} available). It would only force relaunches.")
        val lim = d.cachedLimit ?: 32
        if (b.cached >= lim * 0.85 && (s["activity_manager.max_cached_processes"] ?: "null") != "48")
            o.add(Opt("cached48", "RAM", "Raise cached-process limit to 48", "${b.cached} cached processes against a limit of $lim", "More apps stay warm, fewer cold starts", "More RAM held by cached apps", "Confirmed (AOSP key)", false, true,
                { r -> tw(r, "cached") { "effective: " + Sh.exec("dumpsys activity settings | grep max_cached_processes", false).out.trim() } }))
        else skip("Raise cached-process limit", "Cached processes ${b.cached} are well below the limit of $lim.")
        if ((s["global.settings_enable_monitor_phantom_procs"] ?: "null") != "false" && Build.VERSION.SDK_INT >= 31)
            o.add(Opt("phantom", "RAM", "Disable phantom-process killer", "Limit is ${d.phantomLimit ?: 32} child processes for all apps combined", "Helper processes of games and emulators survive", "Slightly more background load", "Confirmed mechanism, situational benefit", false, false,
                { r -> tw(r, "phantom") { "effective: " + Sh.exec("dumpsys activity settings | grep max_phantom_processes", false).out.trim() } }))
        else skip("Disable phantom-process killer", "Already disabled or not applicable.")
        if (d.compaction == "false") o.add(Opt("compact", "RAM", "Enable app memory compaction", "Compaction is reported off", "More free RAM from idle apps", "Small CPU cost", "Community, effect unverified", false, false, { r -> tw(r, "compact") }))
        else skip("App memory compaction", "State: ${d.compaction ?: "not exposed"}.")
        val bg = d.bgApps
        if (bg.isNotEmpty()) o.add(Opt("bgrestrict", "RAM", "Restrict ${bg.size} heavy background apps", bg.joinToString { "${it.label} ${it.rssMb} MB" }, "Standby bucket 'restricted' limits background work", "Notifications from these apps can be delayed", "Confirmed (standby buckets)", true, false,
            { r ->
                var ok = 0
                for ((bi, p) in bg.withIndex()) { if (r.cancelled) break; r.onStep?.invoke(bi + 1, bg.size); val o = Mut.m.change(BucketT(p.pkg), "45", "planner"); if (o.ok && o.changed) { ok++; r.buckets.add(p.pkg to o.before) } }
                OptRes(if (ok == bg.size) St.APPLIED else if (ok > 0) St.APPLIED else St.FAILED, "$ok of ${bg.size} restricted and verified by read-back")
            }))
        else skip("Restrict heavy background apps", "No user app above 150 MB in the background (messaging apps excluded).")
        // Battery
        if (s["global.wifi_scan_always_enabled"] == "1" || s["global.ble_scan_always_enabled"] == "1")
            o.add(Opt("scans", "Battery", "Stop background Wi-Fi/Bluetooth scans", "Always-on scanning is enabled", "Fewer idle wakeups", "Location accuracy may drop slightly", "Confirmed (AOSP keys)", false, true, { r -> tw(r, "scans") }))
        else skip("Stop background scans", "Already off.")
        if (s["global.adaptive_battery_management_enabled"] == "0") o.add(Opt("adaptive", "Battery", "Turn on Adaptive Battery", "Currently off", "Restricts apps you rarely open", "None", "Confirmed", false, true, { r -> tw(r, "adaptive") })) else skip("Adaptive Battery", "Already on or default.")
        if (s["global.app_auto_restriction_enabled"] == "false" || s["global.app_auto_restriction_enabled"] == "0") o.add(Opt("autorestrict", "Battery", "Auto-restrict rarely used apps", "Currently off", "Less drain from forgotten apps", "Delayed notifications from unused apps", "Confirmed", false, true, { r -> tw(r, "autorestrict") })) else skip("Auto-restrict rare apps", "Already on or default.")
        if (s["global.mobile_data_always_on"] == "1") o.add(Opt("mdalways", "Battery", "Mobile data off while on Wi-Fi", "Mobile data is kept up alongside Wi-Fi", "Less radio drain", "Slower Wi-Fi to mobile handover; affects connectivity", "Confirmed (AOSP key)", true, false, { r -> tw(r, "mdalways") })) else skip("Mobile data on Wi-Fi", "Already off.")
        val inact = Engine.durMs(d.doze["inactive_to"])
        if (inact != null && inact >= 600_000L && (s["global.device_idle_constants"] ?: "null") == "null")
            o.add(Opt("doze", "Battery", "Faster Doze (idle after 1 min)", "Doze waits ${inact / 60000} min of stillness before deep idle (inactive_to)", "Deep idle starts sooner when still and unplugged: fewer background wakeups", "Delays background sync for apps that aren't exempt", "AOSP key; HyperOS 3 may ignore it (checked via dumpsys)", true, false,
                { r ->
                    val x = tw(r, "doze"); Thread.sleep(600)
                    val now = Sh.exec("dumpsys deviceidle | grep -E 'inactive_to='", false).out.trim()
                    val adopted = (Engine.durMs(Regex("(?<![a-z_])inactive_to=(\\S+)").find(now)?.groupValues?.get(1)) ?: Long.MAX_VALUE) <= 120000L
                    if (x.st == St.APPLIED && !adopted) { TE.revert(TE.byId("doze")); r.tw.remove("doze"); OptRes(St.NOCHANGE, "Stored, but the system did not adopt it (dumpsys: ${now.take(60)}). Reverted.") } else OptRes(x.st, x.detail + "; dumpsys: ${now.take(60)}")
                }))
        else skip("Faster Doze", "Doze timer is ${d.doze["inactive_to"] ?: "unreadable"} or already customized.")
        if (d.xbg.isNotEmpty()) o.add(Opt("xibg", "RAM", "Quiet Xiaomi ad and telemetry services", d.xbg.joinToString { it.removePrefix("com.miui.") }, "Denies background run and sets the restricted bucket; nothing is removed", "Xiaomi ads, analytics and feedback stop running in the background", "Mechanism confirmed (appops, buckets); package choice community", false, true,
            { r -> val ok = Engine.quiet(d.xbg, r); OptRes(if (ok > 0) St.APPLIED else St.FAILED, "$ok of ${d.xbg.size} quieted and verified by read-back")             }))
        else skip("Quiet Xiaomi services", "None of the known ad/telemetry packages are active.")
        val sdx = listOf("com.miui.home", "com.android.systemui").filter { p -> d.sysDex[p]?.let { it != "n/a" && it !in Engine.DONE } == true }
        if (sdx.isNotEmpty()) o.add(Opt("sysdex", "Launch", "Compile launcher and System UI (speed)", sdx.joinToString { "${it.substringAfterLast('.')}: ${d.sysDex[it]}" }, "Ahead-of-time compiles the launcher and shade; community cure for launcher stutter", "Brief CPU use; Reset compile reverts", "ART confirmed; stutter fix community", false, true,
            { r -> var ok = 0; var si = 0; for (p in sdx) { si++; r.onStep?.invoke(si, sdx.size); if (Sh.exec("cmd package compile -m speed -f $p", false, 180000).out.contains("Success")) ok++ }; OptRes(if (ok > 0) St.APPLIED else St.FAILED, "$ok of ${sdx.size} compiled") },
            { x, y -> if (y.compiled > x.compiled) "Compiled apps ${x.compiled} to ${y.compiled}" else null }))
        else skip("Compile launcher and System UI", "Already compiled or state unknown.")
        // Privacy / camera
        val pdm = s["global.private_dns_mode"]
        if (pdm == null || pdm == "off" || pdm == "opportunistic" || pdm == "null")
            o.add(Opt("dnsad", "Privacy", "Block ads and trackers (DNS)", "Private DNS is ${pdm ?: "off"}; " + (if (b.tele >= 0) "${b.tele}/${Net.HOSTS.size} known Xiaomi tracker hosts blocked" else "tracker blocking not measurable offline"), "Ad and tracker domains, including Xiaomi telemetry hosts, stop resolving", "Apps with their own DNS bypass it; an unreachable DNS server would break lookups (auto-reverted)", "Private DNS documented; host list community", true, true,
                { r -> val x = tw(r, "dnsad"); if (x.st != St.APPLIED) x else { Thread.sleep(1500); val t = Net.blocked(); if (t < 0) { TE.revert(TE.byId("dnsad")); r.tw.remove("dnsad"); OptRes(St.FAILED, "DNS server unreachable; reverted") } else OptRes(St.APPLIED, x.detail + "; tracker hosts blocked $t/${Net.HOSTS.size}") } },
                { x, y -> if (x.tele >= 0 && y.tele > x.tele) "Tracker hosts blocked ${x.tele}/${Net.HOSTS.size} to ${y.tele}/${Net.HOSTS.size}" else null }))
        else skip("Block ads via DNS", "You already use Private DNS ($pdm).")
        val mp = "com.xiaomi.mipicks"
        if (Debloat.isInstalled(a, mp) && (try { a.packageManager.getApplicationEnabledSetting(mp) < 2 } catch (e: Exception) { false }) && (Engine.bucketOf(mp) ?: 0) < 45)
            o.add(Opt("mipicks", "Camera", "Pause GetApps background updates", "Xiaomi says the camera can lag while GetApps installs or updates apps in batches", "Restricts GetApps in the background so updates don't compete with the camera", "Xiaomi apps update when you open GetApps", "Official Xiaomi FAQ", false, true,
                { r -> val n = Engine.quiet(listOf(mp), r); OptRes(if (n > 0) St.APPLIED else St.FAILED, "$n of 1 restricted and verified") }))
        else skip("Pause GetApps background updates", "GetApps is absent, disabled or already restricted.")
        val camp = listOf("com.android.camera", "com.miui.gallery").filter { p -> d.sysDex[p]?.let { it != "n/a" && it !in Engine.DONE } == true }
        if (camp.isNotEmpty()) o.add(Opt("camcompile", "Camera", "Compile Camera and Gallery (speed)", camp.joinToString { "${it.substringAfterLast('.')}: ${d.sysDex[it]}" }, "Ahead-of-time compiles both apps for faster launch and browsing", "Brief CPU use; Reset compile reverts. No effect on image processing", "ART confirmed", false, true,
            { r -> var ok = 0; var ci = 0; for (p in camp) { ci++; r.onStep?.invoke(ci, camp.size); if (Sh.exec("cmd package compile -m speed -f $p", false, 180000).out.contains("Success")) ok++ }; OptRes(if (ok > 0) St.APPLIED else St.FAILED, "$ok of ${camp.size} compiled") },
            { x, y -> if (y.compiled > x.compiled) "Compiled apps ${x.compiled} to ${y.compiled}" else null }))
        else skip("Compile Camera and Gallery", "Already compiled or state unknown.")
        // Smoothness
        if (s["secure.long_press_timeout"] != "250") o.add(Opt("longpress", "Smoothness", "Faster long-press (250 ms)", "Long-press delay is ${s["secure.long_press_timeout"] ?: "default 400"} ms", "Menus and drags start sooner", "Accidental long-presses are easier", "Confirmed (AOSP key)", false, true, { r -> tw(r, "longpress") })) else skip("Faster long-press", "Already 250 ms.")
        val pk = s["system.peak_refresh_rate"]
        if (d.modes.any { it >= 119f } && pk != "120.0" && pk != "120")
            o.add(Opt("hzpeak", "Smoothness", "Allow 120 Hz (stays adaptive)", "Peak refresh setting is ${pk ?: "unset"}; panel supports ${d.modes.joinToString("/") { it.toInt().toString() }} Hz", "System may use up to 120 Hz; LTPO still lowers it when idle", "None; HyperOS may ignore the key", "AOSP key, HyperOS behaviour unverified", false, true,
                { r -> tw(r, "hzpeak") { Thread.sleep(800); "display now ${Engine.f1(Engine.hz(a))} Hz" } }))
        else skip("Allow 120 Hz", if (d.modes.none { it >= 119f }) "Panel doesn't report 120 Hz." else "Peak refresh already 120.")
        if (s["global.disable_window_blurs"] != "1") o.add(Opt("blur", "Smoothness", "Disable window blur", "Blur is on", "Less GPU work in shade and recents", "Flatter look", "Confirmed (AOSP key)", false, false, { r -> tw(r, "blur") }))
        // Storage
        val total = Sys.storage(a).first
        if (d.cacheBytes >= 1_000_000_000L || b.storFree.toFloat() / total < 0.15f)
            o.add(Opt("trim", "Storage", "Trim app caches", "Caches ${Sys.fmt(d.cacheBytes)}; storage ${String.format(Locale.US, "%.0f", 100f * b.storFree / total)}% free", "Frees evictable app caches; no personal data", "Apps rebuild caches on next use", "Confirmed", false, true,
                { r -> val s0 = Sys.storage(a).second; val x = Sh.exec("pm trim-caches 999g", true, 120000); val s1 = Sys.storage(a).second; OptRes(if (x.ok) St.APPLIED else St.FAILED, "Free storage ${Sys.fmt(s0)} to ${Sys.fmt(s1)}") },
                { x, y -> if (y.storFree - x.storFree > 20_000_000L) "Free storage +${Sys.fmt(y.storFree - x.storFree)}" else null }))
        else skip("Trim app caches", "Only ${Sys.fmt(d.cacheBytes)} of caches and ${String.format(Locale.US, "%.0f", 100f * b.storFree / total)}% storage free: negligible gain.")
        o.add(Opt("maint", "Storage", "Storage TRIM and system upkeep", "Supported maintenance job", "Starts idle maintenance (TRIM) and ART background dexopt", "None", "Confirmed", false, true, { r -> val x = Sh.bgJob("sm idle-maint run; cmd package bg-dexopt-job"); OptRes(if (x.ok) St.APPLIED else St.FAILED, "Started in background; effect is not immediate") }))
        if (d.uncompiled.size >= 3) o.add(Opt("compile", "Launch", "Compile ${minOf(d.uncompiled.size, 15)} apps (speed-profile)", "${d.uncompiled.size} user apps are not ahead-of-time compiled", "Can shorten cold starts for those apps", "Takes a few minutes; some extra storage", "Confirmed (ART)", false, true,
            { r -> var ok = 0; var n = 0; val cl = d.uncompiled.take(15); for (p in cl) { if (r.cancelled) break; n++; r.onStep?.invoke(n, cl.size); if (Sh.exec("cmd package compile -m speed-profile -f $p", false, 120000).out.contains("Success")) ok++ }; OptRes(if (ok > 0) St.APPLIED else St.FAILED, "$ok of $n compiled") },
            { x, y -> if (y.compiled > x.compiled) "Compiled apps ${x.compiled} to ${y.compiled}" else null }))
        else skip("Compile apps", "${d.uncompiled.size} user apps uncompiled: not worth a run.")
        // Camera
        val cb = d.camBucket
        if (cb != null && cb >= 40) o.add(Opt("cambucket", "Camera", "Keep Camera app responsive", "Camera app is in the '${Engine.bucketName(cb)}' bucket", "Moves it to 'working set' so it can start and finish saves normally", "None", "Confirmed (standby buckets)", false, true,
            { r -> val o = Mut.m.change(BucketT("com.android.camera"), "20", "planner"); if (o.ok && o.changed) r.buckets.add("com.android.camera" to o.before); OptRes(if (o.ok) St.APPLIED else St.FAILED, o.detail) }))
        else skip("Camera app responsiveness", "Camera app is not restricted (${Engine.bucketName(cb)}).")
        return o to sk
    }
}
