package com.lunaroptimizer.app

// Pure parsers for dumpsys / shell output (no android.* imports: unit-testable on the JVM).
// Every format below is written from the documented AOSP output format. None has been checked against this phone yet,
// so each parser returns null / empty when it cannot recognise the text and the UI then says "unavailable".

class ProcRow(val name: String, val pid: Int, val kb: Long, val group: String)
class MemDump(val procs: List<ProcRow>, val groups: Map<String, Long>, val zramUsedKb: Long?, val zramSwapKb: Long?, val totalKb: Long?, val freeKb: Long?)
class BattUid(val id: String, val mah: Double, val cpu: Double?, val wake: Double?)
class AudioThread(val type: String, val rateHz: Int?, val format: String?, val devices: List<String>, val standby: Boolean?, val effectCount: Int)
class BtCodec(val codec: String, val rateHz: Int?, val bits: Int?)

object Parse {
    private fun num(s: String) = s.replace(",", "").toLongOrNull()

    /** CUR_MAX_CACHED_PROCESSES from `dumpsys activity settings` (the limit the system is really using). */
    fun curMaxCached(out: String): Int? = Regex("CUR_MAX_CACHED_PROCESSES=(\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull()
        ?: Regex("(?m)^\\s*max_cached_processes=(\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull()

    /** `dumpsys meminfo`: processes grouped by OOM adjustment class, plus totals and ZRAM. */
    fun meminfo(out: String): MemDump? {
        val i = out.indexOf("Total PSS by OOM adjustment:"); if (i < 0) return null
        val procs = ArrayList<ProcRow>(); val groups = LinkedHashMap<String, Long>(); var g = ""
        val head = Regex("^ {1,6}([\\d,]+)K: ([A-Za-z][A-Za-z ]*?)\\s*$"); val item = Regex("^\\s{7,}([\\d,]+)K: (\\S+) \\(pid (\\d+)")
        for (l in out.substring(i).lines().drop(1)) {
            if (l.isBlank() && groups.isNotEmpty()) break
            if (l.startsWith("Total PSS by")) break
            val h = head.find(l)
            if (h != null) { g = h.groupValues[2].trim(); groups[g] = num(h.groupValues[1]) ?: 0L; continue }
            val it2 = item.find(l)
            if (it2 != null) procs.add(ProcRow(it2.groupValues[2], it2.groupValues[3].toInt(), num(it2.groupValues[1]) ?: 0L, g))
        }
        if (groups.isEmpty() && procs.isEmpty()) return null
        val z = Regex("ZRAM:\\s*([\\d,]+)K physical used for ([\\d,]+)K in swap").find(out)
        return MemDump(procs, groups, z?.let { num(it.groupValues[1]) }, z?.let { num(it.groupValues[2]) },
            Regex("Total RAM:\\s*([\\d,]+)K").find(out)?.let { num(it.groupValues[1]) }, Regex("Free RAM:\\s*([\\d,]+)K").find(out)?.let { num(it.groupValues[1]) })
    }

    /** `dumpsys diskstats`: per-package cache bytes from the "Package Names" / "Cache Sizes" arrays. */
    fun diskCaches(out: String): List<Pair<String, Long>> {
        fun arr(label: String) = Regex("$label:\\s*\\[([^\\]]*)\\]").find(out)?.groupValues?.get(1)
        val names = arr("Package Names")?.let { a -> Regex("\"([^\"]+)\"").findAll(a).map { it.groupValues[1] }.toList() } ?: return emptyList()
        val sizes = arr("Cache Sizes")?.split(",")?.mapNotNull { it.trim().toLongOrNull() } ?: return emptyList()
        if (names.size != sizes.size) return emptyList()
        return names.zip(sizes).sortedByDescending { it.second }
    }

    fun uidKey(uid: Int): String { val app = uid % 100000; val user = uid / 100000; return if (app >= 10000) "u${user}a${app - 10000}" else uid.toString() }
    /** `pm list packages -U` -> package to uid. */
    fun uidMap(out: String): Map<String, Int> = out.lines().mapNotNull { l -> Regex("^package:(\\S+)\\s+uid:(\\d+)").find(l.trim())?.let { it.groupValues[1] to it.groupValues[2].toInt() } }.toMap()
    /** `dumpsys batterystats`, section "Estimated power use (mAh)": per-uid mAh since the last full charge. */
    fun battUids(out: String): Map<String, BattUid> {
        val i = out.indexOf("Estimated power use"); if (i < 0) return emptyMap()
        val m = LinkedHashMap<String, BattUid>(); val rx = Regex("^\\s*(?:Uid|UID) (u\\d+a\\d+|\\d+): ([\\d.]+)(?: \\(([^)]*)\\))?")
        for (l in out.substring(i).lines().drop(1)) {
            if (l.isBlank() && m.isNotEmpty()) break
            val r = rx.find(l) ?: continue; val comp = Regex("(\\w+)=([\\d.]+)").findAll(r.groupValues[3]).associate { it.groupValues[1] to it.groupValues[2].toDouble() }
            m[r.groupValues[1]] = BattUid(r.groupValues[1], r.groupValues[2].toDoubleOrNull() ?: 0.0, comp["cpu"], comp["wakelock"])
        }
        return m
    }
    /** Packages that own a running foreground service (media playback, navigation, VPN, location sharing, ...). */
    fun fgServices(out: String): Set<String> {
        val s = HashSet<String>()
        for (blk in out.split("* ServiceRecord{").drop(1)) { val h = Regex("^[0-9a-f]+ u\\d+ ([\\w.]+)/").find(blk) ?: continue; if (blk.contains("isForeground=true")) s.add(h.groupValues[1]) }
        return s
    }
    /** `cmd deviceidle whitelist`: lines kind,package,uid. */
    fun idleWhitelist(out: String): Set<String> = out.lines().mapNotNull { l -> l.trim().split(',').let { if (it.size >= 3) it[1] else null } }.toSet()
    /** Entries the USER added to the battery-optimization whitelist (kind "user"): an explicit choice Lunar must not undo. */
    fun idleUser(out: String): Set<String> = out.lines().mapNotNull { l -> l.trim().split(',').let { if (it.size >= 3 && it[0] == "user") it[1] else null } }.toSet()
    /** dexopt status of one package from `dumpsys package <pkg>` ("[status=speed-profile]"); first arm64 line wins. */
    fun dexStatus(out: String): String? = Regex("\\[status=([a-z-]+)\\]").find(out)?.groupValues?.get(1)
    /** `am start -W`: TotalTime in ms, only for a COLD launch that reported Status ok. */
    fun startTotalMs(out: String): Int? { if (!Regex("Status:\\s*ok").containsMatchIn(out)) return null; if (Regex("LaunchState:\\s*(WARM|HOT)").containsMatchIn(out)) return null; return Regex("TotalTime:\\s*(\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull() }
    /** `cmd package resolve-activity --brief <pkg>`: the last line that looks like pkg/Activity. */
    fun resolveActivity(out: String): String? = out.lines().map { it.trim() }.lastOrNull { Regex("^[\\w.]+/[\\w.$]+$").matches(it) }
    /** `cmd game mode <mode> <pkg>` counts as accepted only with exit 0 and no refusal text. */
    fun gameModeOk(out: String, code: Int): Boolean = code == 0 && !Regex("(?i)exception|not support|unknown|error|invalid|usage").containsMatchIn(out)
    /** Over-inclusive on purpose: every package-like token in a dump. Used only to PROTECT apps (media sessions, alarms, admins). */
    fun pkgTokens(text: String): Set<String> = Regex("\\b[a-z][a-z0-9_]*(?:\\.[a-z0-9_]+){2,}\\b").findAll(text).map { it.value }.toSet()
    /** "pkg/cls:pkg2/cls2" (enabled_notification_listeners, enabled_accessibility_services) -> packages. */
    fun componentPkgs(v: String): Set<String> = if (v.isBlank() || v.trim() == "null") emptySet() else v.trim().split(':').map { it.substringBefore('/') }.filter { it.isNotEmpty() }.toSet()
    fun adminPkgs(out: String): Set<String> = Regex("ComponentInfo\\{([^/}]+)/").findAll(out).map { it.groupValues[1] }.toSet()

    /** `dumpsys media.audio_flinger`: one entry per output thread. */
    fun audioFlinger(out: String): List<AudioThread> {
        val parts = Regex("(?m)^Output thread 0x[0-9a-fA-F]+").split(out); if (parts.size < 2) return emptyList()
        return parts.drop(1).map { blk0 ->
            val blk = blk0.substringBefore("\nInput thread ").substringBefore("\nCapture thread ")
            val devLines = blk.lines().filter { it.contains("Output device", true) }
            val dev = devLines.flatMap { l -> Regex("AUDIO_DEVICE_OUT_[A-Z0-9_]+").findAll(l).map { it.value.removePrefix("AUDIO_DEVICE_OUT_") }.toList() }.distinct()
            AudioThread(Regex("type \\d+ \\((\\w+)\\)").find(blk.lines().first())?.groupValues?.get(1) ?: "?",
                Regex("Sample rate:\\s*(\\d+)").find(blk)?.groupValues?.get(1)?.toIntOrNull(),
                Regex("HAL format:\\s*0x[0-9a-fA-F]+ \\((?:AUDIO_FORMAT_)?(\\w+)\\)").find(blk)?.groupValues?.get(1),
                dev, Regex("Standby:\\s*(yes|no)").find(blk)?.groupValues?.get(1)?.let { it == "yes" }, Regex("Effect ID \\d+").findAll(blk).count())
        }
    }
    /** Active A2DP codec from `dumpsys bluetooth_manager`; null when no connected device or the text is not recognised. */
    fun btCodec(out: String): BtCodec? {
        val i = out.indexOf("A2dp"); if (i < 0) return null
        val sec = out.substring(i, minOf(out.length, i + 12000))
        val c = Regex("(?:codecName|mCodecName|codec_name)\\s*[:=]\\s*([A-Za-z0-9 ._+-]+?)\\s*(?:[,;}\\n]|$)").find(sec)?.groupValues?.get(1)
            ?: Regex("SOURCE_CODEC_TYPE_([A-Z0-9_]+)").find(sec)?.groupValues?.get(1) ?: return null
        return BtCodec(c.trim(), Regex("(?:sampleRate|mSampleRate)\\s*[:=]\\s*(\\d+)").find(sec)?.groupValues?.get(1)?.toIntOrNull(), Regex("(?:bitsPerSample|mBitsPerSample)\\s*[:=]\\s*(\\d+)").find(sec)?.groupValues?.get(1)?.toIntOrNull())
    }
}
