package com.lunaroptimizer.app

import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors

// Section A (safety and rollback). Pure Kotlin: no android.* imports, so it runs in JVM unit tests with a fake Shell.

interface Shell { fun exec(cmd: String, log: Boolean = true, timeoutMs: Long = 60000): Sh.R }
interface KV { fun get(k: String): String?; fun put(k: String, v: String); fun remove(k: String); fun keys(prefix: String): List<String> }

/** Validated read: ok only when the command succeeded and produced a plausible value ("null" is a real value: unset). */
class Rd(val ok: Boolean, val v: String, val why: String = "")

abstract class Target(val key: String) {
    abstract val label: String
    abstract fun read(sh: Shell): Rd
    abstract fun write(sh: Shell, v: String): Sh.R
    open fun restore(sh: Shell, orig: String): Sh.R = write(sh, orig)
    open fun settable(v: String): Boolean = true
    open fun same(a: String, b: String): Boolean { val x = a.trim().toFloatOrNull(); val y = b.trim().toFloatOrNull(); return if (x != null && y != null) Math.abs(x - y) < 0.001f else a.trim() == b.trim() }
    protected fun clean(r: Sh.R): Rd {
        if (r.code != 0) return Rd(false, "", "exit ${r.code}" + if (r.code == -3) " (timeout)" else if (r.err.isNotBlank()) ": " + r.err.trim().take(60) else "")
        val o = r.out.trim()
        if (o.isEmpty()) return Rd(false, "", "empty output")
        if (o.contains("Exception") || o.startsWith("Error") || o.contains("Permission denied") || o.contains("not found")) return Rd(false, "", o.take(80))
        return Rd(true, o)
    }
}

class SettingT(val ns: String, val k: String) : Target("s|$ns|$k") {
    override val label get() = "$ns/$k"
    override fun read(sh: Shell) = clean(sh.exec("settings get $ns $k", false, 15000))
    override fun write(sh: Shell, v: String) = sh.exec(if (v == "null") "settings delete $ns $k" else "settings put $ns $k $v", true, 15000)
}
class DcT(val ns: String, val k: String) : Target("dc|$ns|$k") {
    override val label get() = "device_config $ns/$k"
    override fun read(sh: Shell) = clean(sh.exec("device_config get $ns $k", false, 15000))
    override fun write(sh: Shell, v: String) = sh.exec(if (v == "null") "device_config delete $ns $k" else "device_config put $ns $k $v", true, 15000)
}
/** DeviceConfig sync switch. Lunar uses until_reboot (self-heals) and restores the value it found. */
class SyncT : Target("dcsync") {
    override val label get() = "device_config sync"
    override fun read(sh: Shell): Rd { val r = clean(sh.exec("device_config get_sync_disabled_for_tests", false, 15000)); return if (r.ok && r.v !in setOf("none", "persistent", "until_reboot")) Rd(false, "", "unexpected '${r.v.take(30)}'") else r }
    override fun write(sh: Shell, v: String) = sh.exec("device_config set_sync_disabled_for_tests $v", true, 15000)
    override fun settable(v: String) = v in setOf("none", "persistent", "until_reboot")
}
class OpT(val pkg: String, val op: String) : Target("op|$pkg|$op") {
    override val label get() = "$pkg $op"
    override fun read(sh: Shell): Rd {
        val r = sh.exec("cmd appops get $pkg $op", false, 15000)
        if (r.code != 0) return Rd(false, "", "exit ${r.code}")
        val o = r.out
        if (o.contains("No operations", true)) return Rd(true, "default")
        val m = Regex("(?m)^\\s*(?:Uid mode:\\s*)?" + Regex.escape(op) + ":\\s*([a-z_]+)").find(o) ?: return Rd(false, "", "unparsable: " + o.trim().take(60))
        return Rd(true, m.groupValues[1])
    }
    override fun write(sh: Shell, v: String) = sh.exec("cmd appops set $pkg $op $v", true, 15000)
    override fun settable(v: String) = v in setOf("allow", "ignore", "deny", "default", "foreground", "errored")
}
class BucketT(val pkg: String) : Target("bk|$pkg") {
    override val label get() = "$pkg standby bucket"
    private val names = mapOf("10" to "active", "20" to "working_set", "30" to "frequent", "40" to "rare", "45" to "restricted")
    override fun read(sh: Shell): Rd { val r = clean(sh.exec("am get-standby-bucket $pkg", false, 15000)); return if (r.ok && r.v.toIntOrNull() == null) Rd(false, "", "unexpected '${r.v.take(30)}'") else r }
    override fun settable(v: String) = v in names
    override fun write(sh: Shell, v: String) = names[v]?.let { sh.exec("am set-standby-bucket $pkg $it", true, 15000) } ?: Sh.R("", "bucket $v cannot be set from the shell", -9)
}
/** Package enabled state: Lunar records a package only when IT disabled it (original = "enabled"). */
class PkgT(val pkg: String) : Target("pkg|$pkg") {
    override val label get() = pkg
    override fun read(sh: Shell): Rd {
        val d = sh.exec("pm list packages -d --user 0 $pkg", false, 20000); if (d.code != 0) return Rd(false, "", "exit ${d.code}")
        if (d.out.lines().any { it.trim() == "package:$pkg" }) return Rd(true, "disabled")
        val a = sh.exec("pm list packages --user 0 $pkg", false, 20000); if (a.code != 0) return Rd(false, "", "exit ${a.code}")
        return Rd(true, if (a.out.lines().any { it.trim() == "package:$pkg" }) "enabled" else "absent")
    }
    override fun settable(v: String) = v == "enabled" || v == "disabled"
    override fun write(sh: Shell, v: String) = sh.exec(if (v == "disabled") "pm disable-user --user 0 $pkg" else "pm enable --user 0 $pkg", true, 30000)
}

fun targetOf(key: String): Target? {
    val p = key.split('|')
    return when {
        key == "dcsync" -> SyncT()
        p.size == 3 && p[0] == "s" -> SettingT(p[1], p[2])
        p.size == 3 && p[0] == "dc" -> DcT(p[1], p[2])
        p.size == 3 && p[0] == "op" -> OpT(p[1], p[2])
        p.size == 2 && p[0] == "bk" -> BucketT(p[1])
        p.size == 2 && p[0] == "pkg" -> PkgT(p[1])
        else -> null
    }
}

enum class JState { PENDING, APPLIED, RESTORING, RESTORE_FAILED }
class JEntry(val key: String, val original: String, var applied: String, var state: JState, val owners: MutableSet<String>, var note: String = "")
class Out(val ok: Boolean, val changed: Boolean, val detail: String, val before: String = "", val after: String = "", val rejected: Boolean = false)
class Tx(val ok: Boolean, val outs: List<Out>, val rolledBack: Int)

class Mutator(private val sh: Shell, private val kv: KV) {
    private val lock = Any()
    @Volatile private var worker: Thread? = null
    private val ex = Executors.newSingleThreadExecutor { r -> Thread(r, "lunar-mut").also { it.isDaemon = true; worker = it } }

    /** One serialized mutation executor: every state-changing operation runs on this single thread under one lock. */
    fun <T> serial(b: () -> T): T {
        if (Thread.currentThread() === worker) return b()
        try { return ex.submit(Callable { synchronized(lock) { b() } }).get() } catch (e: ExecutionException) { throw e.cause ?: e }
    }

    // ---- journal persistence (line codec, no org.json so it runs on the JVM)
    private fun enc(s: String) = s.replace("%", "%25").replace("\u001F", "%1F").replace("\n", "%0A").replace(",", "%2C")
    private fun dec(s: String) = s.replace("%2C", ",").replace("%0A", "\n").replace("%1F", "\u001F").replace("%25", "%")
    private fun ser(e: JEntry) = listOf(e.state.name, enc(e.original), enc(e.applied), e.owners.sorted().joinToString(",") { enc(it) }, enc(e.note)).joinToString("\u001F")
    private fun de(key: String, s: String): JEntry? {
        val p = s.split("\u001F"); if (p.size != 5) return null
        val st = try { JState.valueOf(p[0]) } catch (x: Exception) { return null }
        return JEntry(key, dec(p[1]), dec(p[2]), st, p[3].split(",").filter { it.isNotEmpty() }.map { dec(it) }.toMutableSet(), dec(p[4]))
    }
    fun entry(key: String): JEntry? = kv.get("j|$key")?.let { de(key, it) }
    fun entries(): List<JEntry> = kv.keys("j|").mapNotNull { k -> kv.get(k)?.let { de(k.substring(2), it) } }.sortedBy { it.key }
    private fun save(e: JEntry) = kv.put("j|${e.key}", ser(e))
    private fun drop(key: String) = kv.remove("j|$key")

    /** Imports a record written by an older Lunar version (o|kind|ns|key or ob|pkg). */
    fun importLegacy(k: String, v: String): Boolean {
        val key = when {
            k.startsWith("ob|") -> "bk|" + k.substring(3)
            k.startsWith("lpkg|") -> "pkg|" + k.substring(5)
            k.startsWith("o|") -> k.split('|').let { p -> if (p.size != 4) null else if (p[1] == "dc") "dc|${p[2]}|${p[3]}" else "s|${p[1]}|${p[3]}" }
            else -> null
        } ?: return false
        if (entry(key) != null) return false
        save(JEntry(key, v, "", JState.APPLIED, mutableSetOf("legacy"), "imported from an earlier version")); return true
    }

    // ---- change / release
    /** Applies value to t. Records a validated original first, writes, then verifies by read-back. owner = who asked (tweak id). */
    fun change(t: Target, value: String, owner: String): Out = serial {
        if (!t.settable(value)) return@serial Out(false, false, "${t.label}: value '$value' cannot be set")
        val cur = t.read(sh); val ex0 = entry(t.key)
        if (!cur.ok) return@serial Out(false, false, "${t.label}: current value unreadable (${cur.why}); left unchanged")
        if (ex0 == null && t.same(cur.v, value)) return@serial Out(true, false, "${t.label}: already ${cur.v}", cur.v, cur.v)
        val e = when {
            ex0 == null -> JEntry(t.key, cur.v, value, JState.PENDING, mutableSetOf(owner))
            t.same(cur.v, ex0.applied) || t.same(cur.v, ex0.original) -> ex0.also { it.owners.add(owner); it.applied = value; it.state = JState.PENDING }
            else -> JEntry(t.key, cur.v, value, JState.PENDING, mutableSetOf(owner), "value changed outside Lunar; restore target re-based")
        }
        if (!t.settable(e.original) && e.state == JState.PENDING && ex0 == null) return@serial Out(false, false, "${t.label}: original '${e.original}' cannot be restored from the shell; left unchanged")
        save(e)
        val w = t.write(sh, value); val rb = t.read(sh)
        if (rb.ok && t.same(rb.v, value)) { e.state = JState.APPLIED; save(e); return@serial Out(true, true, "${t.label}: ${e.original} -> ${rb.v}", e.original, rb.v) }
        if (rb.ok && t.same(rb.v, e.original) && ex0 == null) { drop(t.key); return@serial Out(false, false, "${t.label}: " + (if (!w.ok) "command failed (exit ${w.code}" + (if (w.err.isNotBlank()) ", " + w.err.trim().take(50) else "") + ")" else "system did not keep it") + "; read back ${rb.v}", e.original, rb.v, rejected = w.ok) }
        Out(false, false, "${t.label}: could not verify (" + (if (rb.ok) "read back ${rb.v}" else "read-back failed: ${rb.why}") + "); record kept, use Restore", e.original, rb.v)
    }

    /** Gives back owner's claim; restores the original only when no other owner needs the change. Record is deleted only after read-back equals the original. */
    fun release(t: Target, owner: String): Out = serial {
        val e = entry(t.key) ?: return@serial Out(true, false, "${t.label}: no Lunar record, left as is")
        val remaining = if (owner in e.owners) e.owners - owner else e.owners - "legacy"
        if (remaining.isNotEmpty() && e.state != JState.RESTORE_FAILED) { e.owners.clear(); e.owners.addAll(remaining); save(e); return@serial Out(true, false, "${t.label}: still used by ${remaining.joinToString()}; left applied") }
        restoreNow(t, e, false)
    }
    /** Explicit restore for all owners. force = also overwrite a value somebody else changed after Lunar (only on the user's explicit request). */
    fun restore(t: Target, force: Boolean = true): Out = serial { val e = entry(t.key) ?: return@serial Out(true, false, "${t.label}: no Lunar record, left as is"); restoreNow(t, e, force) }

    private fun restoreNow(t: Target, e: JEntry, force: Boolean): Out {
        if (!force && e.state == JState.APPLIED && e.applied.isNotEmpty()) {
            val cur = t.read(sh)
            if (cur.ok && !t.same(cur.v, e.applied) && !t.same(cur.v, e.original)) { drop(t.key); return Out(true, false, "${t.label}: now ${cur.v}, changed after Lunar applied it; left as is (record cleared)") }
        }
        if (!t.settable(e.original)) { e.state = JState.RESTORE_FAILED; e.note = "original '${e.original}' cannot be restored from the shell"; save(e); return Out(false, false, "${t.label}: RESTORE_FAILED, ${e.note}") }
        e.state = JState.RESTORING; save(e)
        val w = t.restore(sh, e.original); val rb = t.read(sh)
        if (rb.ok && t.same(rb.v, e.original)) { drop(t.key); return Out(true, true, "${t.label}: restored to ${rb.v}", e.applied, rb.v) }
        e.state = JState.RESTORE_FAILED; e.note = if (!w.ok) "restore command failed (exit ${w.code})" else if (rb.ok) "read back ${rb.v}, expected ${e.original}" else "read-back failed: ${rb.why}"; save(e)
        return Out(false, false, "${t.label}: RESTORE_FAILED, ${e.note}; record kept")
    }

    /** All-or-nothing: if any op fails verification, the ops already applied in this transaction are released in reverse. */
    fun transaction(ops: List<Triple<Target, String, String>>): Tx = serial {
        val outs = ArrayList<Out>(); val done = ArrayList<Triple<Target, String, String>>()
        for (op in ops) {
            val o = change(op.first, op.second, op.third); outs.add(o)
            if (!o.ok) { var rb = 0; for (d in done.reversed()) if (release(d.first, d.third).ok) rb++; return@serial Tx(false, outs, rb) }
            done.add(op)
        }
        Tx(true, outs, 0)
    }

    /** DeviceConfig tweaks: take the sync switch (until_reboot) for this dc key before changing it. Released again by releaseDc. */
    fun changeDc(t: DcT, value: String, owner: String): Out = serial {
        val s = change(SyncT(), "until_reboot", t.key)
        if (!s.ok) return@serial Out(false, false, "${t.label}: could not pause DeviceConfig sync (${s.detail})")
        val o = change(t, value, owner)
        if (!o.ok && !o.changed && entry(t.key) == null) release(SyncT(), t.key)
        o
    }
    fun releaseDc(t: DcT, owner: String): Out = serial {
        val o = release(t, owner)
        if (o.ok && entry(t.key) == null) release(SyncT(), t.key)
        o
    }

    /** After a restart: settle records left PENDING or RESTORING by an interrupted operation. Returns human-readable lines. */
    fun recover(): List<String> = serial {
        val ls = ArrayList<String>()
        for (e in entries()) {
            val t = targetOf(e.key) ?: continue
            if (e.state != JState.PENDING && e.state != JState.RESTORING) continue
            val cur = t.read(sh); if (!cur.ok) { ls.add("${t.label}: still ${e.state}, value unreadable (${cur.why})"); continue }
            if (t.same(cur.v, e.original)) { drop(e.key); ls.add("${t.label}: already at original, record cleared"); continue }
            if (e.state == JState.PENDING && t.same(cur.v, e.applied)) { e.state = JState.APPLIED; save(e); ls.add("${t.label}: applied, record confirmed"); continue }
            if (e.state == JState.RESTORING) { val r = restoreNow(t, e, true); ls.add(r.detail); continue }
            drop(e.key); ls.add("${t.label}: now ${cur.v}, changed outside Lunar; record dropped (not touched)")
        }
        ls
    }
    /** Retries every RESTORE_FAILED record. */
    fun retryFailed(): List<String> = serial { entries().filter { it.state == JState.RESTORE_FAILED }.mapNotNull { e -> targetOf(e.key)?.let { restoreNow(it, e, true).detail } } }
    fun failed(): List<JEntry> = entries().filter { it.state == JState.RESTORE_FAILED }
}
