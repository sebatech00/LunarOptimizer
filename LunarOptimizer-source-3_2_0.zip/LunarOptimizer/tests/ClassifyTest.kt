package com.lunaroptimizer.app
object ClassifyTest {
    var f = 0
    fun t(id: String, sys: Boolean, uid: String?, risk: Risk, cat: Cat? = null) {
        val (c, r, _) = Debloat.classify(id, sys, uid); val ok = r == risk && (cat == null || c == cat)
        println((if (ok) "PASS " else "FAIL ") + id + " → $c/$r"); if (!ok) f++
    }
    @JvmStatic fun main(a: Array<String>) {
        t("com.android.systemui", true, null, Risk.PROTECTED); t("com.android.settings", true, null, Risk.PROTECTED)
        t("com.miui.securitycenter", true, null, Risk.PROTECTED); t("com.google.android.gms", true, null, Risk.PROTECTED)
        t("com.xiaomi.thermal.service", true, null, Risk.PROTECTED); t("com.android.providers.contacts", true, null, Risk.PROTECTED)
        t("com.vendor.fingerprintx", true, null, Risk.PROTECTED); t("com.foo.bar", true, "android.uid.system", Risk.PROTECTED)
        t("com.miui.analytics", true, null, Risk.MEDIUM, Cat.XIAOMI); t("com.miui.msa.global", true, null, Risk.MEDIUM)
        t("com.facebook.appmanager", true, null, Risk.LOW); t("com.google.android.youtube", true, null, Risk.LOW, Cat.GOOGLE)
        t("com.xiaomi.somethingnew", true, null, Risk.UNKNOWN, Cat.XIAOMI); t("com.google.android.something", true, null, Risk.UNKNOWN, Cat.GOOGLE)
        t("com.random.preinstalled", true, null, Risk.UNKNOWN, Cat.THIRD); t("com.android.unknownthing", true, null, Risk.UNKNOWN, Cat.SYSTEM)
        t("org.some.userapp", false, null, Risk.LOW, Cat.USER); t("com.miui.securitycenter", false, null, Risk.PROTECTED)
        println(if (f == 0) "ALL CLASSIFY TESTS PASSED" else "$f FAILED"); if (f != 0) System.exit(1)
    }
}
